import { Router, Response } from 'express';
import * as XLSX from 'xlsx';
import { dbStorage } from '../db/storage';
import { requireAuth, AuthenticatedRequest } from '../middleware/auth';
import { requirePermission } from '../middleware/permissions';
import { PermissionKey } from '../../types/permissions';
import { REPORT_EXPORT_FIELDS, ReportQueryResult } from '../../types/reports';

export const reportRouter = Router();

reportRouter.get('/query', requireAuth, requirePermission(PermissionKey.REPORTS_VIEW), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const {
      reportType = 'tasks',
      companyId,
      status,
      priority,
      assignedToId,
      creatorId,
      dateFrom,
      dateTo,
      dueDateFrom,
      dueDateTo,
      search,
    } = req.query;

    const allowedCompanyIds = user.isSuperAdmin
      ? undefined
      : user.assignedCompanies?.map(c => c.id) || [];

    const allTasks = dbStorage.getTasks({
      companyId: companyId as string,
      status: status as string,
      priority: priority as string,
      assigneeId: assignedToId as string,
      search: search as string,
      allowedCompanyIds,
    });

    let filtered = allTasks;

    if (creatorId && creatorId !== 'all') {
      filtered = filtered.filter(t => t.creatorId === creatorId);
    }
    if (dateFrom) {
      filtered = filtered.filter(t => new Date(t.createdAt) >= new Date(dateFrom as string));
    }
    if (dateTo) {
      filtered = filtered.filter(t => new Date(t.createdAt) <= new Date(dateTo as string));
    }
    if (dueDateFrom) {
      filtered = filtered.filter(t => t.dueDate && new Date(t.dueDate) >= new Date(dueDateFrom as string));
    }
    if (dueDateTo) {
      filtered = filtered.filter(t => t.dueDate && new Date(t.dueDate) <= new Date(dueDateTo as string));
    }

    const now = new Date();
    const tasks = filtered.map((t: any) => {
      const dueDateObj = t.dueDate ? new Date(t.dueDate) : null;
      const isCompleted = t.status?.slug === 'completed' || t.statusId === 'ts-5';
      const daysOverdue = dueDateObj && dueDateObj < now && !isCompleted
        ? Math.ceil((now.getTime() - dueDateObj.getTime()) / (1000 * 60 * 60 * 24))
        : 0;

      return {
        ...t,
        taskCode: t.taskCode || t.code || `TSK-${t.id}`,
        title: t.title || '',
        statusReason: t.statusReason || (t.isDelayed ? 'تأخير في الاعتماد' : ''),
        companyName: t.company?.nameAr || t.company?.nameEn || '',
        companyNameAr: t.company?.nameAr || t.company?.nameEn || '',
        companyNameEn: t.company?.nameEn || t.company?.nameAr || '',
        companyCode: t.company?.code || '',
        assignedToName: t.assignedTo?.fullName || 'غير مسند',
        assignedToNameAr: t.assignedTo?.fullName || 'غير مسند',
        creatorName: t.creator?.fullName || '',
        status: t.status?.slug || (isCompleted ? 'completed' : t.isDelayed ? 'delayed' : 'in_progress'),
        statusLabelAr: t.status?.nameAr || (isCompleted ? 'مكتملة' : 'قيد التنفيذ'),
        statusLabelEn: t.status?.nameEn || (isCompleted ? 'Completed' : 'In Progress'),
        priority: t.priority?.slug || 'medium',
        priorityLabelAr: t.priority?.nameAr || 'متوسطة',
        priorityLabelEn: t.priority?.nameEn || 'Medium',
        daysOverdue,
      };
    });

    const totalTasks = tasks.length;
    const completedTasks = tasks.filter((t: any) => t.status === 'completed' || t.statusId === 'ts-5' || t.statusSlug === 'completed').length;
    const inProgressTasks = tasks.filter((t: any) => t.status === 'in_progress' || t.statusId === 'ts-2' || t.statusSlug === 'in_progress').length;
    const delayedTasks = tasks.filter((t: any) => t.status === 'delayed' || t.statusId === 'ts-4' || t.statusSlug === 'delayed' || t.isDelayed).length;
    const overdueTasks = tasks.filter((t: any) => t.daysOverdue > 0 || (t.dueDate && new Date(t.dueDate) < now && t.status !== 'completed' && t.statusId !== 'ts-5')).length;
    const completionRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

    const summary = {
      totalTasks,
      completedTasks,
      inProgressTasks,
      delayedTasks,
      overdueTasks,
      completionRate,
      avgTurnaroundDays: 3,
    };

    const companyMap = new Map<string, any>();
    tasks.forEach((t: any) => {
      const cId = t.companyId || 'general';
      const cNameAr = t.companyNameAr || 'عامة';
      const cNameEn = t.companyNameEn || 'General';
      const cCode = t.companyCode || '';
      if (!companyMap.has(cId)) {
        companyMap.set(cId, {
          id: cId,
          key: cId,
          labelAr: cNameAr,
          labelEn: cNameEn,
          subLabel: cCode,
          total: 0,
          completed: 0,
          inProgress: 0,
          delayed: 0,
          overdue: 0,
          completionRate: 0,
        });
      }
      const item = companyMap.get(cId);
      item.total++;
      if (t.status === 'completed' || t.statusId === 'ts-5') item.completed++;
      else if (t.status === 'in_progress' || t.statusId === 'ts-2') item.inProgress++;
      else if (t.status === 'delayed' || t.statusId === 'ts-4' || t.isDelayed) item.delayed++;
      if (t.daysOverdue > 0) item.overdue++;
      item.completionRate = item.total > 0 ? Math.round((item.completed / item.total) * 100) : 0;
    });
    const groupBreakdown = Array.from(companyMap.values());

    let selectedCompanyName = '';
    if (companyId && companyId !== 'all') {
      const comp = dbStorage.getCompanyById(companyId as string);
      selectedCompanyName = comp?.nameAr || comp?.nameEn || (companyId as string);
    }

    let selectedAssigneeName = '';
    if (assignedToId && assignedToId !== 'all') {
      const u = dbStorage.findUserById(assignedToId as string);
      selectedAssigneeName = u?.fullName || (assignedToId as string);
    }

    let activeFilterCount = 0;
    if (companyId && companyId !== 'all') activeFilterCount++;
    if (status && status !== 'all') activeFilterCount++;
    if (priority && priority !== 'all') activeFilterCount++;
    if (assignedToId && assignedToId !== 'all') activeFilterCount++;
    if (dateFrom) activeFilterCount++;
    if (dateTo) activeFilterCount++;
    if (search) activeFilterCount++;

    const appliedFilters = {
      companyName: selectedCompanyName,
      status: status && status !== 'all' ? (status as string) : undefined,
      priority: priority && priority !== 'all' ? (priority as string) : undefined,
      assignedToName: selectedAssigneeName,
      dateFrom: dateFrom as string | undefined,
      dateTo: dateTo as string | undefined,
      search: search as string | undefined,
      activeFilterCount,
    };

    const result: ReportQueryResult = {
      data: tasks,
      tasks,
      totalCount: allTasks.length,
      filteredCount: tasks.length,
      metrics: {
        total: tasks.length,
        completed: completedTasks,
      },
      summary,
      groupBreakdown,
      appliedFilters,
      reportType: (reportType as any) || 'company_report',
      generatedBy: {
        fullName: user.fullName || user.email,
        role: user.roles?.[0]?.nameAr || (user.isSuperAdmin ? 'مدير عام النظام' : 'مستخدم مصرح'),
      },
      generatedAt: new Date().toISOString(),
      filters: req.query as any,
    };

    res.json(result);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to query reports' });
  }
});

reportRouter.post('/export/excel', requireAuth, requirePermission(PermissionKey.REPORTS_EXPORT), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { reportType = 'tasks', filters = {}, selectedFields = [], language = 'ar' } = req.body;
    const isAr = language === 'ar';

    const user = req.user!;
    const allowedCompanyIds = user.isSuperAdmin
      ? undefined
      : user.assignedCompanies?.map(c => c.id) || [];

    const tasks = dbStorage.getTasks({
      companyId: filters.companyId,
      status: filters.status,
      priority: filters.priority,
      assigneeId: filters.assignedToId || filters.assigneeId,
      search: filters.search,
      allowedCompanyIds,
    });

    const fieldDefs = REPORT_EXPORT_FIELDS.filter(f => selectedFields.length === 0 || selectedFields.includes(f.key));

    const rows = tasks.map((t: any) => {
      const row: Record<string, any> = {};
      fieldDefs.forEach(field => {
        const header = isAr ? field.labelAr : field.labelEn;
        if (field.key === 'companyName') row[header] = t.company?.nameAr || t.company?.nameEn || '';
        else if (field.key === 'status') row[header] = t.status?.nameAr || t.status?.nameEn || '';
        else if (field.key === 'priority') row[header] = t.priority?.nameAr || t.priority?.nameEn || '';
        else if (field.key === 'assigneeName') row[header] = t.assignedTo?.fullName || 'غير مسند';
        else if (field.key === 'creatorName') row[header] = t.creator?.fullName || '';
        else row[header] = t[field.key] ?? '';
      });
      return row;
    });

    const worksheet = XLSX.utils.json_to_sheet(rows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Report');

    const buffer = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename=report_${reportType}_${Date.now()}.xlsx`);
    res.send(buffer);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to export Excel' });
  }
});

reportRouter.post('/export/pdf-data', requireAuth, requirePermission(PermissionKey.REPORTS_EXPORT), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { filters = {} } = req.body;
    const user = req.user!;
    const allowedCompanyIds = user.isSuperAdmin
      ? undefined
      : user.assignedCompanies?.map(c => c.id) || [];

    const tasks = dbStorage.getTasks({
      companyId: filters.companyId,
      status: filters.status,
      priority: filters.priority,
      assigneeId: filters.assignedToId || filters.assigneeId,
      search: filters.search,
      allowedCompanyIds,
    });

    const formattedData = tasks.map((t: any) => ({
      ...t,
      companyName: t.company?.nameAr || t.company?.nameEn || '',
      status: t.status?.nameAr || t.status?.nameEn || '',
      priority: t.priority?.nameAr || t.priority?.nameEn || '',
      assigneeName: t.assignedTo?.fullName || 'غير مسند',
      creatorName: t.creator?.fullName || '',
    }));

    res.json({
      success: true,
      data: {
        data: formattedData,
        totalCount: formattedData.length,
        filteredCount: formattedData.length,
        generatedAt: new Date().toISOString(),
        filters,
      },
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to export PDF data' });
  }
});
