@echo off
setlocal
title Enterprise System - Production Update

echo ========================================================
echo    Updating Enterprise Production System
echo ========================================================
echo.

echo [1/4] Checking for Git repository updates...
where git >nul 2>nul
if %errorlevel% equ 0 (
    if exist ".git" (
        echo Pulling latest changes from repository...
        git pull
    ) else (
        echo Not a git clone directory, skipping git pull.
    )
) else (
    echo Git not detected, proceeding with file-based update.
)
echo.

echo [2/4] Installing / Updating NPM dependencies...
call npm install
if %errorlevel% neq 0 (
    echo [ERROR] Dependencies installation failed!
    pause
    exit /b 1
)
echo.

echo [3/4] Rebuilding Production Distribution (Vite + esbuild)...
call npm run build
if %errorlevel% neq 0 (
    echo [ERROR] Build failed! The old service was not restarted.
    pause
    exit /b 1
)
echo.

echo [4/4] Restarting background service...
call "%~dp0restart.bat"

echo.
echo ========================================================
echo  [SUCCESS] System updated and restarted successfully!
echo ========================================================
echo.
pause
