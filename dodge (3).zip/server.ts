import express from 'express';
import path from 'path';
import cookieParser from 'cookie-parser';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import { authRouter } from './src/server/routes/auth.routes';
import { companyRouter } from './src/server/routes/company.routes';
import { roleRouter } from './src/server/routes/role.routes';
import { userRouter } from './src/server/routes/user.routes';
import { auditRouter } from './src/server/routes/audit.routes';
import { notificationRouter } from './src/server/routes/notification.routes';
import { schemaRouter } from './src/server/routes/schema.routes';
import { securityTestRouter } from './src/server/routes/security-test.routes';
import { systemRouter } from './src/server/routes/system.routes';
import { taskRouter } from './src/server/routes/task.routes';
import { customFieldRouter } from './src/server/routes/custom-field.routes';
import { dashboardRouter } from './src/server/routes/dashboard.routes';
import { reportRouter } from './src/server/routes/report.routes';
import { apiRateLimiter } from './src/server/middleware/rateLimit';
import { dbStorage } from './src/server/db/storage';
import { logger } from './src/server/utils/logger';

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 2026;

  // JSON Body Parser & Cookie Parser
  app.use(express.json({ limit: '10mb' }));
  app.use(cookieParser());

  // Production request logging
  app.use((req, res, next) => {
    const start = Date.now();
    res.on('finish', () => {
      const duration = Date.now() - start;
      if (req.originalUrl.startsWith('/api') && req.originalUrl !== '/api/health') {
        logger.info(`${req.method} ${req.originalUrl} [${res.statusCode}] - ${duration}ms`);
      }
    });
    next();
  });

  // General API Rate Limiting
  app.use('/api', apiRateLimiter);

  // Health check endpoint for Windows Service & Cloud Load Balancers
  app.get('/api/health', (_req, res) => {
    const mem = process.memoryUsage();
    const companies = dbStorage.getAllCompanies();
    res.json({
      status: 'healthy',
      uptimeSeconds: Math.floor(process.uptime()),
      timestamp: new Date().toISOString(),
      version: '2.5.0-production',
      environment: process.env.NODE_ENV || 'development',
      port: PORT,
      system: {
        nodeVersion: process.version,
        platform: process.platform,
        arch: process.arch,
        memoryUsageMb: {
          rss: Math.round(mem.rss / (1024 * 1024)),
          heapTotal: Math.round(mem.heapTotal / (1024 * 1024)),
          heapUsed: Math.round(mem.heapUsed / (1024 * 1024)),
        },
      },
      database: {
        status: 'connected',
        companiesCount: companies.length,
      }
    });
  });

  // Register API routes
  app.use('/api/auth', authRouter);
  app.use('/api/companies', companyRouter);
  app.use('/api/tasks', taskRouter);
  app.use('/api/custom-fields', customFieldRouter);
  app.use('/api/dashboard', dashboardRouter);
  app.use('/api/reports', reportRouter);
  app.use('/api/roles', roleRouter);
  app.use('/api/users', userRouter);
  app.use('/api/audit-logs', auditRouter);
  app.use('/api/notifications', notificationRouter);
  app.use('/api/system', systemRouter);
  app.use('/api/system/schema', schemaRouter);
  app.use('/api/security-test', securityTestRouter);

  // Vite middleware for development vs static serve for production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const server = app.listen(PORT, '0.0.0.0', () => {
    logger.info(`Enterprise Multi-Company Production Server listening on http://0.0.0.0:${PORT}`);
  });

  // Graceful shutdown handling
  const shutdown = (signal: string) => {
    logger.info(`Received ${signal}. Gracefully stopping server...`);
    server.close(() => {
      logger.info('Server closed cleanly. Exiting process.');
      process.exit(0);
    });
    setTimeout(() => {
      logger.error('Forced shutdown after 10s timeout.');
      process.exit(1);
    }, 10000);
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

startServer().catch(err => {
  logger.error('Failed to start server:', err);
  process.exit(1);
});
