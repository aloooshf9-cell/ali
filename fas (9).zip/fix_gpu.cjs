const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

// Optimize 'classic'
code = code.replace(
  /backdrop-blur-2xl bg-black\/85 animate-fade-in shadow-\[inset_0_0_120px_rgba\(239,68,68,0\.4\)\] animate-\[pulse_1\.5s_infinite\]/g,
  'backdrop-blur-sm bg-[#050505]/95 animate-fade-in bg-[radial-gradient(circle,rgba(239,68,68,0.2)_0%,transparent_100%)] animate-[pulse_1.5s_infinite]'
);

// Optimize 'radar'
code = code.replace(
  /backdrop-blur-xl bg-black\/90 animate-fade-in flex items-center justify-center overflow-hidden/g,
  'backdrop-blur-sm bg-black/95 animate-fade-in flex items-center justify-center overflow-hidden'
);
code = code.replace(/w-\[150vw\] h-\[150vw\] rounded-full border-\[20px\]/g, 'w-[100vw] h-[100vw] rounded-full border-[8px]');
code = code.replace(/w-\[100vw\] h-\[100vw\] rounded-full border-\[10px\]/g, 'w-[75vw] h-[75vw] rounded-full border-[4px]');
code = code.replace(/w-\[50vw\] h-\[50vw\] rounded-full border-\[5px\]/g, 'w-[40vw] h-[40vw] rounded-full border-[2px]');

// Optimize 'strobe'
code = code.replace(
  /backdrop-blur-3xl bg-black\/80 animate-fade-in shadow-\[inset_0_0_150px_rgba\(255,0,0,0\.8\)\] border-\[12px\] border-red-600 animate-\[pulse_0\.15s_infinite\]/g,
  'backdrop-blur-sm bg-[#050505]/90 animate-fade-in border-[8px] border-red-600 animate-[pulse_0.2s_infinite] bg-[radial-gradient(circle,rgba(255,0,0,0.3)_0%,transparent_100%)]'
);

// Optimize 'cyber'
code = code.replace(
  /backdrop-blur-xl bg-\[#030000\] animate-fade-in shadow-\[inset_0_0_150px_rgba\(220,38,38,0\.5\)\] border-8 border-red-600\/60/g,
  'backdrop-blur-sm bg-[#030000]/95 animate-fade-in border-4 border-red-600/60 bg-[radial-gradient(circle,rgba(220,38,38,0.2)_0%,transparent_100%)]'
);
code = code.replace(/mix-blend-overlay/g, 'opacity-20'); // mix-blend is very expensive
code = code.replace(/shadow-\[0_0_20px_rgba\(239,68,68,0\.8\)\]/g, 'opacity-60');

// Optimize 'minimal'
code = code.replace(
  /backdrop-blur-3xl bg-slate-950\/90 animate-fade-in border-2 border-red-500\/30 shadow-\[inset_0_0_80px_rgba\(239,68,68,0\.15\)\]/g,
  'backdrop-blur-sm bg-slate-950/95 animate-fade-in border border-red-500/30'
);

// Optimize the inner alert box
code = code.replace(
  /bg-\[#080c16\]\/95 border-2 border-red-500 rounded-\[3rem\] p-8 md:p-12 shadow-\[0_0_120px_rgba\(239,68,68,0\.5\)\] text-center overflow-hidden flex flex-col items-center backdrop-blur-sm/g,
  'bg-[#080c16]/95 border-2 border-red-500 rounded-[3rem] p-8 md:p-12 shadow-[0_0_40px_rgba(239,68,68,0.3)] text-center overflow-hidden flex flex-col items-center'
);

// Optimize the vibrating fire/pulse alert icon
code = code.replace(
  /bg-red-600 rounded-full blur-2xl opacity-60 animate-\[ping_1\.5s_infinite\] scale-125/g,
  'bg-red-600/40 rounded-full blur-md opacity-40 animate-[pulse_1.5s_infinite] scale-110'
);

// We should also check for heavy Mapbox or map animations if there is any map view.
// But the alarm screen is usually the one running 24/7 if an alarm goes off, or the main dashboard.
// If the main dashboard has heavy background blurs, we should fix them too.

fs.writeFileSync('src/App.tsx', code, 'utf8');
console.log('Fixed GPU heavy classes');
