const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

// 1. Fix setHugeOfflineAlert triggering for out_of_service buildings
code = code.replace(
  /if \(b\.isOnline === false\) setHugeOfflineAlert\(b\);/g,
  "if (b.isOnline === false && b.custom_status === 'normal') setHugeOfflineAlert(b);"
);

// 2. Fix login persistence
// Initializers
code = code.replace(
  /const \[username, setUsername\] = useState\(''\);/g,
  "const [username, setUsername] = useState(() => localStorage.getItem('AUIB_Username') || '');"
);
code = code.replace(
  /const \[userRole, setUserRole\] = useState<string \| null>\(null\);/g,
  "const [userRole, setUserRole] = useState<string | null>(() => localStorage.getItem('AUIB_Role') || null);"
);
code = code.replace(
  /const \[isSystemActive, setIsSystemActive\] = useState\(false\);/g,
  "const [isSystemActive, setIsSystemActive] = useState(() => localStorage.getItem('AUIB_Active') === 'true');"
);

// Login handler
const targetLogin = `      if (data.success) {
        setUserRole(data.role);
        setIsSystemActive(true);`;
const replaceLogin = `      if (data.success) {
        setUserRole(data.role);
        setIsSystemActive(true);
        localStorage.setItem('AUIB_Username', username);
        localStorage.setItem('AUIB_Role', data.role);
        localStorage.setItem('AUIB_Active', 'true');`;
code = code.replace(targetLogin, replaceLogin);

const targetLoginFallback = `      if (username) {
        setUserRole('admin');
        setIsSystemActive(true);`;
const replaceLoginFallback = `      if (username) {
        setUserRole('admin');
        setIsSystemActive(true);
        localStorage.setItem('AUIB_Username', username);
        localStorage.setItem('AUIB_Role', 'admin');
        localStorage.setItem('AUIB_Active', 'true');`;
code = code.replace(targetLoginFallback, replaceLoginFallback);

// Logout handler
const targetLogout = `              onClick={() => {
                setUserRole(null);
                setIsSystemActive(false);
              }}`;
const replaceLogout = `              onClick={() => {
                setUserRole(null);
                setIsSystemActive(false);
                localStorage.removeItem('AUIB_Username');
                localStorage.removeItem('AUIB_Role');
                localStorage.removeItem('AUIB_Active');
              }}`;
code = code.replace(targetLogout, replaceLogout);

fs.writeFileSync('src/App.tsx', code, 'utf8');
console.log('Fixed App.tsx issues');
