const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

// Replace handleUpdateCredit with handleUpdateSettings
code = code.replace(/handleUpdateCredit\(/g, 'handleUpdateSettings(');

// Replace creditSettings. with (systemSettings as any).
code = code.replace(/creditSettings\./g, '(systemSettings as any).');

fs.writeFileSync('src/App.tsx', code, 'utf8');
console.log('Fixed credit settings synchronization');
