Option Explicit
Dim WshShell, fso, strPath, comspec, port, cmdLine

Set fso = CreateObject("Scripting.FileSystemObject")
strPath = fso.GetParentFolderName(WScript.ScriptFullName)
Set WshShell = CreateObject("WScript.Shell")
WshShell.CurrentDirectory = strPath

comspec = WshShell.ExpandEnvironmentStrings("%COMSPEC%")
port = "3010"

' Launch server in invisible background mode (0 = Hidden, False = Do not wait)
cmdLine = Chr(34) & comspec & Chr(34) & " /c " & Chr(34) & strPath & "\start-visible.bat" & Chr(34) & " --bg"
WshShell.Run cmdLine, 0, False

' Brief pause to allow the server port to bind
WScript.Sleep 2500

' Open the web monitor automatically in default browser
WshShell.Run "http://localhost:" & port

' Show confirmation notice (auto-closes in 3 seconds)
WshShell.Popup "تم تشغيل نظام BWE بالخلفية بنجاح!" & vbCrLf & _
               "الرابط: http://localhost:" & port & vbCrLf & _
               "الخادم يعمل الآن بدون نوافذ سوداء مزعجة.", 3, "BWE Fire Alarm Monitor", 64

