const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

// We will split the code at "const fetchSystemData = useCallback(async () => {"
// and at "  const buildingsRef = useRef<any[]>([]);"
// then replace the middle.

const startStr = "const fetchSystemData = useCallback(async () => {";
const endStr = "  const buildingsRef = useRef<any[]>([]);";

const startIdx = code.indexOf(startStr);
const endIdx = code.indexOf(endStr);

if (startIdx !== -1 && endIdx !== -1) {
  const before = code.substring(0, startIdx);
  const after = code.substring(endIdx);
  
  const replacement = `const applySystemData = useCallback((data: any) => {
    setBuildings(prev => {
      const nextBuildings = data.buildings || [];
      if (JSON.stringify(prev) === JSON.stringify(nextBuildings)) {
        return prev;
      }
      return nextBuildings;
    });
    setSystemSettings(prev => {
      const merged = { ...prev, ...data.settings };
      if (JSON.stringify(prev) === JSON.stringify(merged)) {
        return prev;
      }
      return merged;
    });
    if (data.settings?.mapBg) {
      const newBg = \`\${SERVER_URL}\${data.settings.mapBg}\`;
      setMapBg(prev => {
        if (prev === newBg) return prev;
        return newBg;
      });
    }
    if (data.settings?.customAlarmSound) {
       const audioUrl = \`\${SERVER_URL}\${data.settings.customAlarmSound}\`;
       if (customAudioRef.current && customAudioRef.current.src !== audioUrl) {
          customAudioRef.current.src = audioUrl;
          setCustomAlarmSound(audioUrl);
       }
    }
    
    setIsConnectedToServer(true);
    setLastPingTime(prev => {
      const nextTime = new Date().toLocaleTimeString(lang === 'ar' ? 'ar-IQ' : 'en-US');
      if (prev === nextTime) return prev;
      return nextTime;
    });
  }, [lang]);

  const fetchSystemData = useCallback(async () => {
    try {
      const res = await fetch(\`\${SERVER_URL}/api/system\`);
      if (res.ok) {
        const data = await res.json();
        applySystemData(data);
      } else { setIsConnectedToServer(false); }
    } catch { 
      setIsConnectedToServer(false);
    }
  }, [applySystemData]);

  useEffect(() => {
    fetchSystemData();
  }, [fetchSystemData]);

  // Real-time synchronization via SSE
  useEffect(() => {
    if (!isSystemActive) return;
    
    const eventSource = new EventSource(\`\${SERVER_URL}/api/stream\`);
    eventSource.onmessage = (e) => {
      try {
        const payload = JSON.parse(e.data);
        if (payload.type === 'SYNC' && payload.data) {
          applySystemData(payload.data);
        }
      } catch (err) {
        console.error("SSE parse error", err);
      }
    };
    
    return () => {
      eventSource.close();
    };
  }, [isSystemActive, applySystemData]);

  useEffect(() => {
    let poll: any;
    if (isSystemActive) {
      const interval = (systemSettings as any).pingInterval || 5000;
      poll = setInterval(fetchSystemData, interval);
    }
    return () => clearInterval(poll);
  }, [isSystemActive, fetchSystemData, (systemSettings as any).pingInterval]);

`;

  fs.writeFileSync('src/App.tsx', before + replacement + after, 'utf8');
  console.log("Successfully replaced block.");
} else {
  console.log("Could not find start or end bounds.");
}
