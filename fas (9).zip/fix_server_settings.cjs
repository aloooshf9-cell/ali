const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const startIndex = code.indexOf('  app.put("/api/settings", (req, res) => {');
const endIndex = code.indexOf('  // Backup database');

if (startIndex !== -1 && endIndex !== -1) {
  const replacement = `  app.put("/api/settings", (req, res) => {
    const db = loadDb();
    
    for (const key of Object.keys(req.body)) {
      if (key !== 'license') {
        (db.settings as any)[key] = req.body[key];
      }
    }

    saveDb(db);
    addLog("info", "تم تحديث إعدادات النظام المركزية.");
    res.json({ success: true, settings: db.settings });
  });

`;
  code = code.substring(0, startIndex) + replacement + code.substring(endIndex);
  fs.writeFileSync('server.ts', code, 'utf8');
  console.log('Fixed server settings PUT');
} else {
  console.log('Could not find settings block');
}
