const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

// Change the polling interval to 5 minutes instead of reading from pingInterval (which might be 5 seconds)
// This is because SSE handles real-time sync, and frequent polling causes memory leaks over 24/7.
code = code.replace(
  /const interval = \(systemSettings as any\)\.pingInterval \|\| 5000;/g,
  'const interval = 300000; // 5 minutes fallback polling, SSE handles real-time'
);

fs.writeFileSync('src/App.tsx', code, 'utf8');
console.log('Fixed polling');
