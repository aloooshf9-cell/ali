const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const targetAudio = `  const mapRef = useRef<HTMLDivElement | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);`;
  
const replaceAudio = `  const mapRef = useRef<HTMLDivElement | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  
  // Re-initialize audio context if already logged in via localStorage
  useEffect(() => {
    if (isSystemActive && !audioCtxRef.current) {
      // Create it on first mount if logged in. Browsers might suspend it until user interaction.
      try {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
        
        // Setup a one-time click listener to resume it if suspended
        const resumeAudio = () => {
          if (audioCtxRef.current && audioCtxRef.current.state === 'suspended') {
            audioCtxRef.current.resume();
          }
          window.removeEventListener('click', resumeAudio);
        };
        window.addEventListener('click', resumeAudio);
      } catch (e) {
        console.error("Audio initialization failed on auto-login", e);
      }
    }
  }, [isSystemActive]);`;

code = code.replace(targetAudio, replaceAudio);
fs.writeFileSync('src/App.tsx', code, 'utf8');
console.log('Fixed audio context');
