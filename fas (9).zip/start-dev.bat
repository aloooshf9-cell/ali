@echo off
title BWE Server Monitor (Development)
echo ========================================
echo BWE Fire Alarm Monitoring System (DEV MODE)
echo ========================================
echo.

cd /d "%~dp0"

:: Check if Node.js is installed
where node >nul 2>nul
if errorlevel 1 goto NO_NODE

set LOCAL_PORT=3010
set PORT=3010
set NODE_ENV=production

:: 1. If compiled server exists, launch it directly! (No npm install, zero disk usage)
if exist dist\server.cjs (
    echo [INFO] BWE System is ready!
    echo [INFO] Starting Central Server directly on Port 3010...
    echo.
    node dist\server.cjs
    pause
    exit /b
)

:: 2. Fallback to dev mode only if dist\server.cjs is missing
if not exist node_modules (
    echo [INFO] First time setup: Installing minimal dependencies...
    call npm install --no-audit --no-fund --ignore-scripts
    if errorlevel 1 goto DISK_ERROR
)

echo.
echo Starting System on Network...
echo Using Port: 3010
call npm run dev

pause
exit /b

:DISK_ERROR
echo.
echo ========================================================
echo [تنبيه حرج]: فشل التثبيت بسبب امتلاء مساحة القرص الصلب (C:)!
echo npm error ENOSPC: no space left on device
echo.
echo يرجى تفريغ مساحة من القرص C: (تفريغ سلة المحذوفات وحذف النسخ القديمة المكررة)
echo ثم شغل ملف clean-disk-cache.bat وأعد تشغيل النظام.
echo ========================================================
pause
exit /b

:NO_NODE
echo [ERROR] Node.js is not installed on your system!
pause
exit /b
