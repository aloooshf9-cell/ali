const fs = require('fs');
let code = fs.readFileSync('vite.config.ts', 'utf8');

// Insert host: true, cors: true, allowedHosts: true
const target = "server: {";
const replacement = "server: {\n      host: true,\n      cors: true,\n      allowedHosts: true,";

if (code.includes(target) && !code.includes("host: true")) {
  code = code.replace(target, replacement);
  fs.writeFileSync('vite.config.ts', code, 'utf8');
  console.log("Updated vite.config.ts");
} else {
  console.log("Already updated or target not found.");
}
