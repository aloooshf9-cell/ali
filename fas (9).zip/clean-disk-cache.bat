@echo off
title BWE Disk & Cache Cleaner
echo ====================================================
echo BWE Disk & Cache Cleaner
echo تنظيف الذاكرة المؤقتة ومخلفات npm فوراً لتوفير مساحة في القرص
echo ====================================================
echo.

echo [1/3] حذف كاش وسجلات npm المؤقتة من القرص C مباشرة...
if exist "%LOCALAPPDATA%\npm-cache" (
    rd /s /q "%LOCALAPPDATA%\npm-cache" 2>nul
    echo تم حذف مجلد كاش npm بنجاح.
)
if exist "%APPDATA%\npm-cache" (
    rd /s /q "%APPDATA%\npm-cache" 2>nul
    echo تم تفريغ كاش AppData بنجاح.
)

echo.
echo [2/3] تنظيف الملفات المؤقتة في ويندوز (Temp Files)...
del /s /f /q "%TEMP%\*.*" 2>nul
echo تم تنظيف ملفات Temp المؤقتة.

echo.
echo [3/3] فحص واكتمال...
echo.
echo ====================================================
echo تم تنظيف المساحة بنجاح!
echo.
echo ملاحظة هامة:
echo الآن النظام مجهز للعمل مباشرة دون الحاجة لأي تثبيت أو استهلاك مساحة!
echo يمكنك تشغيل النظام فوراً عبر:
echo    - start-visible.bat (تشغيل مباشر)
echo    - أو start-bg.vbs (تشغيل صامت في الخلفية)
echo ====================================================
echo.
pause
exit /b
