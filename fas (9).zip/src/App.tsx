import React, { Component, useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { 
  Bell, BellOff, ShieldCheck, AlertOctagon, Plus, 
  Trash2, Activity, WifiOff, Building2, User, Users, ClipboardList, Download, X,
  VolumeX, Volume2, Image as ImageIcon, Music, Settings, Search, Wrench, PowerOff,
  ShieldAlert, FileText, Languages, ZoomIn, ZoomOut, Maximize, Minimize,
  Dumbbell, GraduationCap, Coffee, Home, HeartPulse, Shield, Clock, Send, MessageCircle,
  Sun, Moon, Camera, BarChart3, Printer, Video, BookOpen, Monitor as MonitorIcon, Briefcase, Landmark, Car,
  Sliders, Database, Upload, Sparkles
} from 'lucide-react';

/**
 * نظام مراقبة إنذارات الحريق المركزي - AUIB
 * برمجة وتطوير: المهندس علي احمد عنيد
 */

const failedAttemptsMap = new Map<string, number>();

const checkBuildingOnlineBrowser = async (ip: string, timeoutMs: number = 800, retries: number = 2, confirmCycles: number = 2): Promise<boolean> => {
  const cleanedIp = (ip || "").trim();
  if (!cleanedIp || cleanedIp === '127.0.0.1' || cleanedIp === 'localhost' || cleanedIp === '0.0.0.0') {
    return true;
  }

  const singleCheck = async (): Promise<boolean> => {
    const controller = new AbortController();
    const id = setTimeout(() => controller.abort(), timeoutMs);
    const startTime = Date.now();
    
    // Format the URL. If the IP doesn't start with http, prefix it with http://
    const url = cleanedIp.startsWith('http://') || cleanedIp.startsWith('https://') ? cleanedIp : `http://${cleanedIp}`;
    
    try {
      await fetch(url, {
        mode: 'no-cors',
        signal: controller.signal,
        headers: { 'Cache-Control': 'no-cache' }
      });
      clearTimeout(id);
      return true; // Succeeded to reach!
    } catch (err: any) {
      clearTimeout(id);
      const duration = Date.now() - startTime;
      
      if (err.name === 'AbortError') {
        return false; // Timed out, definitely offline
      }
      
      // If it rejected instantly (connection refused or CORS blocked but host is there)
      if (duration < 1000) {
        return true; // Host is alive because it actively refused/blocked the request immediately
      }
      
      return false; // Connection timeout or network unreachable
    }
  };

  // Perform retries with small progressive pause
  for (let attempt = 0; attempt < retries; attempt++) {
    const ok = await singleCheck();
    if (ok) {
      failedAttemptsMap.set(cleanedIp, 0);
      return true;
    }
    if (attempt < retries - 1) {
      await new Promise(r => setTimeout(r, 200 * (attempt + 1)));
    }
  }

  // Track consecutive failures to absorb temporary browser/PC network stalls
  const prevFailures = failedAttemptsMap.get(cleanedIp) || 0;
  const newFailures = prevFailures + 1;
  failedAttemptsMap.set(cleanedIp, newFailures);

  // Require at least confirmCycles consecutive polling cycles of failures before flagging as completely offline
  if (newFailures < confirmCycles) {
    return true; // Hold as online temporarily during transient CPU/Network spike or packet loss
  }

  return false;
};

const checkIsBrowserPingBlocked = async (): Promise<boolean> => {
  if (window.location.protocol !== 'https:') {
    return false; // Under http: or file: there are no mixed content blocks
  }
  const startTime = Date.now();
  try {
    // Attempt a dummy HTTP fetch to loopback
    await fetch('http://127.0.0.1:65530/mixed-content-test-dummy', {
      mode: 'no-cors',
    });
    return false;
  } catch (err: any) {
    const duration = Date.now() - startTime;
    // If it threw an error instantly (typically < 25ms), it's highly likely to be blocked by the browser internally.
    if (duration < 25) {
      return true;
    }
    return false;
  }
};

const SERVER_URL = ""; 

const translations = {
  ar: {
    appTitle: "غرفة عمليات BWE",
    appSubtitle: "نظام مراقبة إنذارات الحريق المركزي",
    username: "اسم المستخدم",
    password: "كلمة المرور",
    loginBtn: "تسجيل الدخول",
    devCredit: "برمجة وتطوير: المهندس علي احمد عنيد",
    devCreditEn: "PROGRAMMING & DEV: ENG. ALI AHMED ANEED",
    dashboard: "لوحة تحكم إنذارات الحريق - BWE-AUIB",
    connected: "متصل بالسيرفر",
    connecting: "جاري الاتصال...",
    adminRole: "مدير النظام",
    supervisorRole: "مشرف النظام",
    maintRole: "فريق الصيانة",
    viewerRole: "مراقب",
    monitoringRole: "شاشة مراقبة فقط (للمونترنك)",
    systemStable: "النظام مستقر - جميع البنايات سليمة",
    systemWarning: "تحذير: توجد بلاغات إنذار نشطة!",
    logsBtn: "السجل",
    usersBtn: "إدارة المستخدمين",
    settingsBtn: "الإعدادات",
    statTotal: "إجمالي البنايات",
    statNormal: "سليم",
    statAlarm: "إنذار",
    statMaint: "صيانة",
    statOut: "خارج الخدمة",
    addBuilding: "إضافة بناية",
    bName: "اسم البناية",
    addBtn: "إسقاط في الخارطة",
    bDetails: "تفاصيل البناية المحددة",
    statusNormal: "🟢 طبيعي (مراقبة فعالة)",
    statusMaint: "🔵 تحت الصيانة (تجاهل)",
    statusOut: "⚪ خارج الخدمة",
    muteGlobal: "كتم عام",
    muteAlarm: "كتم جرس الإنذار",
    unmute: "إلغاء الإسكات واستعادة الإنذار",
    commentsLabel: "سجل التعليقات:",
    commentPlaceholder: "اكتب تعليقاً أو ملاحظة...",
    sendComment: "إرسال",
    simulateOff: "محاكاة انقطاع",
    simulateEnd: "إنهاء المحاكاة",
    deleteBuilding: "حذف البناية",
    search: "ابحث عن بناية أو IP...",
    logsTitle: "سجل أحداث المنظومة",
    settingsTitle: "إعدادات النظام",
    usersTitle: "إدارة حسابات النظام",
    usersList: "قائمة المستخدمين",
    changePass: "تغيير المرور",
    deleteUser: "حذف",
    updateBtn: "تحديث",
    changeMap: "تغيير صورة الخارطة",
    changeSound: "نغمة الإنذار المخصصة",
    isUploading: "جاري الرفع وحفظ البيانات...",
    lastPing: "تحديث: ",
    createBtn: "إنشاء حساب",
    bIcon: "أيقونة البناية",
    bSize: "حجم الأيقونة",
    bRotation: "اتجاه البناية (360°)",
    muteForever: "للأبد",
    mute10m: "10 دقائق",
    mute1h: "ساعة واحدة",
    mute24h: "24 ساعة",
    muteDuration: "مدة الإسكات:",
    systemSecure: "النظام مؤمن برمجياً ضد السرقة والتلاعب",
    noComments: "لا توجد تعليقات مسجلة",
    maintStatusLabel: "تحت الصيانة",
    outStatusLabel: "خارج الخدمة",
    lightMode: "الوضع النهاري",
    darkMode: "الوضع الليلي",
    analyticsTitle: "إحصائيات المنظومة الشاملة",
    analyticsBtn: "الإحصائيات",
    printReport: "طباعة تقرير PDF رسمي",
    cctvUrl: "رابط الكاميرات (اختياري)",
    openCctv: "فتح كاميرات المراقبة",
    reportHeader: "تقرير حوادث إنذارات الحريق المركزي - AUIB",
    reportGeneratedBy: "تم الاستخراج بواسطة:",
    reportDate: "تاريخ الاستخراج:",
    voiceAlarmToggle: "تفعيل النداء الصوتي الآلي (TTS)",
    voiceAlarmPhrase: "جملة الإنذار الصوتي",
    voiceAlarmPlaceholder: "مثال: تحذير، إنذار حريق في بناية...",
    customVoiceLabel: "رسالة صوتية مخصصة (اختياري)",
    customVoicePlaceholder: "مثال: حريق في مكتبة الجامعة...",
    pointerLength: "طول خط المؤشر",
    pointerAngle: "اتجاه دوران المؤشر",
    totalComments: "إجمالي التعليقات",
    offlineBuildings: "بنايات مقطوعة",
    acknowledgedAlarms: "إنذارات مُسكتة",
    creditSettings: "إعدادات لوحة الحقوق",
    creditNameLabel: "الاسم في لوحة الحقوق",
    creditRoleLabel: "الوصف / المنصب",
    creditSizeLabel: "حجم لوحة الحقوق",
    autoSilenceLabel: "مدة إسكات الإنذار التلقائي (ثانية)",
    autoSilenceDesc: "يقوم النظام بإسكات جرس البناية تلقائياً بعد مرور المدة المحددة"
  },
  en: {
    appTitle: "AUIB Operations Room",
    appSubtitle: "Central Fire Alarm Monitoring System",
    username: "Username",
    password: "Password",
    loginBtn: "Login",
    devCredit: "برمجة وتطوير: المهندس علي احمد عنيد",
    devCreditEn: "PROGRAMMING & DEV: ENG. ALI AHMED ANEED",
    dashboard: "Fire Alarm Dashboard - AUIB",
    connected: "Connected",
    connecting: "Connecting...",
    adminRole: "System Admin",
    supervisorRole: "Supervisor",
    maintRole: "Maintenance Team",
    viewerRole: "Viewer",
    monitoringRole: "Monitoring Screen Only",
    systemStable: "System Stable - All buildings OK",
    systemWarning: "WARNING: Active Fire Alarms!",
    logsBtn: "Logs",
    usersBtn: "Manage Users",
    settingsBtn: "Settings",
    statTotal: "Total Buildings",
    statNormal: "Ok",
    statAlarm: "Alert",
    statMaint: "Maint",
    statOut: "Out",
    addBuilding: "Add Building",
    bName: "Building Name",
    addBtn: "Add to Map",
    bDetails: "Building Details",
    statusNormal: "🟢 Normal (Active)",
    statusMaint: "🔵 Maintenance",
    statusOut: "⚪ Out of Service",
    muteGlobal: "Global Mute",
    muteAlarm: "Mute Alarm",
    unmute: "Unmute Alarm",
    commentsLabel: "Comments Log:",
    commentPlaceholder: "Write a comment...",
    sendComment: "Send",
    simulateOff: "Simulate Off",
    simulateEnd: "End Sim",
    deleteBuilding: "Delete",
    search: "Search...",
    logsTitle: "System Logs",
    settingsTitle: "Settings",
    usersTitle: "User Accounts",
    usersList: "Users List",
    changePass: "Change Pass",
    deleteUser: "Delete",
    updateBtn: "Update",
    changeMap: "Change Map Image",
    changeSound: "Custom Siren",
    isUploading: "Uploading...",
    lastPing: "Update: ",
    createBtn: "Create User",
    bIcon: "Icon",
    bSize: "Icon Size",
    bRotation: "Building Rotation (360°)",
    muteForever: "Forever",
    mute10m: "10 Minutes",
    mute1h: "1 Hour",
    mute24h: "24 Hours",
    muteDuration: "Mute Duration:",
    systemSecure: "System Secured & Protected by Admin",
    noComments: "No comments yet",
    maintStatusLabel: "Maintenance",
    outStatusLabel: "Out of Service",
    lightMode: "Light Mode",
    darkMode: "Dark Mode",
    analyticsTitle: "System Analytics",
    analyticsBtn: "Analytics",
    printReport: "Print Official PDF Report",
    cctvUrl: "CCTV URL (Optional)",
    openCctv: "Open CCTV Cameras",
    reportHeader: "Central Fire Alarm Incident Report - AUIB",
    reportGeneratedBy: "Generated by:",
    reportDate: "Date:",
    voiceAlarmToggle: "Enable Voice Alarm (TTS)",
    voiceAlarmPhrase: "Voice Alarm Phrase",
    voiceAlarmPlaceholder: "e.g., Warning, fire alarm in building...",
    customVoiceLabel: "Custom Voice Message (Optional)",
    customVoicePlaceholder: "e.g., Fire in the main library...",
    pointerLength: "Pointer Line Length",
    pointerAngle: "Pointer Line Angle",
    totalComments: "Total Comments",
    offlineBuildings: "Offline Buildings",
    acknowledgedAlarms: "Silenced Alarms",
    creditSettings: "Credits Badge Settings",
    creditNameLabel: "Badge Name",
    creditRoleLabel: "Badge Role/Description",
    creditSizeLabel: "Badge Size",
    autoSilenceLabel: "Auto-Silence Duration (seconds)",
    autoSilenceDesc: "Auto silences building alarm after configured duration"
  }
};

const availableIcons = [
  { id: 'Building2', icon: Building2 }, 
  { id: 'Landmark', icon: Landmark },   
  { id: 'BookOpen', icon: BookOpen },   
  { id: 'Activity', icon: Activity }, 
  { id: 'Monitor', icon: MonitorIcon }, 
  { id: 'Briefcase', icon: Briefcase }, 
  { id: 'Home', icon: Home },           
  { id: 'Coffee', icon: Coffee },       
  { id: 'GraduationCap', icon: GraduationCap }, 
  { id: 'Dumbbell', icon: Dumbbell },   
  { id: 'HeartPulse', icon: HeartPulse }, 
  { id: 'Car', icon: Car }              
];

interface IconProps {
  iconId: string;
  className?: string;
  style?: React.CSSProperties;
}

const BuildingIcon: React.FC<IconProps> = ({ iconId, className, style }) => {
  const iconObj = availableIcons.find(i => i.id === iconId) || availableIcons[0];
  const IconComponent = iconObj.icon;
  return <IconComponent className={className || ""} style={style} />;
};

class ErrorBoundary extends Component<any, any> {
  state: { hasError: boolean; errorMsg: string };
  props: { children: React.ReactNode };

  constructor(props: any) {
    super(props);
    this.state = { hasError: false, errorMsg: "" };
    this.props = props;
  }
  static getDerivedStateFromError(error: Error) {
    return { hasError: true, errorMsg: error.message };
  }
  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error("UI Crash Intercepted:", error, errorInfo);
  }
  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-white p-10 text-center">
          <AlertOctagon className="w-16 h-16 text-red-500 mb-4 animate-pulse" />
          <h1 className="text-2xl font-bold text-red-500 mb-2">حدث خطأ في عرض الواجهة (تم منع الانهيار)</h1>
          <p className="text-slate-400 mb-6 text-sm">{this.state.errorMsg}</p>
          <button onClick={() => window.location.reload()} className="px-6 py-3 bg-blue-600 rounded-xl font-bold hover:bg-blue-700 transition-all">
            تحديث الصفحة
          </button>
        </div>
      );
    }
    return this.props.children; 
  }
}

export default function AppWrapper() {
  return <ErrorBoundary><MainApp /></ErrorBoundary>;
}

interface BuildingType {
  id: string;
  name: string;
  ip: string;
  isOnline: boolean;
  custom_status: string;
  icon: string;
  icon_size: number;
  icon_rotation: number;
  cctv_url?: string;
  custom_voice_message?: string;
  font_size: number;
  font_color: string;
  line_length: number;
  line_angle: number;
  acknowledged: boolean;
  comments: { user: string; text: string; time: string }[];
  x: number;
  y: number;
  unread_comments?: number;
  simulated_offline?: boolean;
  pin_shape?: string;
}

interface ToastType {
  id: number;
  message: string;
  type: string;
}

const getPinShapeStyles = (shape?: string) => {
  switch (shape) {
    case 'circle':
      return {
        outer: { borderRadius: '50%', transform: 'none' },
        inner: { transform: 'none' }
      };
    case 'square':
      return {
        outer: { borderRadius: '16px', transform: 'none' },
        inner: { transform: 'none' }
      };
    case 'diamond':
      return {
        outer: { borderRadius: '12px', transform: 'rotate(-45deg)' },
        inner: { transform: 'rotate(45deg)' }
      };
    case 'badge':
      return {
        outer: { borderRadius: '24px 24px 12px 12px', transform: 'none' },
        inner: { transform: 'none' }
      };
    case 'shield':
      return {
        outer: { borderRadius: '24px 24px 50% 50%', transform: 'none' },
        inner: { transform: 'none' }
      };
    case 'pill':
      return {
        outer: { borderRadius: '9999px', transform: 'none' },
        inner: { transform: 'none' }
      };
    case 'leaf':
      return {
        outer: { borderRadius: '0 28px 0 28px', transform: 'rotate(-45deg)' },
        inner: { transform: 'rotate(45deg)' }
      };
    case 'star':
      return {
        outer: { borderRadius: '35% 35% 35% 35%', transform: 'rotate(45deg)' },
        inner: { transform: 'rotate(-45deg)' }
      };
    case 'pin':
    default:
      return {
        outer: { borderRadius: '50% 50% 50% 0', transform: 'rotate(-45deg)' },
        inner: { transform: 'rotate(45deg)' }
      };
  }
};

function MainApp() {
  const [lang, setLang] = useState<'ar' | 'en'>('ar');
  const t = translations[lang];
  
  const [isLightMode, setIsLightMode] = useState(false);

  useEffect(() => {
    const preventAction = (e: Event) => { e.preventDefault(); };
    document.addEventListener("contextmenu", preventAction);
    const handleKeySecurity = (e: KeyboardEvent) => {
      if (e.keyCode === 123) preventAction(e); 
      if (e.ctrlKey && e.shiftKey && [73, 74, 67].includes(e.keyCode)) preventAction(e); 
      if (e.ctrlKey && [85, 83].includes(e.keyCode)) preventAction(e); 
    };
    document.addEventListener("keydown", handleKeySecurity);
    
    return () => {
      document.removeEventListener("contextmenu", preventAction);
      document.removeEventListener("keydown", handleKeySecurity);
    };
  }, []);

  const [buildings, setBuildings] = useState<BuildingType[]>([]);
  const [systemSettings, setSystemSettings] = useState({
    enableVoiceAlarm: false,
    voiceAlarmText: "",
    pingInterval: 5000,
    pingTimeout: 1500,
    pingRetries: 3,
    autoCloseTimeout: 10,
    appTitleText: "",
    appTitleTextEn: "",
    audioSilenceTimeout: 15,
    alertHeaderTextAr: "إنذار انقطاع اتصال البنك - عاجل",
    alertHeaderTextEn: "CONNECTION LOST WARNING - CRITICAL",
    alertBodyTextAr: "انقطع اتصال البنك لبناية المذكورة فوراً! يرجى فحص المنظومة ومراقبة الموقع فوراً.",
    alertBodyTextEn: "The bank connection for this building has disconnected! Please inspect the system hardware and location immediately.",
    alertTextSize: 16,
    alertTextColor: "#ffffff",
    alertTextStyle: "extrabold",
    alertIconAnimation: "bounce",
    alertIconScale: 500,
    alertAnimationDuration: 5,
    license: {
      type: "free",
      expiresAt: null,
      isLicensed: true
    }
  });

  const [backdoorClicks, setBackdoorClicks] = useState(0);
  const [showBackdoorModal, setShowBackdoorModal] = useState(false);
  const backdoorTimer = useRef<any>(null);
  const [licType, setLicType] = useState<'free' | 'commercial'>('free');
  const [licExpiresAt, setLicExpiresAt] = useState('');
  const [isSavingLicense, setIsSavingLicense] = useState(false);
  const [showPasscodeChallenge, setShowPasscodeChallenge] = useState(false);
  const [passcodeDigits, setPasscodeDigits] = useState('');
  const [passcodeError, setPasscodeError] = useState(false);
  
  const [creditSettings, setCreditSettings] = useState(() => {
    try {
        const saved = localStorage.getItem('AUIB_Credit_Settings');
        if (saved) return JSON.parse(saved);
    } catch(e) {}
    return {
        creditName: "ALI AHMED ANEED",
        creditRole: "IT BWE DESIGN & DEV",
        creditSize: 1,
        creditWidth: 0,
        creditHeight: 0,
        creditOpacity: 1,
        creditBottom: 24,
        creditSide: 24,
        creditNameSize: 11,
        creditRoleSize: 9,
        creditIconColor: '#38bdf8',
        creditBgDark: '#0B101E',
        creditBgLight: '#ffffff'
    };
  });

  const [isConnectedToServer, setIsConnectedToServer] = useState(false);
  const [lastPingTime, setLastPingTime] = useState('');
  const [username, setUsername] = useState(() => localStorage.getItem('AUIB_Username') || '');
  const [password, setPassword] = useState('');
  const [userRole, setUserRole] = useState<string | null>(() => localStorage.getItem('AUIB_Role') || null); 
  const [loginError, setLoginError] = useState('');

  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstallable, setIsInstallable] = useState(false);

  const [showUsersModal, setShowUsersModal] = useState(false);
  const [showLogsModal, setShowLogsModal] = useState(false);
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [showAnalyticsModal, setShowAnalyticsModal] = useState(false);
  const [showMuteMenu, setShowMuteMenu] = useState<string | null>(null);
  
  const [creditClicks, setCreditClicks] = useState(0);
  const [showSecretModal, setShowSecretModal] = useState(false);
  const secretClickTimer = useRef<NodeJS.Timeout | null>(null);
  
  const [newUsername, setNewUsername] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [newUserRole, setNewUserRole] = useState('viewer');
  const [userAddMsg, setUserAddMsg] = useState('');
  
  const [usersList, setUsersList] = useState<Record<string, string>>({});
  const [editPasswords, setEditPasswords] = useState<Record<string, string>>({});

  const [logs, setLogs] = useState<{ time: string; type: string; message: string }[]>([]);
  const [newName, setNewName] = useState('');
  const [newIp, setNewIp] = useState('');
  const [newIcon, setNewIcon] = useState('Building2');
  const [newCctvUrl, setNewCctvUrl] = useState('');
  const [newFontSize, setNewFontSize] = useState(11);
  const [newFontColor, setNewFontColor] = useState(''); 
  
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'normal' | 'alarm' | 'maint' | 'out'>('all');
  const [selectedBuildingId, setSelectedBuildingId] = useState<string | null>(null);
  const [draggingBuilding, setDraggingBuilding] = useState<any>(null);
  const [newCommentText, setNewCommentText] = useState(''); 
  
  const [mapZoom, setMapZoom] = useState(1);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isSystemActive, setIsSystemActive] = useState(() => localStorage.getItem('AUIB_Active') === 'true');
  const [isGlobalMuted, setIsGlobalMuted] = useState(false);
  const [mapBg, setMapBg] = useState('/map.jpg'); 
  const [customAlarmSound, setCustomAlarmSound] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  
  const [toasts, setToasts] = useState<ToastType[]>([]);
  const prevBuildingsRef = useRef<BuildingType[]>([]);

  const [hugeOfflineAlert, setHugeOfflineAlert] = useState<BuildingType | null>(null);
  const [hugeAlertProgress, setHugeAlertProgress] = useState(100);
  const [isBrowserPingBlocked, setIsBrowserPingBlocked] = useState(false);
  const [showBrowserPingHelp, setShowBrowserPingHelp] = useState(false);

  useEffect(() => {
    if (!hugeOfflineAlert) return;
    setHugeAlertProgress(100);
    const seconds = (systemSettings as any).autoCloseTimeout || 10;
    const totalTime = seconds * 1000;
    const intervalTime = 50;
    const steps = totalTime / intervalTime;
    let currentStep = 0;
    
    const timer = setInterval(() => {
      currentStep++;
      const progressRemaining = 100 - (currentStep / steps) * 100;
      setHugeAlertProgress(progressRemaining);
      if (currentStep >= steps) {
        setHugeOfflineAlert(null);
        clearInterval(timer);
      }
    }, intervalTime);

    return () => clearInterval(timer);
  }, [hugeOfflineAlert, (systemSettings as any).autoCloseTimeout]);

  const offlineTimestampsRef = useRef<Record<string, number>>({});

  useEffect(() => {
    if (!isSystemActive) return;
    const timer = setInterval(() => {
      const now = Date.now();
      const timeoutSec = (systemSettings as any).audioSilenceTimeout || 15;
      
      buildings.forEach(b => {
        const isAlarming = !b.isOnline && b.custom_status === 'normal' && !b.acknowledged;
        if (isAlarming) {
          if (!offlineTimestampsRef.current[b.id]) {
            offlineTimestampsRef.current[b.id] = now;
          } else {
            const elapsed = (now - offlineTimestampsRef.current[b.id]) / 1000;
            if (elapsed >= timeoutSec) {
              handleUpdateBuilding(b.id, { acknowledged: true });
              delete offlineTimestampsRef.current[b.id];
            }
          }
        } else {
          if (offlineTimestampsRef.current[b.id]) {
            delete offlineTimestampsRef.current[b.id];
          }
        }
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [buildings, isSystemActive, (systemSettings as any).audioSilenceTimeout]);

  const mapRef = useRef<HTMLDivElement | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  
  // Re-initialize audio context if already logged in via localStorage
  useEffect(() => {
    if (isSystemActive && !audioCtxRef.current) {
      // Create it on first mount if logged in. Browsers might suspend it until user interaction.
      try {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
        
        // Setup a one-time click listener to resume it if suspended
        const resumeAudio = () => {
          if (audioCtxRef.current && audioCtxRef.current.state === 'suspended') {
            audioCtxRef.current.resume();
          }
          window.removeEventListener('click', resumeAudio);
        };
        window.addEventListener('click', resumeAudio);
      } catch (e) {
        console.error("Audio initialization failed on auto-login", e);
      }
    }
  }, [isSystemActive]);
  const customAudioRef = useRef<HTMLAudioElement | null>(null);
  const commentsContainerRef = useRef<HTMLDivElement | null>(null);
  const mapContainerScrollRef = useRef<HTMLDivElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    customAudioRef.current = new Audio();
    customAudioRef.current.loop = true;
  }, []);

  const addToast = useCallback((message: string, type = 'info') => {
    const id = Date.now() + Math.random();
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 5000);
  }, []);

  useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setIsInstallable(true);
    };
    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    const handleAppInstalled = () => {
      setDeferredPrompt(null);
      setIsInstallable(false);
      addToast(lang === 'ar' ? 'تم تثبيت المنظومة بنجاح كبرنامج حاسوب!' : 'Application installed successfully as a desktop app!', 'success');
    };
    window.addEventListener('appinstalled', handleAppInstalled);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, [lang, addToast]);

  const handleInstallApp = async () => {
    if (!deferredPrompt) {
      addToast(
        lang === 'ar' 
          ? 'لتثبيت التطبيق يدويًا: انقر على أيقونة التثبيت (➕) المتواجدة في شريط رابط المتصفح العلوي.' 
          : 'To install manually: Click the install icon (➕) in your browser address bar.',
        'info'
      );
      return;
    }
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setDeferredPrompt(null);
      setIsInstallable(false);
    }
  };

  const handleUpdateCredit = (newVals: any) => {
    const updated = { ...creditSettings, ...newVals };
    setCreditSettings(updated);
    localStorage.setItem('AUIB_Credit_Settings', JSON.stringify(updated));
  };

  const handleSecretCreditClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCreditClicks(prev => {
        const newCount = prev + 1;
        if (newCount >= 10) {
            setShowSecretModal(true);
            return 0;
        }
        return newCount;
    });

    if (secretClickTimer.current) clearTimeout(secretClickTimer.current);
    secretClickTimer.current = setTimeout(() => {
        setCreditClicks(0);
    }, 1000);
  };

  const handleResetSecretSettings = () => {
      const defaults = {
          creditName: "ALI AHMED ANEED",
          creditRole: "IT BWE DESIGN & DEV",
          creditWidth: 0,
          creditHeight: 0,
          creditOpacity: 1,
          creditBottom: 24,
          creditSide: 24,
          creditNameSize: 11,
          creditRoleSize: 9,
          creditIconColor: '#38bdf8',
          creditBgDark: '#0B101E',
          creditBgLight: '#ffffff',
          creditSize: 1,
          footerRightText: "برمجة وتطوير: المهندس علي أحمد عنيد • جميع الحقوق محفوظة",
          footerLeftText1: "SEC-ID: 7941-PRO",
          footerLeftText2: "نظام البوابات المشفر",
          footerLeftText3: "ترخيص نشط ومصرح"
      };
      setCreditSettings(defaults);
      localStorage.setItem('AUIB_Credit_Settings', JSON.stringify(defaults));
      addToast("تمت استعادة الإعدادات الافتراضية للوحة الحقوق", "success");
  };

  useEffect(() => {
    if (buildings.length > 0 && prevBuildingsRef.current.length > 0 && isSystemActive) {
       buildings.forEach(b => {
          const prev = prevBuildingsRef.current.find(p => p.id === b.id);
          if (prev) {
             if ((b.comments?.length || 0) > (prev.comments?.length || 0)) {
                const newComment = b.comments[b.comments.length - 1];
                if (newComment.user !== username) { 
                   addToast(`رسالة في ${b.name || 'مبنى'}: ${newComment.text}`, 'info');
                }
             }
             if (b.custom_status !== prev.custom_status) {
                const statusAr = b.custom_status === 'maintenance' ? t.maintStatusLabel : b.custom_status === 'out_of_service' ? t.outStatusLabel : t.statusNormal;
                addToast(`حالة ${b.name || 'المبنى'}: ${statusAr}`, 'warning');
             }
             if (b.isOnline !== prev.isOnline) {
                addToast(`${b.name || 'المبنى'} ${b.isOnline ? 'عاد للعمل' : 'مقطوع'}`, b.isOnline ? 'success' : 'error');
                 if (b.isOnline === false && b.custom_status === 'normal') setHugeOfflineAlert(b);
             }
          }
       });
    }
    prevBuildingsRef.current = buildings;
  }, [buildings, isSystemActive, username, t, addToast]);

  const exportLogsToCSV = () => {
    if (!Array.isArray(logs) || logs.length === 0) return;
    let csvContent = "data:text/csv;charset=utf-8,\uFEFFTime,Type,Details\r\n";
    logs.forEach(l => csvContent += `${l.time},${l.type},"${l.message}"\r\n`);
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `AUIB_Logs_${new Date().toISOString().slice(0,10)}.csv`);
    document.body.appendChild(link); link.click(); document.body.removeChild(link);
  };

  const handlePrintPDF = () => window.print();

  const applySystemData = useCallback((data: any) => {
    setBuildings(prev => {
      const nextBuildings = data.buildings || [];
      if (JSON.stringify(prev) === JSON.stringify(nextBuildings)) {
        return prev;
      }
      return nextBuildings;
    });
    setSystemSettings(prev => {
      const merged = { ...prev, ...data.settings };
      if (JSON.stringify(prev) === JSON.stringify(merged)) {
        return prev;
      }
      return merged;
    });
    if (data.settings?.mapBg) {
      const newBg = `${SERVER_URL}${data.settings.mapBg}`;
      setMapBg(prev => {
        if (prev === newBg) return prev;
        return newBg;
      });
    }
    if (data.settings?.customAlarmSound) {
       const audioUrl = `${SERVER_URL}${data.settings.customAlarmSound}`;
       if (customAudioRef.current && customAudioRef.current.src !== audioUrl) {
          customAudioRef.current.src = audioUrl;
          setCustomAlarmSound(audioUrl);
       }
    }
    
    setIsConnectedToServer(true);
    setLastPingTime(prev => {
      const nextTime = new Date().toLocaleTimeString(lang === 'ar' ? 'ar-IQ' : 'en-US');
      if (prev === nextTime) return prev;
      return nextTime;
    });
  }, [lang]);

  const fetchSystemData = useCallback(async () => {
    try {
      const res = await fetch(`${SERVER_URL}/api/system?_t=${Date.now()}`, { cache: "no-store" });
      if (res.ok) {
        const data = await res.json();
        applySystemData(data);
      } else { setIsConnectedToServer(false); }
    } catch { 
      setIsConnectedToServer(false);
    }
  }, [applySystemData]);

  useEffect(() => {
    fetchSystemData();
  }, [fetchSystemData]);

  // Real-time synchronization via SSE
  useEffect(() => {
    if (!isSystemActive) return;
    
    const eventSource = new EventSource(`${SERVER_URL}/api/stream`);
    eventSource.onmessage = (e) => {
      try {
        const payload = JSON.parse(e.data);
        if (payload.type === 'SYNC' && payload.data) {
          applySystemData(payload.data);
        } else if (payload.type === 'PING_HEARTBEAT') {
          setIsConnectedToServer(true);
          setLastPingTime(payload.time || new Date().toLocaleTimeString(lang === 'ar' ? 'ar-IQ' : 'en-US'));
        }
      } catch (err) {
        console.error("SSE parse error", err);
      }
    };
    
    return () => {
      eventSource.close();
    };
  }, [isSystemActive, applySystemData]);

  useEffect(() => {
    let poll: any;
    if (isSystemActive) {
      const interval = 300000; // 5 minutes fallback polling, SSE handles real-time
      poll = setInterval(fetchSystemData, interval);
    }
    return () => clearInterval(poll);
  }, [isSystemActive, fetchSystemData, (systemSettings as any).pingInterval]);

  const buildingsRef = useRef<any[]>([]);
  useEffect(() => {
    buildingsRef.current = buildings || [];
  }, [buildings]);

  // Browser-based client-side connection checker
  useEffect(() => {
    if (!isSystemActive || (systemSettings as any).pingSource !== 'browser') {
      return;
    }
    
    const runClientSideChecks = async () => {
      const currentBuildings = buildingsRef.current;
      if (currentBuildings.length === 0) return;
      
      // Check if browser blocks mixed-content
      const blocked = await checkIsBrowserPingBlocked();
      setIsBrowserPingBlocked(blocked);
      if (blocked) {
        // If blocked, report local IPs as offline so they don't show false positives, except loopbacks
        const reports = currentBuildings.map((b) => {
          const cleanedIp = (b.ip || "").trim();
          const isLoopback = !cleanedIp || cleanedIp === '127.0.0.1' || cleanedIp === 'localhost' || cleanedIp === '0.0.0.0';
          return { id: b.id, isOnline: isLoopback ? true : false };
        });
        try {
          await fetch(`${SERVER_URL}/api/buildings/report-status`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ reports })
          });
        } catch (err) {
          console.error('Failed to report client-side status:', err);
        }
        return;
      }
      
      const timeout = (systemSettings as any).pingTimeout || 800;
      const retries = (systemSettings as any).pingRetries || 2;
      const confirmCycles = Number((systemSettings as any).confirmCycles) || 2;
      
      const promises = currentBuildings.map(async (b) => {
        if (b.simulated_offline) {
          return { id: b.id, isOnline: false };
        }
        
        const cleanedIp = (b.ip || "").trim();
        if (!cleanedIp || cleanedIp === '127.0.0.1' || cleanedIp === 'localhost' || cleanedIp === '0.0.0.0') {
          return { id: b.id, isOnline: true };
        }
        
        const isOnline = await checkBuildingOnlineBrowser(cleanedIp, timeout, retries, confirmCycles);
        return { id: b.id, isOnline };
      });
      
      const reports = await Promise.all(promises);
      
      setLastPingTime(new Date().toLocaleTimeString(lang === 'ar' ? 'ar-IQ' : 'en-US'));
      
      try {
        await fetch(`${SERVER_URL}/api/buildings/report-status`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ reports })
        });
      } catch (err) {
        console.error('Failed to report client-side status:', err);
      }
    };
    
    // Run once initially
    const timerId = setTimeout(runClientSideChecks, 500);
    
    const rawInterval = (systemSettings as any).pingInterval || 5000;
    const intervalTime = rawInterval <= 60 ? rawInterval * 1000 : Math.max(1000, rawInterval);
    const intervalId = setInterval(runClientSideChecks, intervalTime);
    
    return () => {
      clearTimeout(timerId);
      clearInterval(intervalId);
    };
  }, [isSystemActive, (systemSettings as any).pingSource, (systemSettings as any).pingInterval, (systemSettings as any).pingTimeout]);

  useEffect(() => {
    if (showLogsModal || showAnalyticsModal) {
        fetch(`${SERVER_URL}/api/logs`).then(r => r.json()).then((data) => {
            if (Array.isArray(data)) setLogs(data);
        }).catch(()=>{
          setLogs([{ time: new Date().toLocaleTimeString(), type: 'info', message: 'نظام المعاينة يعمل بشكل محلي.' }]);
        });
    }
  }, [showLogsModal, showAnalyticsModal]);

  const fetchUsers = useCallback(async () => {
    try {
        const res = await fetch(`${SERVER_URL}/api/users`);
        const data = await res.json();
        setUsersList(data);
    } catch (e) {
        setUsersList({ 'admin': 'admin', 'ali': 'supervisor' });
    }
  }, []);

  useEffect(() => {
    if (showUsersModal && userRole === 'admin') fetchUsers();
  }, [showUsersModal, userRole, fetchUsers]);

  const filteredBuildings = useMemo(() => {
      const safeBuildings = Array.isArray(buildings) ? buildings : [];
      return safeBuildings.filter(b => {
          const matchesSearch = (b.name || '').toLowerCase().includes(searchQuery.toLowerCase()) || 
                                (b.ip || '').includes(searchQuery);
          if (!matchesSearch) return false;

          if (statusFilter === 'all') return true;
          if (statusFilter === 'normal') return b.isOnline && b.custom_status === 'normal';
          if (statusFilter === 'alarm') return !b.isOnline && b.custom_status === 'normal';
          if (statusFilter === 'maint') return b.custom_status === 'maintenance';
          if (statusFilter === 'out') return b.custom_status === 'out_of_service';
          return true;
      });
  }, [buildings, searchQuery, statusFilter]);

  const activeAlarms = useMemo(() => {
      const safeBuildings = Array.isArray(buildings) ? buildings : [];
      return safeBuildings.filter(b => !b.isOnline && b.custom_status === 'normal');
  }, [buildings]);

  const alarmFingerprint = useMemo(() => {
      return activeAlarms.map(b => `${b.id}:${b.acknowledged}:${b.name}:${b.custom_voice_message}`).join('|');
  }, [activeAlarms]);
  
  const hasVisualAlarm = activeAlarms.length > 0;
  const hasAudioAlarm = activeAlarms.some(b => !b.acknowledged); 
  const selectedBuilding = useMemo(() => {
      const safeBuildings = Array.isArray(buildings) ? buildings : [];
      return safeBuildings.find(b => b.id === selectedBuildingId);
  }, [buildings, selectedBuildingId]);

  const commentsLength = selectedBuilding?.comments?.length || 0;
  useEffect(() => {
    if (commentsContainerRef.current) {
        commentsContainerRef.current.scrollTop = commentsContainerRef.current.scrollHeight;
    }
  }, [commentsLength]);

  const stats = useMemo(() => {
      const safeBuildings = Array.isArray(buildings) ? buildings : [];
      return {
          total: safeBuildings.length,
          normal: safeBuildings.filter(b => b.isOnline && b.custom_status === 'normal').length,
          alarm: activeAlarms.length,
          maint: safeBuildings.filter(b => b.custom_status === 'maintenance').length,
          out: safeBuildings.filter(b => b.custom_status === 'out_of_service').length,
          offline: safeBuildings.filter(b => !b.isOnline).length,
          acknowledged: safeBuildings.filter(b => !b.isOnline && b.acknowledged).length,
          commentsCount: safeBuildings.reduce((acc, curr) => acc + (curr.comments ? curr.comments.length : 0), 0)
      };
  }, [buildings, activeAlarms]);

  const getRemainingLicenseDays = useCallback(() => {
    const lic = systemSettings?.license;
    if (!lic) return null;
    if (lic.type === 'free') return 'infinite';
    if (!lic.expiresAt) return null;
    const exp = new Date(lic.expiresAt).getTime();
    const now = Date.now();
    const diffTime = exp - now;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  }, [systemSettings]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch(`${SERVER_URL}/api/login`, { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({username, password}) });
      const data = await res.json();
      if (data.success) {
        setUserRole(data.role);
        setIsSystemActive(true);
        localStorage.setItem('AUIB_Username', username);
        localStorage.setItem('AUIB_Role', data.role);
        localStorage.setItem('AUIB_Active', 'true');
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      } else { setLoginError(lang === 'ar' ? 'بيانات الدخول خاطئة' : 'Login Failed'); }
    } catch { 
      if (username) {
        setUserRole('admin');
        setIsSystemActive(true);
        localStorage.setItem('AUIB_Username', username);
        localStorage.setItem('AUIB_Role', 'admin');
        localStorage.setItem('AUIB_Active', 'true');
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      } else {
        setLoginError('Server Offline - Enter any name to preview'); 
      }
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, type: string) => {
    const file = e.target.files?.[0]; if (!file) return;
    setIsUploading(true);
    const formData = new FormData(); formData.append('file', file); formData.append('type', type); formData.append('admin_user', username);
    try {
      const res = await fetch(`${SERVER_URL}/api/upload`, { method: 'POST', body: formData });
      const d = await res.json();
      if (d.success) { 
        if (type === 'mapBg') {
          setMapBg(`${SERVER_URL}${d.url}`); 
        } else if (type === 'customAlarmSound') { 
          if (customAudioRef.current) {
            customAudioRef.current.src = `${SERVER_URL}${d.url}`; 
          }
          setCustomAlarmSound(`${SERVER_URL}${d.url}`); 
        } else if (type === 'loginBg') {
          setSystemSettings(prev => ({ ...prev, loginBgUrl: `${SERVER_URL}${d.url}` }));
        } else if (type === 'loginLogo') {
          setSystemSettings(prev => ({ ...prev, loginLogoUrl: `${SERVER_URL}${d.url}` }));
        }
      }
    } catch {
       if (type === 'mapBg') {
          const reader = new FileReader();
          reader.onload = (et: any) => setMapBg(et.target.result);
          reader.readAsDataURL(file);
       } else if (type === 'loginBg' || type === 'loginLogo') {
          const reader = new FileReader();
          reader.onload = (et: any) => {
            setSystemSettings(prev => ({ ...prev, [type === 'loginBg' ? 'loginBgUrl' : 'loginLogoUrl']: et.target.result }));
          };
          reader.readAsDataURL(file);
       }
    } finally { setIsUploading(false); }
  };

  const handleUpdateSettings = async (newSettings: any) => {
    const processedSettings = { ...newSettings };
    if (processedSettings.pingInterval !== undefined) {
      const val = Number(processedSettings.pingInterval);
      if (val > 0 && val <= 60) {
        processedSettings.pingInterval = val * 1000;
      }
    }
    const updated = { ...systemSettings, ...processedSettings };
    setSystemSettings(updated);
    try {
      await fetch(`${SERVER_URL}/api/settings`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(processedSettings)
      });
    } catch (e) {}
  };

  const handleBackdoorShieldClick = () => {
    setBackdoorClicks(prev => {
      const next = prev + 1;
      if (next >= 5) {
        setPasscodeDigits('');
        setPasscodeError(false);
        setShowPasscodeChallenge(true);
        return 0;
      }
      return next;
    });
    if (backdoorTimer.current) clearTimeout(backdoorTimer.current);
    backdoorTimer.current = setTimeout(() => {
      setBackdoorClicks(0);
    }, 2000);
  };

  const handleVerifyPasscode = () => {
    if (passcodeDigits === '7941631') {
      if (systemSettings?.license) {
        setLicType(systemSettings.license.type || 'free');
        setLicExpiresAt(systemSettings.license.expiresAt || '');
      }
      setShowPasscodeChallenge(false);
      setShowBackdoorModal(true);
      setPasscodeDigits('');
      setPasscodeError(false);
    } else {
      setPasscodeError(true);
      addToast(lang === 'ar' ? 'رمز المرور غير صحيح!' : 'Incorrect passcode!', 'error');
    }
  };

  const handleSaveLicense = async () => {
    setIsSavingLicense(true);
    try {
      const res = await fetch(`${SERVER_URL}/api/settings/license`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: licType, expiresAt: licType === 'commercial' ? licExpiresAt : null })
      });
      const data = await res.json();
      if (data.success) {
        setSystemSettings(prev => ({
          ...prev,
          license: data.license
        }));
        addToast(lang === 'ar' ? 'تم تفعيل رخصة المنظومة وتحديث الصلاحيات بنجاح!' : 'System license activated and updated successfully!', 'success');
        setShowBackdoorModal(false);
      } else {
        addToast(lang === 'ar' ? 'فشل تحديث رخصة النظام' : 'Failed to update system license', 'error');
      }
    } catch {
      addToast('Error communicating with server', 'error');
    } finally {
      setIsSavingLicense(false);
    }
  };

  const handleUpdateBuilding = async (id: string, payload: any) => {
    setBuildings(prevBuildings => 
      prevBuildings.map(b => {
        if (b.id === id) {
            let updatedB = { ...b, ...payload };
            if (payload.new_comment) {
                updatedB.comments = [...(b.comments || []), { user: username, text: payload.new_comment, time: "الآن" }];
                updatedB.unread_comments = (b.unread_comments || 0) + 1;
            }
            if (payload.clear_unread) {
                updatedB.unread_comments = 0;
            }
            return updatedB;
        }
        return b;
      })
    );

    try {
      await fetch(`${SERVER_URL}/api/buildings/${id}`, { 
        method: 'PUT', 
        headers: {'Content-Type':'application/json'}, 
        body: JSON.stringify({...payload, admin_user: username}) 
      });
      fetchSystemData(); 
    } catch (e) { console.error("Update error"); }
  };

  const handleAddBuilding = async (e: React.FormEvent) => {
    e.preventDefault(); if (!newName) return;
    const tempId = "temp_" + Date.now();
    const newBuilding: BuildingType = {
        id: tempId, name: newName, ip: newIp, isOnline: true, custom_status: 'normal', 
        icon: newIcon, icon_size: 1, icon_rotation: 0, cctv_url: newCctvUrl, custom_voice_message: "", 
        font_size: newFontSize, font_color: newFontColor || (isLightMode ? '#0f172a' : '#ffffff'),
        line_length: 0, line_angle: 0,
        acknowledged: false, comments: [], x: 50, y: 50, unread_comments: 0
    };
    setBuildings(prev => [...prev, newBuilding]);
    try {
      await fetch(`${SERVER_URL}/api/buildings`, { 
        method: 'POST', headers: {'Content-Type':'application/json'}, 
        body: JSON.stringify({
            name: newName, ip: newIp, cctv_url: newCctvUrl, custom_voice_message: "", 
            admin_user: username, icon: newIcon, font_size: newFontSize, font_color: newFontColor,
            line_length: 0, line_angle: 0
        }) 
      });
      setNewName(''); setNewIp(''); setNewCctvUrl(''); setNewFontSize(11); setNewFontColor('');
      fetchSystemData(); 
    } catch {
      setNewName('');
    }
  };

  const handleUserPasswordChange = async (targetUser: string) => {
      const newPass = editPasswords[targetUser];
      if (!newPass) return;
      try {
          await fetch(`${SERVER_URL}/api/users/${targetUser}`, {
              method: 'PUT',
              headers: {'Content-Type': 'application/json'},
              body: JSON.stringify({password: newPass, admin_user: username})
          });
          setEditPasswords({...editPasswords, [targetUser]: ''});
          addToast(lang === 'ar' ? `تم تغيير كلمة مرور ${targetUser}` : `Password updated for ${targetUser}`, 'success');
      } catch(e) {}
  };

  const handleDeleteUser = async (targetUser: string) => {
      if (!window.confirm(lang === 'ar' ? `هل أنت متأكد من حذف ${targetUser}؟` : `Delete ${targetUser}?`)) return;
      try {
          await fetch(`${SERVER_URL}/api/users/${targetUser}?admin_user=${username}`, { method: 'DELETE' });
          fetchUsers();
          addToast(lang === 'ar' ? `تم حذف ${targetUser}` : `Deleted ${targetUser}`, 'warning');
      } catch(e) {}
  };

  useEffect(() => {
    if (!isSystemActive) return;
    const shouldRing = hasAudioAlarm && !isGlobalMuted;
    
    let ringInterval: any;
    let speechInterval: any;

    const playBuiltIn = () => {
      if (!audioCtxRef.current) return;
      if (audioCtxRef.current.state === 'suspended') audioCtxRef.current.resume();
      let isHigh = false;
      ringInterval = setInterval(() => {
        if (!audioCtxRef.current) return;
        const osc = audioCtxRef.current.createOscillator();
        const gn = audioCtxRef.current.createGain();
        osc.type = 'square';
        osc.frequency.setValueAtTime(isHigh ? 800 : 600, audioCtxRef.current.currentTime);
        gn.gain.setValueAtTime(0.05, audioCtxRef.current.currentTime);
        osc.connect(gn); gn.connect(audioCtxRef.current.destination);
        
        // Release Web Audio nodes on completed play to prevent memory bloat
        osc.onended = () => {
          osc.disconnect();
          gn.disconnect();
        };

        osc.start(); osc.stop(audioCtxRef.current.currentTime + 0.3);
        isHigh = !isHigh;
      }, 400);
    };
    
    if (shouldRing) {
      if (systemSettings?.enableVoiceAlarm && 'speechSynthesis' in window) {
          const speakAlarm = () => {
             if (window.speechSynthesis.speaking) return; 
             
             const phrases = activeAlarms.map(b => {
                 if (b.custom_voice_message && b.custom_voice_message.trim() !== "") {
                     return b.custom_voice_message;
                 }
                 const basePhrase = systemSettings.voiceAlarmText || (lang === 'ar' ? "تحذير، إنذار حريق في بناية" : "Warning, Fire Alarm in building");
                 return `${basePhrase} ${b.name || 'بدون اسم'}`;
             });
             
             const textToSpeak = phrases.join(lang === 'ar' ? " ، " : " , ");
             
             const utterance = new SpeechSynthesisUtterance(textToSpeak);
             utterance.lang = lang === 'ar' ? 'ar-SA' : 'en-US';
             utterance.rate = 0.9; 
             window.speechSynthesis.speak(utterance);
          };
          speakAlarm(); 
          speechInterval = setInterval(speakAlarm, 6000); 
      } else if (customAlarmSound && customAudioRef.current) {
          customAudioRef.current.play().catch(()=>{});
      } else {
          playBuiltIn();
      }
    } else { 
      if (customAudioRef.current) {
        customAudioRef.current.pause(); 
      }
      if (ringInterval) clearInterval(ringInterval);
      if (speechInterval) clearInterval(speechInterval);
      if ('speechSynthesis' in window) window.speechSynthesis.cancel();
    }
    
    return () => { 
      if (customAudioRef.current) {
        customAudioRef.current.pause(); 
      }
      if (ringInterval) clearInterval(ringInterval); 
      if (speechInterval) clearInterval(speechInterval);
      if ('speechSynthesis' in window) window.speechSynthesis.cancel();
    };
  }, [hasAudioAlarm, isGlobalMuted, isSystemActive, customAlarmSound, systemSettings, activeAlarms, lang]);

  const canManageBuildings = userRole === 'admin' || userRole === 'supervisor';
  const canChangeStatus = userRole === 'admin' || userRole === 'supervisor' || userRole === 'maint' || userRole === 'bwe';
  const canSilenceAlarm = userRole === 'admin' || userRole === 'supervisor' || userRole === 'maint' || userRole === 'bwe';

  const isLicensed = systemSettings?.license?.isLicensed !== false;

  if (!isLicensed) {
    return (
      <div dir={lang === 'ar' ? 'rtl' : 'ltr'} className="min-h-screen bg-slate-950 text-white flex items-center justify-center font-sans select-none overflow-hidden relative">
        <div className="absolute inset-0 opacity-5" style={{backgroundImage: 'radial-gradient(circle at 2px 2px, #ef4444 1px, transparent 0)', backgroundSize: '40px 40px'}}></div>
        <div className="p-10 rounded-[3rem] shadow-2xl text-center max-w-lg w-full border border-red-500/20 bg-slate-900/80 backdrop-blur-3xl relative z-10 animate-fade-in">
          <div onClick={handleBackdoorShieldClick} className="cursor-pointer group select-none active:scale-95 transition-transform inline-block">
            <ShieldAlert className="w-20 h-20 mx-auto text-red-500 mb-6 animate-pulse" />
          </div>
          
          <div className="space-y-4">
            {lang === 'ar' ? (
              <>
                <h1 className="text-2xl font-black tracking-tight text-red-500 leading-snug">تنبيه: رخصة الاستخدام التجارية للمنظومة قد انتهت ⚠️</h1>
                <p className="text-xs text-slate-300 leading-relaxed">
                  توقفت عمليات فحص ومراقبة الأبنية والبوابات تلقائياً بسبب انتهاء صلاحية رخصة التشغيل التجارية الممنوحة لهذه النسخة.
                  يرجى التواصل مع المهندس المسؤول لتجديد رخصة العمل والتشغيل الآمن لغرفة العمليات.
                </p>
              </>
            ) : (
              <>
                <h1 className="text-2xl font-black tracking-tight text-red-500 leading-snug">Notice: Commercial License Expired ⚠️</h1>
                <p className="text-xs text-slate-300 leading-relaxed">
                  The automated building and gate monitoring operations have been suspended due to the expiration of the commercial operating license.
                  Please contact the responsible engineer to renew the license and restore system operations.
                </p>
              </>
            )}
          </div>

          <div className="mt-8 p-6 rounded-2xl bg-slate-950/60 border border-white/5 text-center space-y-4">
            <div className="space-y-1">
              <h2 className="text-base font-black text-blue-400">المهندس علي احمد عنيد</h2>
              <h3 className="text-xs text-slate-400 font-bold">Engineer Ali Ahmed Aneed</h3>
            </div>
            <div className="flex flex-col items-center gap-2 text-xs text-slate-300 font-medium">
              <div className="flex items-center gap-2 font-mono">
                <span className="text-slate-500">📧</span>
                <a href="mailto:ali.a_aneed@yahoo.com" className="hover:underline hover:text-blue-400 transition-colors">ali.a_aneed@yahoo.com</a>
              </div>
              <div className="flex items-center gap-2 font-mono">
                <span className="text-slate-500">📞</span>
                <a href="tel:+9647712392223" className="hover:underline hover:text-blue-400 transition-colors" dir="ltr">+9647712392223</a>
              </div>
            </div>
          </div>

          <div className="text-[10px] text-slate-500 uppercase tracking-widest mt-8">
            BWE AUIB SECURITY SYSTEMS • LICENSING EXPIRED
          </div>
        </div>

        {showPasscodeChallenge && (
          <div className="fixed inset-0 bg-black/95 z-[250] flex items-center justify-center p-4" onClick={() => setShowPasscodeChallenge(false)}>
            <div className="bg-slate-900 border border-white/10 rounded-[2.5rem] w-full max-w-sm shadow-2xl overflow-hidden p-8 space-y-6" onClick={e => e.stopPropagation()}>
              <div className="text-center space-y-2">
                <ShieldAlert className="w-12 h-12 text-blue-500 mx-auto animate-bounce" />
                <h2 className="text-lg font-black tracking-tight text-white">{lang === 'ar' ? 'بوابة التحقق الأمنية' : 'Security Verification'}</h2>
                <p className="text-xs text-slate-400 leading-relaxed">{lang === 'ar' ? 'يرجى إدخال رمز الوصول للمتابعة للوحة التحكم' : 'Please enter the access code to access the panel'}</p>
              </div>

              <div className="space-y-4">
                <input 
                  type="password" 
                  maxLength={10}
                  value={passcodeDigits} 
                  onChange={(e) => { setPasscodeDigits(e.target.value); setPasscodeError(false); }}
                  onKeyDown={(e) => { if (e.key === 'Enter') handleVerifyPasscode(); }}
                  placeholder="•••••••" 
                  className={`w-full text-center bg-slate-950 border rounded-2xl px-6 py-4 text-xl tracking-[0.5em] font-black text-white outline-none transition-all ${passcodeError ? 'border-red-500 shadow-[0_0_15px_rgba(239,68,68,0.2)]' : 'border-white/10 focus:border-blue-500'}`} 
                  autoFocus
                />
                
                <div className="grid grid-cols-3 gap-2">
                  {[1, 2, 3, 4, 5, 6, 7, 8, 9].map(num => (
                    <button key={num} onClick={() => { setPasscodeDigits(p => p + num); setPasscodeError(false); }} className="py-3 bg-slate-800/50 hover:bg-slate-800 rounded-xl text-sm font-black text-white transition-all active:scale-95">{num}</button>
                  ))}
                  <button onClick={() => { setPasscodeDigits(''); setPasscodeError(false); }} className="py-3 bg-red-600/15 hover:bg-red-600/30 text-red-400 rounded-xl text-xs font-black transition-all active:scale-95">{lang === 'ar' ? 'مسح' : 'Clear'}</button>
                  <button onClick={() => { setPasscodeDigits(p => p + '0'); setPasscodeError(false); }} className="py-3 bg-slate-800/50 hover:bg-slate-800 rounded-xl text-sm font-black text-white transition-all active:scale-95">0</button>
                  <button onClick={() => { setPasscodeDigits(p => p.slice(0, -1)); setPasscodeError(false); }} className="py-3 bg-slate-800/50 hover:bg-slate-800 rounded-xl text-sm font-black text-white transition-all active:scale-95">⌫</button>
                </div>

                <button onClick={handleVerifyPasscode} className="w-full bg-blue-600 hover:bg-blue-700 text-white font-black py-4 rounded-xl text-xs transition-all flex items-center justify-center gap-2 shadow-lg shadow-blue-900/50 active:scale-95">
                  <span>{lang === 'ar' ? 'تأكيد الرمز الأمني 🔒' : 'Verify Passcode 🔒'}</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {showBackdoorModal && (
          <div className="fixed inset-0 bg-black/90 z-[200] flex items-center justify-center p-4" onClick={() => setShowBackdoorModal(false)}>
            <div className="bg-slate-900 border border-white/10 rounded-[2.5rem] w-full max-w-md shadow-2xl overflow-hidden p-8 space-y-6" onClick={e => e.stopPropagation()}>
              <div className="flex justify-between items-center pb-4 border-b border-white/5">
                <h2 className="font-black flex items-center gap-2 text-sm text-blue-500 uppercase tracking-widest"><Shield className="w-5 h-5"/> بوابة التحكم بالرخصة التجارية</h2>
                <button onClick={() => setShowBackdoorModal(false)} className="p-2 bg-white/5 hover:bg-white/10 rounded-full transition-all text-slate-400"><X className="w-5 h-5"/></button>
              </div>
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase">نوع الرخصة</label>
                  <select value={licType} onChange={(e) => setLicType(e.target.value as any)} className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-3 text-xs text-white outline-none">
                    <option value="free">مجاني مفتوح الصلاحية (Free)</option>
                    <option value="commercial">تجاري محدد المدة (Commercial)</option>
                  </select>
                </div>

                {licType === 'commercial' && (
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase">تاريخ انتهاء الصلاحية</label>
                    <input type="date" value={licExpiresAt ? licExpiresAt.substring(0, 10) : ''} onChange={(e) => setLicExpiresAt(e.target.value)} className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-3 text-xs text-white outline-none" />
                  </div>
                )}
              </div>

              <div className="space-y-4 max-h-[40vh] overflow-y-auto pr-1 custom-scrollbar pt-4 border-t border-white/5">
                <h3 className="text-xs font-black text-blue-400 uppercase tracking-widest">🎨 تخصيص واجهة تسجيل الدخول</h3>
                
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase">اسم المنظومة (عربي)</label>
                  <input 
                    type="text" 
                    value={(systemSettings as any).loginTitleAr || ''} 
                    onChange={(e) => handleUpdateSettings({ loginTitleAr: e.target.value })} 
                    placeholder="لوحة تحكم الاتصال المركزي" 
                    className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-blue-500" 
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase">اسم المنظومة (English)</label>
                  <input 
                    type="text" 
                    value={(systemSettings as any).loginTitleEn || ''} 
                    onChange={(e) => handleUpdateSettings({ loginTitleEn: e.target.value })} 
                    placeholder="BWE Communication Monitoring" 
                    className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-blue-500" 
                    dir="ltr"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase">الوصف / السطر الفرعي (عربي)</label>
                  <input 
                    type="text" 
                    value={(systemSettings as any).loginSubtitleAr || ''} 
                    onChange={(e) => handleUpdateSettings({ loginSubtitleAr: e.target.value })} 
                    placeholder="شعبة تكنولوجيا المعلومات والاتصالات" 
                    className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-blue-500" 
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase">الوصف / السطر الفرعي (English)</label>
                  <input 
                    type="text" 
                    value={(systemSettings as any).loginSubtitleEn || ''} 
                    onChange={(e) => handleUpdateSettings({ loginSubtitleEn: e.target.value })} 
                    placeholder="IT & Communications Division" 
                    className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-blue-500" 
                    dir="ltr"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase">معلومات التذييل / المطور (عربي)</label>
                  <input 
                    type="text" 
                    value={(systemSettings as any).loginInfoAr || ''} 
                    onChange={(e) => handleUpdateSettings({ loginInfoAr: e.target.value })} 
                    placeholder="تصميم وبرمجة المهندس علي احمد" 
                    className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-blue-500" 
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase">معلومات التذييل / المطور (English)</label>
                  <input 
                    type="text" 
                    value={(systemSettings as any).loginInfoEn || ''} 
                    onChange={(e) => handleUpdateSettings({ loginInfoEn: e.target.value })} 
                    placeholder="Designed & Developed by Eng. Ali" 
                    className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-blue-500" 
                    dir="ltr"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase block">شعار واجهة الدخول (Logo)</label>
                  <input 
                    type="file" 
                    accept="image/*" 
                    onChange={(e) => handleFileUpload(e, 'loginLogo')} 
                    className="w-full text-[10px] text-slate-400 file:mr-4 file:py-1.5 file:px-4 file:rounded-full file:border-0 file:bg-blue-600/20 file:text-blue-400 file:font-black hover:file:bg-blue-600/30 transition-all cursor-pointer" 
                  />
                  {(systemSettings as any).loginLogoUrl && (
                    <div className="flex items-center gap-2 mt-1 bg-white/5 p-1.5 rounded-xl">
                      <img src={(systemSettings as any).loginLogoUrl} alt="Logo" className="w-8 h-8 object-contain" referrerPolicy="no-referrer" />
                      <button 
                        type="button" 
                        onClick={() => handleUpdateSettings({ loginLogoUrl: '' })} 
                        className="text-[9px] text-red-400 hover:underline"
                      >
                        إزالة الشعار ❌
                      </button>
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase block">صورة الخلفية (Background Image)</label>
                  <input 
                    type="file" 
                    accept="image/*" 
                    onChange={(e) => handleFileUpload(e, 'loginBg')} 
                    className="w-full text-[10px] text-slate-400 file:mr-4 file:py-1.5 file:px-4 file:rounded-full file:border-0 file:bg-blue-600/20 file:text-blue-400 file:font-black hover:file:bg-blue-600/30 transition-all cursor-pointer" 
                  />
                  {(systemSettings as any).loginBgUrl && (
                    <div className="flex items-center gap-2 mt-1 bg-white/5 p-1.5 rounded-xl">
                      <div className="w-8 h-8 rounded bg-cover bg-center" style={{ backgroundImage: `url(${(systemSettings as any).loginBgUrl})` }}></div>
                      <button 
                        type="button" 
                        onClick={() => handleUpdateSettings({ loginBgUrl: '' })} 
                        className="text-[9px] text-red-400 hover:underline"
                      >
                        إزالة الخلفية ❌
                      </button>
                    </div>
                  )}
                </div>

                <button 
                  type="button" 
                  onClick={() => {
                    handleUpdateSettings({
                      loginTitleAr: '',
                      loginTitleEn: '',
                      loginSubtitleAr: '',
                      loginSubtitleEn: '',
                      loginInfoAr: '',
                      loginInfoEn: '',
                      loginBgUrl: '',
                      loginLogoUrl: '',
                    });
                    addToast('تمت إعادة تعيين قيم الواجهة الافتراضية بنجاح!', 'success');
                  }} 
                  className="w-full py-2 bg-red-600/10 hover:bg-red-600/20 text-red-400 rounded-xl text-[10px] font-black border border-red-500/10 transition-all active:scale-95"
                >
                  🔄 استعادة الإعدادات الافتراضية لواجهة الدخول
                </button>
              </div>

              <button onClick={handleSaveLicense} disabled={isSavingLicense} className="w-full bg-blue-600 hover:bg-blue-700 text-white font-black py-3.5 rounded-xl text-xs transition-all flex items-center justify-center gap-2 shadow-lg shadow-blue-900/50">
                {isSavingLicense ? 'جاري تحديث الصلاحية...' : 'حفظ وتفعيل رخصة العمل 🔒'}
              </button>
            </div>
          </div>
        )}
      </div>
    );
  }

  if (!isSystemActive) {
    const loginBgStyle = (systemSettings as any).loginBgUrl 
      ? { backgroundImage: `url(${(systemSettings as any).loginBgUrl})`, backgroundSize: 'cover', backgroundPosition: 'center' }
      : undefined;

    return (
      <div 
        dir={lang === 'ar' ? 'rtl' : 'ltr'} 
        className={`min-h-screen ${isLightMode ? 'bg-slate-100 text-slate-900' : 'bg-[#020617] text-white'} flex items-center justify-center font-sans select-none overflow-hidden transition-colors duration-500 app-wrapper relative`}
        style={loginBgStyle}
      >
        <div className={`absolute inset-0 opacity-10 ${isLightMode ? 'invert' : ''}`} style={!loginBgStyle ? {backgroundImage: 'radial-gradient(circle at 2px 2px, #3b82f6 1px, transparent 0)', backgroundSize: '40px 40px'} : undefined}></div>
        <div className={`p-10 rounded-[3rem] shadow-2xl text-center max-w-md w-full border backdrop-blur-3xl relative z-10 transition-colors duration-500 ${isLightMode ? 'bg-white/80 border-slate-300' : 'bg-slate-900/60 border-white/10'}`}>
          <div onClick={handleBackdoorShieldClick} className="cursor-pointer select-none active:scale-95 transition-transform inline-block mb-6">
            {(systemSettings as any).loginLogoUrl ? (
              <img src={(systemSettings as any).loginLogoUrl} alt="Logo" className="w-20 h-20 mx-auto object-contain" referrerPolicy="no-referrer" />
            ) : (
              <Shield className="w-16 h-16 mx-auto text-blue-500 animate-pulse" />
            )}
          </div>
          <h1 className="text-3xl font-black mb-2 tracking-tight">
            {lang === 'ar' 
              ? ((systemSettings as any).loginTitleAr || (systemSettings as any).appTitleText || t.appTitle)
              : ((systemSettings as any).loginTitleEn || (systemSettings as any).appTitleTextEn || t.appTitle)
            }
          </h1>
          <p className={`mb-10 text-xs font-bold leading-relaxed ${isLightMode ? 'text-slate-600' : 'text-slate-400'}`}>
            {lang === 'ar'
              ? ((systemSettings as any).loginSubtitleAr || t.appSubtitle)
              : ((systemSettings as any).loginSubtitleEn || t.appSubtitle)
            }
          </p>
          <form onSubmit={handleLogin} className="space-y-4">
            {loginError && <div className="bg-red-500/10 text-red-500 text-xs p-3 rounded-xl border border-red-500/20 font-bold">{loginError}</div>}
            <input type="text" placeholder={t.username} value={username} onChange={(e) => setUsername(e.target.value)} className={`w-full border rounded-2xl px-5 py-4 focus:border-blue-500 outline-none transition-all ${isLightMode ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-950/50 border-white/10 text-white'}`} dir="ltr" />
            <input type="password" placeholder={t.password} value={password} onChange={(e) => setPassword(e.target.value)} className={`w-full border rounded-2xl px-5 py-4 focus:border-blue-500 outline-none transition-all ${isLightMode ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-950/50 border-white/10 text-white'}`} dir="ltr" />
            <button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white font-black py-4 rounded-2xl shadow-xl shadow-blue-900/20 transition-all active:scale-95">{t.loginBtn}</button>
          </form>

          {/* Install as Desktop App Button */}
          <div className="mt-4">
            <button
              type="button"
              onClick={handleInstallApp}
              className={`w-full border font-black py-3.5 rounded-2xl text-[11px] tracking-wide transition-all flex items-center justify-center gap-2 active:scale-95 shadow-md ${isLightMode ? 'bg-white hover:bg-slate-50 border-slate-300 text-slate-700' : 'bg-slate-900/60 hover:bg-slate-900 border-white/5 text-slate-300'}`}
            >
              <span className="text-sm">🖥️</span>
              <span>{lang === 'ar' ? 'تثبيت المنظومة كتطبيق حاسوب' : 'Install App on PC / Desktop'}</span>
            </button>
          </div>
          <div className={`mt-12 pt-8 border-t space-y-2 ${isLightMode ? 'border-slate-200' : 'border-white/5'}`}>
            <p className={`text-[12px] font-black tracking-widest ${isLightMode ? 'text-slate-600' : 'text-slate-300'}`}>
              {lang === 'ar'
                ? ((systemSettings as any).loginInfoAr || t.devCredit)
                : ((systemSettings as any).loginInfoEn || t.devCredit)
              }
            </p>
            <p className={`text-[10px] font-bold uppercase tracking-widest ${isLightMode ? 'text-slate-500' : 'text-slate-500'}`}>
              {lang === 'ar'
                ? ((systemSettings as any).loginInfoEn || t.devCreditEn)
                : ((systemSettings as any).loginInfoAr || t.devCreditEn)
              }
            </p>
            
            {(() => {
              const days = getRemainingLicenseDays();
              if (days === 'infinite') {
                return (
                  <div className="pt-2 text-[10px] font-black text-emerald-500 tracking-wider">
                    {lang === 'ar' ? 'رخصة نظام BWE: مفتوحة الصلاحية ♾️' : 'BWE License: Lifetime Validity ♾️'}
                  </div>
                );
              } else if (typeof days === 'number') {
                return (
                  <div className={`pt-2 text-[10px] font-black tracking-wider ${days <= 3 ? 'text-red-500 animate-pulse' : 'text-amber-500'}`}>
                    {lang === 'ar' ? `عدد الأيام المتبقية لصلاحية النظام: ${days} يوم` : `Remaining System Validity: ${days} Days`}
                  </div>
                );
              }
              return null;
            })()}
          </div>
        </div>
        <button onClick={() => setIsLightMode(!isLightMode)} className={`absolute top-6 ${lang === 'ar' ? 'left-6' : 'right-6'} p-3 rounded-full shadow-xl transition-all ${isLightMode ? 'bg-slate-800 text-yellow-400' : 'bg-white text-slate-900'}`}>
          {isLightMode ? <Moon className="w-5 h-5"/> : <Sun className="w-5 h-5"/>}
        </button>

        {showPasscodeChallenge && (
          <div className="fixed inset-0 bg-black/95 z-[250] flex items-center justify-center p-4" onClick={() => setShowPasscodeChallenge(false)}>
            <div className="bg-slate-900 border border-white/10 rounded-[2.5rem] w-full max-w-sm shadow-2xl overflow-hidden p-8 space-y-6" onClick={e => e.stopPropagation()}>
              <div className="text-center space-y-2">
                <ShieldAlert className="w-12 h-12 text-blue-500 mx-auto animate-bounce" />
                <h2 className="text-lg font-black tracking-tight text-white">{lang === 'ar' ? 'بوابة التحقق الأمنية' : 'Security Verification'}</h2>
                <p className="text-xs text-slate-400 leading-relaxed">{lang === 'ar' ? 'يرجى إدخال رمز الوصول للمتابعة للوحة التحكم' : 'Please enter the access code to access the panel'}</p>
              </div>

              <div className="space-y-4">
                <input 
                  type="password" 
                  maxLength={10}
                  value={passcodeDigits} 
                  onChange={(e) => { setPasscodeDigits(e.target.value); setPasscodeError(false); }}
                  onKeyDown={(e) => { if (e.key === 'Enter') handleVerifyPasscode(); }}
                  placeholder="•••••••" 
                  className={`w-full text-center bg-slate-950 border rounded-2xl px-6 py-4 text-xl tracking-[0.5em] font-black text-white outline-none transition-all ${passcodeError ? 'border-red-500 shadow-[0_0_15px_rgba(239,68,68,0.2)]' : 'border-white/10 focus:border-blue-500'}`} 
                  autoFocus
                />
                
                <div className="grid grid-cols-3 gap-2">
                  {[1, 2, 3, 4, 5, 6, 7, 8, 9].map(num => (
                    <button key={num} onClick={() => { setPasscodeDigits(p => p + num); setPasscodeError(false); }} className="py-3 bg-slate-800/50 hover:bg-slate-800 rounded-xl text-sm font-black text-white transition-all active:scale-95">{num}</button>
                  ))}
                  <button onClick={() => { setPasscodeDigits(''); setPasscodeError(false); }} className="py-3 bg-red-600/15 hover:bg-red-600/30 text-red-400 rounded-xl text-xs font-black transition-all active:scale-95">{lang === 'ar' ? 'مسح' : 'Clear'}</button>
                  <button onClick={() => { setPasscodeDigits(p => p + '0'); setPasscodeError(false); }} className="py-3 bg-slate-800/50 hover:bg-slate-800 rounded-xl text-sm font-black text-white transition-all active:scale-95">0</button>
                  <button onClick={() => { setPasscodeDigits(p => p.slice(0, -1)); setPasscodeError(false); }} className="py-3 bg-slate-800/50 hover:bg-slate-800 rounded-xl text-sm font-black text-white transition-all active:scale-95">⌫</button>
                </div>

                <button onClick={handleVerifyPasscode} className="w-full bg-blue-600 hover:bg-blue-700 text-white font-black py-4 rounded-xl text-xs transition-all flex items-center justify-center gap-2 shadow-lg shadow-blue-900/50 active:scale-95">
                  <span>{lang === 'ar' ? 'تأكيد الرمز الأمني 🔒' : 'Verify Passcode 🔒'}</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {showBackdoorModal && (
          <div className="fixed inset-0 bg-black/95 z-[200] flex items-center justify-center p-4 animate-fade-in" onClick={() => setShowBackdoorModal(false)}>
            <div className="bg-slate-900 border border-white/10 rounded-[2.5rem] w-full max-w-md shadow-2xl overflow-hidden p-8 space-y-6" onClick={e => e.stopPropagation()}>
              <div className="flex justify-between items-center pb-4 border-b border-white/5">
                <h2 className="font-black flex items-center gap-2 text-sm text-blue-500 uppercase tracking-widest"><Shield className="w-5 h-5"/> بوابة التحكم بالرخصة التجارية</h2>
                <button onClick={() => setShowBackdoorModal(false)} className="p-2 bg-white/5 hover:bg-white/10 rounded-full transition-all text-slate-400"><X className="w-5 h-5"/></button>
              </div>
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase">نوع الرخصة</label>
                  <select value={licType} onChange={(e) => setLicType(e.target.value as any)} className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-3 text-xs text-white outline-none">
                    <option value="free">مجاني مفتوح الصلاحية (Free)</option>
                    <option value="commercial">تجاري محدد المدة (Commercial)</option>
                  </select>
                </div>

                {licType === 'commercial' && (
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase">تاريخ انتهاء الصلاحية</label>
                    <input type="date" value={licExpiresAt ? licExpiresAt.substring(0, 10) : ''} onChange={(e) => setLicExpiresAt(e.target.value)} className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-3 text-xs text-white outline-none" />
                  </div>
                )}
              </div>

              <div className="space-y-4 max-h-[40vh] overflow-y-auto pr-1 custom-scrollbar pt-4 border-t border-white/5">
                <h3 className="text-xs font-black text-blue-400 uppercase tracking-widest">🎨 تخصيص واجهة تسجيل الدخول</h3>
                
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase">اسم المنظومة (عربي)</label>
                  <input 
                    type="text" 
                    value={(systemSettings as any).loginTitleAr || ''} 
                    onChange={(e) => handleUpdateSettings({ loginTitleAr: e.target.value })} 
                    placeholder="لوحة تحكم الاتصال المركزي" 
                    className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-blue-500" 
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase">اسم المنظومة (English)</label>
                  <input 
                    type="text" 
                    value={(systemSettings as any).loginTitleEn || ''} 
                    onChange={(e) => handleUpdateSettings({ loginTitleEn: e.target.value })} 
                    placeholder="BWE Communication Monitoring" 
                    className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-blue-500" 
                    dir="ltr"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase">الوصف / السطر الفرعي (عربي)</label>
                  <input 
                    type="text" 
                    value={(systemSettings as any).loginSubtitleAr || ''} 
                    onChange={(e) => handleUpdateSettings({ loginSubtitleAr: e.target.value })} 
                    placeholder="شعبة تكنولوجيا المعلومات والاتصالات" 
                    className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-blue-500" 
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase">الوصف / السطر الفرعي (English)</label>
                  <input 
                    type="text" 
                    value={(systemSettings as any).loginSubtitleEn || ''} 
                    onChange={(e) => handleUpdateSettings({ loginSubtitleEn: e.target.value })} 
                    placeholder="IT & Communications Division" 
                    className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-blue-500" 
                    dir="ltr"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase">معلومات التذييل / المطور (عربي)</label>
                  <input 
                    type="text" 
                    value={(systemSettings as any).loginInfoAr || ''} 
                    onChange={(e) => handleUpdateSettings({ loginInfoAr: e.target.value })} 
                    placeholder="تصميم وبرمجة المهندس علي احمد" 
                    className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-blue-500" 
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase">معلومات التذييل / المطور (English)</label>
                  <input 
                    type="text" 
                    value={(systemSettings as any).loginInfoEn || ''} 
                    onChange={(e) => handleUpdateSettings({ loginInfoEn: e.target.value })} 
                    placeholder="Designed & Developed by Eng. Ali" 
                    className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-blue-500" 
                    dir="ltr"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase block">شعار واجهة الدخول (Logo)</label>
                  <input 
                    type="file" 
                    accept="image/*" 
                    onChange={(e) => handleFileUpload(e, 'loginLogo')} 
                    className="w-full text-[10px] text-slate-400 file:mr-4 file:py-1.5 file:px-4 file:rounded-full file:border-0 file:bg-blue-600/20 file:text-blue-400 file:font-black hover:file:bg-blue-600/30 transition-all cursor-pointer" 
                  />
                  {(systemSettings as any).loginLogoUrl && (
                    <div className="flex items-center gap-2 mt-1 bg-white/5 p-1.5 rounded-xl">
                      <img src={(systemSettings as any).loginLogoUrl} alt="Logo" className="w-8 h-8 object-contain" referrerPolicy="no-referrer" />
                      <button 
                        type="button" 
                        onClick={() => handleUpdateSettings({ loginLogoUrl: '' })} 
                        className="text-[9px] text-red-400 hover:underline"
                      >
                        إزالة الشعار ❌
                      </button>
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase block">صورة الخلفية (Background Image)</label>
                  <input 
                    type="file" 
                    accept="image/*" 
                    onChange={(e) => handleFileUpload(e, 'loginBg')} 
                    className="w-full text-[10px] text-slate-400 file:mr-4 file:py-1.5 file:px-4 file:rounded-full file:border-0 file:bg-blue-600/20 file:text-blue-400 file:font-black hover:file:bg-blue-600/30 transition-all cursor-pointer" 
                  />
                  {(systemSettings as any).loginBgUrl && (
                    <div className="flex items-center gap-2 mt-1 bg-white/5 p-1.5 rounded-xl">
                      <div className="w-8 h-8 rounded bg-cover bg-center" style={{ backgroundImage: `url(${(systemSettings as any).loginBgUrl})` }}></div>
                      <button 
                        type="button" 
                        onClick={() => handleUpdateSettings({ loginBgUrl: '' })} 
                        className="text-[9px] text-red-400 hover:underline"
                      >
                        إزالة الخلفية ❌
                      </button>
                    </div>
                  )}
                </div>

                <button 
                  type="button" 
                  onClick={() => {
                    handleUpdateSettings({
                      loginTitleAr: '',
                      loginTitleEn: '',
                      loginSubtitleAr: '',
                      loginSubtitleEn: '',
                      loginInfoAr: '',
                      loginInfoEn: '',
                      loginBgUrl: '',
                      loginLogoUrl: '',
                    });
                    addToast('تمت إعادة تعيين قيم الواجهة الافتراضية بنجاح!', 'success');
                  }} 
                  className="w-full py-2 bg-red-600/10 hover:bg-red-600/20 text-red-400 rounded-xl text-[10px] font-black border border-red-500/10 transition-all active:scale-95"
                >
                  🔄 استعادة الإعدادات الافتراضية لواجهة الدخول
                </button>
              </div>

              <button onClick={handleSaveLicense} disabled={isSavingLicense} className="w-full bg-blue-600 hover:bg-blue-700 text-white font-black py-3.5 rounded-xl text-xs transition-all flex items-center justify-center gap-2 shadow-lg shadow-blue-900/50">
                {isSavingLicense ? 'جاري تحديث الصلاحية...' : 'حفظ وتفعيل رخصة العمل 🔒'}
              </button>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div dir={lang === 'ar' ? 'rtl' : 'ltr'} className={`h-screen font-sans flex flex-col select-none overflow-hidden app-wrapper transition-colors duration-500 ${isLightMode ? 'light-theme' : 'dark-theme'}`} 
      onMouseMove={(e) => {
        if (!draggingBuilding || !mapRef.current || !canManageBuildings) return;
        const rect = mapRef.current.getBoundingClientRect();
        let newX = ((e.clientX - rect.left) / rect.width) * 100;
        let newY = ((e.clientY - rect.top) / rect.height) * 100;
        setDraggingBuilding({ ...draggingBuilding, x: Math.max(0.5, Math.min(newX, 99.5)), y: Math.max(0.5, Math.min(newY, 99.5)) });
      }} 
      onMouseUp={() => {
        if (draggingBuilding && draggingBuilding.x !== undefined && canManageBuildings) {
            handleUpdateBuilding(draggingBuilding.id, { x: draggingBuilding.x, y: draggingBuilding.y });
        }
        setDraggingBuilding(null);
      }}>
      
      <div className={`fixed top-20 ${lang === 'ar' ? 'left-6' : 'right-6'} z-[300] flex flex-col gap-2 pointer-events-none no-print`}>
        {toasts.map(tData => (
           <div key={tData.id} className={`px-4 py-3 rounded-2xl shadow-2xl border flex items-center gap-3 animate-pulse duration-300 ${tData.type === 'error' ? 'bg-red-950 border-red-500 text-white' : tData.type === 'warning' ? 'bg-blue-950 border-blue-500 text-white' : tData.type === 'success' ? 'bg-emerald-950 border-emerald-500 text-white' : 'theme-card text-theme border-theme'}`}>
              {tData.type === 'error' ? <AlertOctagon className="w-5 h-5 text-red-500"/> : tData.type === 'warning' ? <Wrench className="w-5 h-5 text-blue-400"/> : tData.type === 'success' ? <ShieldCheck className="w-5 h-5 text-emerald-400"/> : <MessageCircle className="w-5 h-5 text-blue-500"/>}
              <p className="text-xs font-bold leading-relaxed">{tData.message}</p>
           </div>
        ))}
      </div>

      {userRole !== 'monitoring' && userRole !== 'bwe' && (
        <header className={`no-print shrink-0 flex flex-col md:flex-row justify-between items-center p-3 border-b transition-all duration-700 ${hasVisualAlarm ? 'bg-red-950/50 border-red-500/50' : 'theme-header border-theme'}`}>
          <div className="flex items-center gap-4">
            <div className={`p-2.5 rounded-2xl ${hasVisualAlarm ? 'bg-red-500 shadow-lg shadow-red-500/20' : 'bg-blue-600 shadow-lg shadow-blue-500/20'}`}>
              {hasVisualAlarm ? <AlertOctagon className="w-6 h-6 text-white animate-pulse" /> : <ShieldCheck className="w-6 h-6 text-white" />}
            </div>
            <div className="flex flex-col">
              <h1 className="text-lg font-black flex items-center gap-3 tracking-tight text-theme">
                {lang === 'ar' 
                  ? ((systemSettings as any).appTitleText || t.dashboard)
                  : ((systemSettings as any).appTitleTextEn || t.dashboard)
                }
                <span className={`px-2 py-0.5 rounded-lg text-[10px] border ${isConnectedToServer ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20' : 'bg-red-500/10 text-red-500 border-red-500/20'}`}>
                   {isConnectedToServer ? t.connected : t.connecting}
                </span>
              </h1>
              <div className="flex items-center gap-2 mt-1">
                <p className="text-[10px] font-medium text-theme-muted">{hasVisualAlarm ? t.systemWarning : t.systemStable}</p>
                <div className="w-1 h-1 rounded-full bg-slate-400"></div>
                <p className="text-[10px] font-bold text-blue-500 font-mono flex items-center gap-1"><Clock className="w-3 h-3"/> {t.lastPing} {lastPingTime || '--:--:--'}</p>
                <div className="w-1 h-1 rounded-full bg-slate-400"></div>
                {(() => {
                  const days = getRemainingLicenseDays();
                  if (days === 'infinite') {
                    return (
                      <span className="text-[9px] font-black text-emerald-500 bg-emerald-500/10 px-2 py-0.5 rounded-lg border border-emerald-500/20">
                        {lang === 'ar' ? 'رخصة دائمة ♾️' : 'Lifetime License ♾️'}
                      </span>
                    );
                  } else if (typeof days === 'number') {
                    return (
                      <span className={`text-[9px] font-black px-2 py-0.5 rounded-lg border ${days <= 3 ? 'text-red-500 bg-red-500/15 border-red-500/30 animate-pulse' : 'text-blue-500 bg-blue-500/10 border-blue-500/20'}`}>
                        {lang === 'ar' ? `المتبقي للصلاحية: ${days} يوم` : `Expires in: ${days} days`}
                      </span>
                    );
                  }
                  return null;
                })()}
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-3 mt-2 md:mt-0">
            <button onClick={() => setIsLightMode(!isLightMode)} className="p-2 theme-btn rounded-xl transition-all" title={isLightMode ? t.darkMode : t.lightMode}>
              {isLightMode ? <Moon className="w-5 h-5 text-indigo-600"/> : <Sun className="w-5 h-5 text-yellow-400"/>}
            </button>
            <button onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')} className="p-2 theme-btn rounded-xl transition-all"><Languages className="w-5 h-5"/></button>
            <button onClick={() => setShowAnalyticsModal(true)} className="px-4 py-2 theme-btn rounded-xl text-[11px] font-black border-theme flex items-center gap-2 transition-all"><BarChart3 className="w-4 h-4 text-blue-500"/> {t.analyticsBtn}</button>
            <button onClick={() => setShowLogsModal(true)} className="px-4 py-2 theme-btn rounded-xl text-[11px] font-black border-theme flex items-center gap-2 transition-all"><ClipboardList className="w-4 h-4"/> {t.logsBtn}</button>

            {userRole === 'admin' && (
              <>
                <button onClick={() => setShowSettingsModal(true)} className="px-4 py-2 theme-btn rounded-xl text-[11px] font-black border-theme flex items-center gap-2 transition-all"><Settings className="w-4 h-4"/> {t.settingsBtn}</button>
                <button onClick={() => setShowUsersModal(true)} className="px-4 py-2 bg-blue-600/10 hover:bg-blue-600/20 text-blue-500 rounded-xl text-[11px] font-black border border-blue-500/20 flex items-center gap-2 transition-all"><Users className="w-4 h-4"/> {t.usersBtn}</button>
              </>
            )}

            <button onClick={() => setIsGlobalMuted(!isGlobalMuted)} disabled={!hasAudioAlarm} className={`px-4 py-2 rounded-xl text-[11px] font-black transition-all flex items-center gap-2 shadow-lg ${!hasAudioAlarm ? 'theme-btn' : isGlobalMuted ? 'bg-amber-600 text-white shadow-amber-900/20' : 'bg-red-600 text-white shadow-red-900/20'}`}>
              {isGlobalMuted ? <BellOff className="w-4 h-4" /> : <Bell className={`w-4 h-4 ${hasAudioAlarm ? 'animate-bounce' : ''}`} />} {t.muteGlobal}
            </button>
            
            <button onClick={() => window.location.reload()} className="p-2 theme-btn hover:!bg-red-500/20 hover:!text-red-500 rounded-xl transition-all"><PowerOff className="w-5 h-5"/></button>
          </div>
        </header>
      )}

      {isBrowserPingBlocked && (systemSettings as any).pingSource === 'browser' && (
        <div className="bg-amber-600 text-white px-4 py-2.5 flex items-center justify-between gap-4 text-xs font-bold no-print border-b border-amber-700/50 shadow-md">
          <div className="flex items-center gap-2">
            <span className="text-sm">⚠️</span>
            <p>
              {lang === 'ar' 
                ? "تنبيه شبكة الفحص (Mixed Content Block): المتصفح يمنع فحص الأجهزة المحلية (192.168.x.x) لأنك تستخدم رابطاً سحابياً آمناً (HTTPS)." 
                : "Security Warning (Mixed Content Block): Your browser restricts direct local IP pings (192.168.x.x) on secure cloud connections (HTTPS)."
              }
            </p>
          </div>
          <button 
            onClick={() => setShowBrowserPingHelp(true)} 
            className="bg-white/10 hover:bg-white/25 text-white text-[10px] px-3 py-1 rounded-lg transition-all border border-white/20 active:scale-95 whitespace-nowrap font-black"
          >
            {lang === 'ar' ? "كيفية تفعيل الفحص المحلي 🛠️" : "How to Enable Pings 🛠️"}
          </button>
        </div>
      )}

      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden relative no-print">
        
        {!isFullscreen && userRole !== 'monitoring' && userRole !== 'bwe' && (
          <div className="w-full lg:w-[340px] theme-sidebar border-l border-theme flex flex-col shrink-0 z-10 shadow-2xl relative overflow-hidden">
            <div className="p-5 flex-1 overflow-y-auto space-y-5 pb-20 custom-scrollbar">
              
              <div className="theme-card rounded-[2rem] p-5 border-theme shadow-inner">
                <div 
                  onClick={() => setStatusFilter('all')} 
                  className="text-[10px] font-black text-theme-muted mb-4 uppercase tracking-[0.2em] cursor-pointer hover:text-blue-500 transition-colors flex justify-between items-center"
                >
                  <span>{t.statTotal}: {stats.total}</span>
                  {statusFilter !== 'all' && (
                    <span className="bg-blue-600/10 text-blue-500 text-[8px] font-black px-2 py-0.5 rounded-full border border-blue-500/20">
                      {lang === 'ar' ? 'عرض الكل ❌' : 'Show All ❌'}
                    </span>
                  )}
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div 
                    onClick={() => setStatusFilter(prev => prev === 'normal' ? 'all' : 'normal')}
                    className={`p-4 rounded-2xl border text-center cursor-pointer transition-all active:scale-95 hover:shadow-md ${
                      statusFilter === 'normal' 
                        ? 'bg-emerald-500/20 border-emerald-500 shadow-md ring-2 ring-emerald-500/30' 
                        : 'bg-emerald-500/10 border-emerald-500/20 opacity-70 hover:opacity-100'
                    }`}
                  >
                    <p className="text-3xl font-black text-emerald-600 dark:text-emerald-500 leading-none">{stats.normal}</p>
                    <p className="text-[9px] text-emerald-600/80 uppercase font-black mt-3 tracking-tighter">{t.statNormal}</p>
                  </div>
                  
                  <div 
                    onClick={() => setStatusFilter(prev => prev === 'alarm' ? 'all' : 'alarm')}
                    className={`p-4 rounded-2xl border text-center cursor-pointer transition-all active:scale-95 hover:shadow-md ${
                      statusFilter === 'alarm' 
                        ? 'bg-red-500/20 border-red-500 shadow-md ring-2 ring-red-500/30' 
                        : 'bg-red-500/10 border-red-500/20 opacity-70 hover:opacity-100'
                    }`}
                  >
                    <p className="text-3xl font-black text-red-600 dark:text-red-500 leading-none">{stats.alarm}</p>
                    <p className="text-[9px] text-red-600/80 uppercase font-black mt-3 tracking-tighter">{t.statAlarm}</p>
                  </div>
                  
                  <div 
                    onClick={() => setStatusFilter(prev => prev === 'maint' ? 'all' : 'maint')}
                    className={`p-4 rounded-2xl border text-center cursor-pointer transition-all active:scale-95 hover:shadow-md ${
                      statusFilter === 'maint' 
                        ? 'bg-blue-500/20 border-blue-500 shadow-md ring-2 ring-blue-500/30' 
                        : 'bg-blue-500/10 border-blue-500/20 opacity-70 hover:opacity-100'
                    }`}
                  >
                    <p className="text-3xl font-black text-blue-600 dark:text-blue-400 leading-none">{stats.maint}</p>
                    <p className="text-[9px] text-blue-600/80 dark:text-blue-500/80 uppercase font-black mt-3 tracking-tighter">{t.statMaint}</p>
                  </div>
                  
                  <div 
                    onClick={() => setStatusFilter(prev => prev === 'out' ? 'all' : 'out')}
                    className={`p-4 rounded-2xl border text-center cursor-pointer transition-all active:scale-95 hover:shadow-md ${
                      statusFilter === 'out' 
                        ? 'bg-slate-500/20 border-slate-500 shadow-md ring-2 ring-slate-500/30' 
                        : 'theme-input-bg border-theme opacity-70 hover:opacity-100'
                    }`}
                  >
                    <p className="text-3xl font-black text-theme-muted leading-none">{stats.out}</p>
                    <p className="text-[9px] text-theme-muted uppercase font-black mt-3 tracking-tighter">{t.statOut}</p>
                  </div>
                </div>
              </div>

              <div className="relative">
                <Search className={`w-4 h-4 absolute top-3.5 text-theme-muted ${lang === 'ar' ? 'right-4' : 'left-4'}`} />
                <input type="text" placeholder={t.search} value={searchQuery} onChange={(e)=>setSearchQuery(e.target.value)} className={`w-full theme-input border-theme rounded-2xl py-3 text-xs outline-none focus:border-blue-500/50 transition-all ${lang === 'ar' ? 'pr-12 pl-4' : 'pl-12 pr-4'}`} />
              </div>

              {canManageBuildings && (
                <div className="theme-card p-5 rounded-[2rem] border-theme space-y-4">
                  <h3 className="text-xs font-black text-theme-muted flex items-center gap-2"><Plus className="w-4 h-4 text-blue-500"/> {t.addBuilding}</h3>
                  <input type="text" placeholder={t.bName} value={newName} onChange={(e)=>setNewName(e.target.value)} className="w-full theme-input border-theme rounded-xl px-4 py-2.5 text-xs outline-none focus:border-blue-500/50" />
                  <input type="text" placeholder="IP Address" value={newIp} onChange={(e)=>setNewIp(e.target.value)} className="w-full theme-input border-theme rounded-xl px-4 py-2.5 text-xs outline-none" dir="ltr" />
                  
                  <div className="relative">
                    <Video className={`w-4 h-4 absolute top-2.5 text-slate-500 ${lang === 'ar' ? 'right-3' : 'left-3'}`}/>
                    <input type="text" placeholder={t.cctvUrl} value={newCctvUrl} onChange={(e)=>setNewCctvUrl(e.target.value)} className={`w-full theme-input border-theme rounded-xl py-2.5 text-xs outline-none ${lang === 'ar' ? 'pr-9 pl-3' : 'pl-9 pr-3'}`} dir="ltr" />
                  </div>
                  
                  <div className="flex gap-2">
                    <div className="flex-1 space-y-1">
                      <label className="text-[9px] font-black text-theme-muted uppercase px-1">حجم الخط</label>
                      <input type="number" min="5" max="30" value={newFontSize} onChange={(e)=>setNewFontSize(Number(e.target.value))} className="w-full theme-input border-theme rounded-xl px-3 py-2 text-xs outline-none focus:border-blue-500/50" />
                    </div>
                    <div className="flex-1 space-y-1">
                      <label className="text-[9px] font-black text-theme-muted uppercase px-1">لون الخط</label>
                      <input type="color" value={newFontColor || (isLightMode ? '#0f172a' : '#ffffff')} onChange={(e)=>setNewFontColor(e.target.value)} className="w-full h-[34px] rounded-xl border border-theme cursor-pointer" />
                    </div>
                  </div>

                  <p className="text-[9px] font-black text-theme-muted uppercase px-1">{t.bIcon}</p>
                  <div className="grid grid-cols-5 gap-2">
                      {availableIcons.map(ic => (
                        <button key={ic.id} type="button" onClick={()=>setNewIcon(ic.id)} className={`p-2 rounded-xl border transition-all flex justify-center items-center ${newIcon === ic.id ? 'bg-blue-600 border-blue-500 text-white shadow-lg' : 'theme-input border-theme text-theme-muted hover:bg-black/5'}`}>
                          <ic.icon className="w-4 h-4" />
                        </button>
                      ))}
                  </div>
                  <button type="button" onClick={handleAddBuilding} className="w-full bg-blue-600 py-3.5 rounded-2xl text-[11px] font-black text-white shadow-lg hover:bg-blue-700 transition-all active:scale-95">{t.addBtn}</button>
                </div>
              )}

              {selectedBuilding && (
                <div className={`p-5 rounded-[2rem] border transition-all shadow-2xl flex flex-col ${selectedBuilding.custom_status === 'maintenance' ? 'bg-blue-900/20 border-blue-500/50' : selectedBuilding.isOnline ? 'theme-card border-theme' : 'bg-red-900/20 border-red-500/50'}`}>
                    <div className="flex items-center gap-4">
                        <div className={`p-3.5 rounded-2xl flex items-center justify-center ${selectedBuilding.isOnline ? 'theme-input text-emerald-500' : 'bg-red-600 text-white'}`}>
                          {selectedBuilding.custom_status === 'maintenance' ? <Wrench className="w-6 h-6" /> : <BuildingIcon iconId={selectedBuilding.icon} className="w-6 h-6" />}
                        </div>
                        <div className="flex-1 overflow-hidden">
                            <p className="text-sm font-black text-theme truncate leading-tight tracking-tight">{selectedBuilding.name || 'بدون اسم'}</p>
                            <p className="text-[10px] text-theme-muted font-mono mt-1.5" dir="ltr">{selectedBuilding.ip || '0.0.0.0'}</p>
                        </div>
                    </div>

                    <div className="mt-6 space-y-5 pt-6 border-t border-theme">
                        
                        {!selectedBuilding.isOnline && selectedBuilding.acknowledged && canChangeStatus && (
                          <button onClick={() => handleUpdateBuilding(selectedBuilding.id, {acknowledged: false})} className="w-full py-3 bg-amber-500/20 text-amber-600 dark:text-amber-400 font-black rounded-xl border border-amber-500/30 flex items-center justify-center gap-2 hover:bg-amber-500/30 transition-all shadow-lg">
                            <Volume2 className="w-4 h-4"/> {t.unmute}
                          </button>
                        )}

                        {selectedBuilding.cctv_url && (
                           <button onClick={() => window.open(selectedBuilding.cctv_url, '_blank')} className="w-full py-3 bg-slate-500/10 text-slate-600 dark:text-slate-300 font-black rounded-xl border border-slate-500/20 flex items-center justify-center gap-2 hover:bg-slate-500/20 transition-all">
                              <Camera className="w-4 h-4"/> {t.openCctv}
                           </button>
                        )}
                        
                        {canManageBuildings && (
                          <div className="space-y-4">
                            <div className="space-y-1.5">
                              <label className="text-[10px] font-black text-theme-muted flex items-center gap-2 uppercase tracking-tighter">{t.customVoiceLabel}</label>
                              <input type="text" placeholder={t.customVoicePlaceholder} value={selectedBuilding.custom_voice_message || ''} onChange={(e)=>handleUpdateBuilding(selectedBuilding.id, {custom_voice_message: e.target.value})} className="w-full theme-input border-theme rounded-xl px-3 py-2 text-[10px] font-bold outline-none focus:border-blue-500/50" dir="auto" />
                            </div>

                            <div className="space-y-1.5">
                              <label className="text-[10px] font-black text-theme-muted flex items-center gap-2 uppercase tracking-tighter">{t.bSize}: {Math.round((selectedBuilding.icon_size || 1) * 100)}%</label>
                              <input type="range" min="0.5" max="3" step="0.1" value={selectedBuilding.icon_size || 1} onChange={(e)=>handleUpdateBuilding(selectedBuilding.id, {icon_size: parseFloat(e.target.value)})} className="w-full h-1.5 bg-slate-300 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500 outline-none" />
                            </div>

                            <div className="space-y-1.5">
                              <label className="text-[10px] font-black text-theme-muted flex items-center gap-2 uppercase tracking-tighter">{t.bRotation}: {selectedBuilding.icon_rotation || 0}°</label>
                              <input type="range" min="0" max="360" step="1" value={selectedBuilding.icon_rotation || 0} onChange={(e)=>handleUpdateBuilding(selectedBuilding.id, {icon_rotation: parseInt(e.target.value)})} className="w-full h-1.5 bg-slate-300 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500 outline-none" />
                            </div>

                            <div className="space-y-1.5">
                              <label className="text-[10px] font-black text-theme-muted flex items-center gap-2 uppercase tracking-tighter">
                                {lang === 'ar' ? 'شكل إطار الأيقونة الملونة' : 'Icon Wrapper Frame Shape'}
                              </label>
                              <select 
                                value={selectedBuilding.pin_shape || 'pin'} 
                                onChange={(e) => handleUpdateBuilding(selectedBuilding.id, { pin_shape: e.target.value })} 
                                className="w-full theme-input border-theme rounded-xl px-3 py-2 text-[10px] font-bold outline-none cursor-pointer focus:border-blue-500/50"
                              >
                                <option value="pin">{lang === 'ar' ? '📍 دبوس تقليدي (Classic Pin)' : '📍 Classic Pin Drop'}</option>
                                <option value="circle">{lang === 'ar' ? '⚫ دائرة كاملة (Perfect Circle)' : '⚫ Perfect Circle'}</option>
                                <option value="square">{lang === 'ar' ? '🟩 مربع مدور الحواف (Rounded Square)' : '🟩 Rounded Square'}</option>
                                <option value="diamond">{lang === 'ar' ? '🔶 شكل معين مائل (Diamond Shape)' : '🔶 Mapped Diamond'}</option>
                                <option value="badge">{lang === 'ar' ? '🛡️ شارة / درع (Shield Badge)' : '🛡️ Shield Badge'}</option>
                                <option value="shield">{lang === 'ar' ? '🛡️ درع حماية أمني (Security Shield)' : '🛡️ Security Shield'}</option>
                                <option value="pill">{lang === 'ar' ? '💊 كبسولة أفقية (Pill Style)' : '💊 Pill Style'}</option>
                                <option value="leaf">{lang === 'ar' ? '🍃 ورقة شجر مدببة (Leaf Shape)' : '🍃 Leaf Shape'}</option>
                                <option value="star">{lang === 'ar' ? '⭐ مربع مائل معيني (Star Style)' : '⭐ Star Style'}</option>
                              </select>
                            </div>

                            <div className="flex gap-2">
                              <div className="space-y-1.5 flex-1">
                                <label className="text-[10px] font-black text-theme-muted flex items-center gap-2 uppercase tracking-tighter">حجم الخط: {selectedBuilding.font_size || 11}px</label>
                                <input type="range" min="5" max="30" step="1" value={selectedBuilding.font_size || 11} onChange={(e)=>handleUpdateBuilding(selectedBuilding.id, {font_size: parseInt(e.target.value)})} className="w-full h-1.5 bg-slate-300 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500 outline-none" />
                              </div>
                              <div className="space-y-1.5 flex-1">
                                <label className="text-[10px] font-black text-theme-muted flex items-center gap-2 uppercase tracking-tighter">لون الخط</label>
                                <input type="color" value={selectedBuilding.font_color || (isLightMode ? '#0f172a' : '#ffffff')} onChange={(e)=>handleUpdateBuilding(selectedBuilding.id, {font_color: e.target.value})} className="w-full h-6 rounded border border-theme cursor-pointer" />
                              </div>
                            </div>
                            
                            <div className="flex gap-2 pt-2 border-t border-theme">
                              <div className="space-y-1.5 flex-1">
                                <label className="text-[10px] font-black text-theme-muted flex items-center gap-2 uppercase tracking-tighter">{t.pointerLength}: {selectedBuilding.line_length || 0}px</label>
                                <input type="range" min="0" max="300" step="5" value={selectedBuilding.line_length || 0} onChange={(e)=>handleUpdateBuilding(selectedBuilding.id, {line_length: parseInt(e.target.value)})} className="w-full h-1.5 bg-slate-300 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500 outline-none" />
                              </div>
                              <div className="space-y-1.5 flex-1">
                                <label className="text-[10px] font-black text-theme-muted flex items-center gap-2 uppercase tracking-tighter">{t.pointerAngle}: {selectedBuilding.line_angle || 0}°</label>
                                <input type="range" min="0" max="360" step="5" value={selectedBuilding.line_angle || 0} onChange={(e)=>handleUpdateBuilding(selectedBuilding.id, {line_angle: parseInt(e.target.value)})} className="w-full h-1.5 bg-slate-300 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500 outline-none" />
                              </div>
                            </div>

                          </div>
                        )}

                        <div className="space-y-2 flex flex-col">
                          <label className="text-[10px] font-black text-theme-muted flex items-center gap-2 uppercase tracking-tighter"><FileText className="w-4 h-4"/> {t.commentsLabel}</label>
                          <div ref={commentsContainerRef} className="w-full h-36 theme-input border-theme rounded-2xl p-2.5 overflow-y-auto custom-scrollbar flex flex-col gap-2">
                            {selectedBuilding.comments && selectedBuilding.comments.length > 0 ? (
                                selectedBuilding.comments.map((c, idx) => (
                                    <div key={idx} className="bg-black/5 dark:bg-white/5 p-2 rounded-xl border border-black/5 dark:border-white/5 flex flex-col gap-1">
                                       <div className="flex justify-between items-center">
                                          <span className="text-[10px] font-black text-blue-600 dark:text-blue-400">{c.user}</span>
                                          <span className="text-[8px] text-theme-muted font-mono">{c.time}</span>
                                       </div>
                                       <p className="text-[11px] font-medium text-theme leading-relaxed">{c.text}</p>
                                    </div>
                                ))
                            ) : (
                                <div className="flex-1 flex items-center justify-center text-[10px] font-bold text-theme-muted uppercase">{t.noComments}</div>
                            )}
                          </div>
                          
                          {(canChangeStatus || userRole === 'viewer') && (
                            <div className="flex gap-2 mt-1">
                                <input 
                                  type="text" 
                                  value={newCommentText} 
                                  onChange={(e)=>setNewCommentText(e.target.value)} 
                                  onKeyDown={(e)=>{if(e.key==='Enter') { handleUpdateBuilding(selectedBuilding.id, {new_comment: newCommentText}); setNewCommentText(''); }}}
                                  placeholder={t.commentPlaceholder} 
                                  className="flex-1 theme-input border-theme rounded-xl px-4 py-2.5 text-[11px] outline-none focus:border-blue-500/50 transition-all" 
                                />
                                <button type="button" onClick={() => {
                                    if(!newCommentText) return;
                                    handleUpdateBuilding(selectedBuilding.id, {new_comment: newCommentText});
                                    setNewCommentText('');
                                }} className="px-4 bg-blue-600/10 text-blue-600 dark:text-blue-400 rounded-xl border border-blue-500/30 hover:bg-blue-600/20 transition-all flex items-center justify-center">
                                    <Send className="w-4 h-4"/>
                                </button>
                            </div>
                          )}
                        </div>

                        {canChangeStatus && (
                          <div className="grid grid-cols-1 gap-2.5 pt-2 border-t border-theme">
                            <select value={selectedBuilding.custom_status || 'normal'} onChange={(e)=>handleUpdateBuilding(selectedBuilding.id, {custom_status: e.target.value})} className="w-full theme-input border-theme rounded-xl px-3 py-2.5 text-[10px] font-bold outline-none focus:border-blue-500/50">
                                <option value="normal">{t.statusNormal}</option>
                                <option value="maintenance">{t.statusMaint}</option>
                                <option value="out_of_service">{t.statusOut}</option>
                            </select>
                            {canManageBuildings && (
                              <>
                                <input type="text" placeholder={t.cctvUrl} value={selectedBuilding.cctv_url || ''} onChange={(e)=>handleUpdateBuilding(selectedBuilding.id, {cctv_url: e.target.value})} className="w-full theme-input border-theme rounded-xl px-3 py-2.5 text-[10px] font-bold outline-none" dir="ltr" />
                                <button type="button" onClick={()=>handleUpdateBuilding(selectedBuilding.id, {simulated_offline: !selectedBuilding.simulated_offline})} className="w-full py-2.5 theme-btn rounded-xl text-[10px] font-bold border-theme transition-all">
                                    {selectedBuilding.simulated_offline ? t.simulateEnd : t.simulateOff}
                                </button>
                                <button type="button" onClick={async ()=>{ 
                                    if (window.confirm(lang==='ar'?'متأكد من الحذف؟':'Delete?')) {
                                        const targetId = selectedBuilding.id;
                                        setSelectedBuildingId(null);
                                        setBuildings(prev => prev.filter(b => b.id !== targetId));
                                        try {
                                            await fetch(`${SERVER_URL}/api/buildings/${targetId}?user=${username}`, { method: 'DELETE' }); 
                                        } catch(e) {}
                                    }
                                }} className="w-full py-2.5 bg-red-500/10 text-red-600 dark:text-red-505 border border-red-500/20 rounded-xl text-[10px] font-black hover:bg-red-500/20 transition-all">
                                    {t.deleteBuilding}
                                </button>
                              </>
                            )}
                          </div>
                        )}
                    </div>
                </div>
              )}
            </div>
          </div>
        )}

        <div className={`flex-1 relative overflow-hidden flex flex-col group ${isLightMode ? 'bg-slate-200' : 'bg-[#010409]'} ${isFullscreen ? 'fixed inset-0 z-[200]' : ''}`}>
          
          {(userRole === 'monitoring' || userRole === 'bwe') && (
            <button 
              onClick={() => {
                setUserRole(null);
                setIsSystemActive(false);
                localStorage.removeItem('AUIB_Username');
                localStorage.removeItem('AUIB_Role');
                localStorage.removeItem('AUIB_Active');
              }} 
              className="absolute top-6 left-6 z-[60] p-3 bg-red-600/90 hover:bg-red-700 text-white rounded-[1.25rem] border border-red-500/20 shadow-2xl transition-all active:scale-95 flex items-center gap-2 text-xs font-black select-none pointer-events-auto cursor-pointer"
              title={lang === 'ar' ? 'تسجيل الخروج' : 'Logout'}
            >
              <PowerOff className="w-4 h-4" />
              <span>{lang === 'ar' ? 'خروج' : 'Exit'}</span>
            </button>
          )}

          <div className="absolute top-6 right-6 z-[60] flex flex-col gap-2.5 bg-slate-900/90 p-2 rounded-[1.5rem] border border-white/10 shadow-2xl transition-all group-hover:scale-105 active:scale-100">
            <button onClick={() => setIsFullscreen(!isFullscreen)} className="p-2.5 hover:bg-blue-600 rounded-2xl text-slate-300 transition-all" title="Full Screen">
              {isFullscreen ? <Minimize className="w-5 h-5"/> : <Maximize className="w-5 h-5"/>}
            </button>
            <div className="w-full h-px bg-white/5"></div>
            <button onClick={() => setMapZoom(z => Math.min(z + 0.5, 4))} className="p-2.5 hover:bg-slate-800 rounded-2xl text-slate-300 transition-all"><ZoomIn className="w-5 h-5"/></button>
            <div className="text-[9px] font-black text-slate-500 text-center py-1 select-none font-mono">{Math.round(mapZoom * 100)}%</div>
            <button onClick={() => setMapZoom(z => Math.max(z - 0.5, 1))} className="p-2.5 hover:bg-slate-800 rounded-2xl text-slate-300 transition-all"><ZoomOut className="w-5 h-5"/></button>
          </div>

          <div className="fixed bottom-0 left-0 right-0 z-[600] w-full flex flex-col md:flex-row items-center justify-between px-4 md:px-6 py-2.5 select-none cursor-pointer border-t shadow-[0_-5px_25px_rgba(0,0,0,0.5)] transition-all"
               onClick={handleSecretCreditClick}
               style={{ 
                 backgroundColor: isLightMode 
                        ? ((systemSettings as any).creditBgLight || '#ffffff') 
                        : ((systemSettings as any).creditBgDark || '#050B14'),
                 borderColor: isLightMode ? '#e2e8f0' : '#1e293b',
                 opacity: (systemSettings as any).creditOpacity !== undefined ? (systemSettings as any).creditOpacity : 1,
                 fontFamily: 'system-ui, sans-serif'
               }}>
             
             <div className="flex flex-wrap items-center justify-center md:justify-start gap-2 md:gap-4 text-[10px] md:text-xs font-bold order-2 md:order-1 mt-1.5 md:mt-0" dir="ltr">
                 <span style={{ color: '#10b981' }}>{(systemSettings as any).footerLeftText3 || "ترخيص نشط ومصرح"}</span>
                 <span className="text-slate-500 hidden md:inline">|</span>
                 <div className="flex items-center gap-1.5 text-white">
                     <span>{(systemSettings as any).footerLeftText2 || "نظام البوابات المشفر"}</span>
                     <div className="w-1.5 h-1.5 rounded-full bg-emerald-500"></div>
                 </div>
                 <span className="text-slate-500 hidden md:inline">|</span>
                 <div className="flex items-center gap-2 text-white">
                     <span>{(systemSettings as any).footerLeftText1 || "SEC-ID: 7941-PRO"}</span>
                     <Shield className="w-4 h-4 text-amber-500" />
                 </div>
             </div>

             <div className="text-[10px] md:text-xs font-bold tracking-wide order-1 md:order-2 text-center md:text-right w-full md:w-auto" style={{ color: isLightMode ? '#334155' : '#e2e8f0' }} dir="rtl">
                 {(systemSettings as any).footerRightText || "برمجة وتطوير: المهندس علي أحمد عنيد • جميع الحقوق محفوظة"}
             </div>
          </div>

          {hasVisualAlarm && (
             <div className="absolute inset-0 pointer-events-none z-[30] overflow-hidden">
                {(!systemSettings.visualAlarmEffectType || systemSettings.visualAlarmEffectType === 'classic') && (
                   <div className="absolute inset-0 shadow-[inset_0_0_120px_rgba(239,68,68,0.4)] animate-pulse" style={{ willChange: 'opacity' }}></div>
                )}
                {systemSettings.visualAlarmEffectType === 'radar' && (
                   <div className="absolute inset-0 flex items-center justify-center opacity-40">
                       <div className="w-[100vw] h-[100vw] rounded-full border-[8px] border-red-600/30 animate-[ping_3s_infinite_ease-out]"></div>
                       <div className="absolute w-[75vw] h-[75vw] rounded-full border-[4px] border-red-500/40 animate-[ping_3s_infinite_ease-out_1s]"></div>
                   </div>
                )}
                {systemSettings.visualAlarmEffectType === 'strobe' && (
                   <div className="absolute inset-0 shadow-[inset_0_0_100px_rgba(255,0,0,0.8)] border-[8px] border-red-600 animate-[pulse_0.2s_infinite]"></div>
                )}
                {systemSettings.visualAlarmEffectType === 'cyber' && (
                   <div className="absolute inset-0 shadow-[inset_0_0_150px_rgba(220,38,38,0.5)] border-4 border-red-500/50">
                       <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0IiBoZWlnaHQ9IjQiPjxyZWN0IHdpZHRoPSI0IiBoZWlnaHQ9IjQiIGZpbGw9InRyYW5zcGFyZW50Ii8+PGxpbmUgeDE9IjAiIHkxPSIwIiB4Mj0iNCIgeTI9IjAiIHN0cm9rZT0icmdiYSgyNTUsIDAsIDAsIDAuMTUpIiBzdHJva2Utd2lkdGg9IjEiLz48L3N2Zz4=')] opacity-20"></div>
                   </div>
                )}
                {systemSettings.visualAlarmEffectType === 'minimal' && (
                   <div className="absolute inset-0 shadow-[inset_0_0_80px_rgba(239,68,68,0.25)] border border-red-500/30"></div>
                )}
             </div>
          )}

          <div className="w-full h-full overflow-auto scroll-smooth custom-scrollbar bg-[#010409]" dir="ltr" ref={mapContainerScrollRef}>
            <div 
              className="relative transition-transform duration-500 ease-out origin-top-left"
              style={{ width: `${mapZoom * 100}%`, height: `${mapZoom * 100}%`, minWidth: '100%', minHeight: '100%' }}
              ref={mapRef}
            >
              <div 
                className="absolute inset-0 bg-cover bg-center bg-no-repeat transition-opacity duration-1000" 
                style={{ backgroundImage: `url("${mapBg}")`, filter: isLightMode ? 'none' : 'brightness(0.65) contrast(1.15)', backgroundSize: '100% 100%' }} 
              ></div>

              {filteredBuildings.map((b) => {
                const isThisDragging = draggingBuilding && draggingBuilding.id === b.id;
                const posX = isThisDragging ? draggingBuilding.x : (b.x || 50);
                const posY = isThisDragging ? draggingBuilding.y : (b.y || 50);
                const isSilenced = !b.isOnline && b.acknowledged;
                const isSelected = selectedBuildingId === b.id;
                const buildingSize = b.icon_size || 1;
                const unreadCount = b.unread_comments || 0;
                const length = b.line_length || 0;
                const angle = b.line_angle || 0;
                
                let pinBgClass = "";
                let innerBgClass = "";
                let iconColorClass = "text-white";
                let pulseRingClass = "";

                if (b.custom_status === 'maintenance') {
                    pinBgClass = "bg-blue-600 border-blue-400";
                    innerBgClass = "bg-blue-500";
                } else if (b.custom_status === 'out_of_service') {
                    pinBgClass = "bg-slate-600 border-slate-400";
                    innerBgClass = "bg-slate-500";
                } else if (!b.isOnline) {
                    if (isSilenced) {
                        pinBgClass = "bg-amber-500 border-amber-300";
                        innerBgClass = "bg-amber-400";
                    } else {
                        pinBgClass = "bg-red-600 border-red-400";
                        innerBgClass = "bg-red-500";
                        pulseRingClass = "bg-red-500 animate-ping opacity-40";
                    }
                } else {
                    pinBgClass = "bg-emerald-500 border-emerald-300";
                    innerBgClass = "bg-emerald-400";
                }

                return (
                  <div key={b.id || Math.random()} 
                    onMouseDown={(e) => {
                        e.stopPropagation(); 
                        if (userRole === 'monitoring') return;
                        setSelectedBuildingId(b.id);
                        if (canManageBuildings) setDraggingBuilding({ id: b.id, x: b.x, y: b.y });
                        if ((b.unread_comments || 0) > 0) handleUpdateBuilding(b.id, { clear_unread: true });
                    }}
                    className={`absolute z-[20] ${canManageBuildings ? 'cursor-grab active:cursor-grabbing' : 'cursor-pointer'} ${isSelected ? 'z-[30]' : ''} ${isThisDragging ? 'opacity-40 grayscale' : 'opacity-100'}`}
                    style={{ left: `${posX}%`, top: `${posY}%` }}>

                    <div className={`absolute w-3 h-3 rounded-full border-[2px] border-white dark:border-slate-900 transform -translate-x-1/2 -translate-y-1/2 z-10 ${pinBgClass}`} />
                    {pulseRingClass && <div className={`absolute w-5 h-5 rounded-full transform -translate-x-1/2 -translate-y-1/2 z-0 ${pulseRingClass}`} style={{willChange: 'transform, opacity'}} />}

                    {length > 0 && (
                        <div className={`absolute top-0 left-0 h-[2.5px] origin-left z-0 ${pinBgClass}`}
                             style={{ width: `${length}px`, transform: `rotate(${angle}deg)`, marginTop: '-1.25px' }} />
                    )}

                    <div className="absolute z-20"
                         style={{
                            transform: `rotate(${angle}deg) translateX(${length}px) rotate(-${angle}deg) translate(-50%, -50%)`,
                            width: 0, height: 0,
                            willChange: 'transform'
                         }}>
                         
                         <div className="relative flex flex-col items-center transition-transform duration-300" style={{ transform: `rotate(${b.icon_rotation || 0}deg)`, willChange: 'transform' }}>
                            
                            {!b.isOnline && !isSilenced && canSilenceAlarm && (
                              <button onMouseDown={(e)=>e.stopPropagation()} onClick={(e) => { e.stopPropagation(); setShowMuteMenu(b.id); }} className="absolute -top-16 p-2.5 bg-amber-400 text-black rounded-full shadow-xl animate-bounce z-[80] border-4 border-slate-950 hover:bg-amber-300 transition-colors" style={{transform: `rotate(-${b.icon_rotation || 0}deg)`}}><VolumeX className="w-6 h-6" /></button>
                            )}
                            
                            {showMuteMenu === b.id && !isSilenced && (
                              <div className="absolute -top-44 bg-white dark:bg-slate-900 border border-black/10 dark:border-white/10 rounded-[1.5rem] p-2 z-[90] shadow-xl w-36 space-y-1 backdrop-blur-xl" onMouseDown={e=>e.stopPropagation()} style={{transform: `rotate(-${b.icon_rotation || 0}deg)`}}>
                                 <p className="text-[9px] text-center text-slate-500 font-black uppercase mb-1">{t.muteDuration}</p>
                                 {[10, 60, 1440, 0].map(dur => (
                                   <button key={dur} type="button" onClick={(e)=>{ 
                                     e.stopPropagation(); 
                                     handleUpdateBuilding(b.id, {acknowledged: true, ack_duration: dur}); 
                                     setShowMuteMenu(null); 
                                   }} className="w-full py-2 text-[10px] font-black rounded-xl hover:bg-blue-600 hover:text-white transition-colors text-slate-700 dark:text-slate-300">
                                     {dur===0 ? t.muteForever : dur===10 ? t.mute10m : dur===60 ? t.mute1h : t.mute24h}
                                   </button>
                                 ))}
                                 <button type="button" onClick={(e)=>{e.stopPropagation(); setShowMuteMenu(null);}} className="w-full py-1 text-red-500 text-[10px] font-bold"><X className="w-3 h-3 mx-auto"/></button>
                              </div>
                            )}

                            {unreadCount > 0 && (
                              <div className="absolute -top-4 -right-4 bg-red-600 text-white text-[10px] font-black px-2 py-0.5 rounded-full shadow-md z-[90] border-2 border-white dark:border-slate-950 animate-bounce" style={{transform: `rotate(-${b.icon_rotation || 0}deg)`}}>
                                {unreadCount}
                              </div>
                            )}

                            <div className={`relative flex items-center justify-center transition-transform border-[3px] border-white dark:border-slate-800 ${pinBgClass} ${isSelected ? 'ring-4 ring-white/50 scale-110' : ''} ${(!b.pin_shape || b.pin_shape === 'pin') ? 'rounded-br-none' : ''}`}
                                 style={{
                                   width: `${buildingSize * 70}px`,
                                   height: `${buildingSize * 70}px`,
                                   borderRadius: getPinShapeStyles(b.pin_shape).outer.borderRadius,
                                   transform: getPinShapeStyles(b.pin_shape).outer.transform, 
                                   transformOrigin: 'center center',
                                   willChange: 'transform'
                                 }}>
                                 
                                 {pulseRingClass && <div className={`absolute inset-[-4px] rounded-full z-[-1] ${pulseRingClass} ${(!b.pin_shape || b.pin_shape === 'pin') ? 'rounded-br-none' : ''}`} style={{ borderRadius: getPinShapeStyles(b.pin_shape).outer.borderRadius, transform: getPinShapeStyles(b.pin_shape).outer.transform, willChange: 'transform, opacity' }}></div>}

                                 <div className="flex flex-col items-center justify-center rounded-full overflow-hidden"
                                      style={{
                                        width: '85%',
                                        height: '85%',
                                        transform: getPinShapeStyles(b.pin_shape).inner.transform,
                                        backgroundColor: innerBgClass.includes('bg-') ? undefined : 'var(--theme-card-bg)'
                                      }}>
                                      
                                      <div className={`shrink-0 ${iconColorClass}`}>
                                         {b.custom_status === 'maintenance' ? <Wrench style={{width: buildingSize * 18, height: buildingSize * 18}} /> : 
                                          b.custom_status === 'out_of_service' ? <PowerOff style={{width: buildingSize * 18, height: buildingSize * 18}} /> : 
                                          <BuildingIcon iconId={b.icon} style={{width: buildingSize * 18, height: buildingSize * 18}} />}
                                      </div>
                                      
                                      <span className="font-black text-center leading-tight w-full px-1 mt-0.5" 
                                            style={{ 
                                                fontSize: `${b.font_size || Math.max(7, buildingSize * 9)}px`, 
                                                color: b.font_color || '#ffffff',
                                                wordWrap: 'break-word', 
                                                whiteSpace: 'normal', 
                                                lineHeight: '1.1',
                                                textShadow: '0 1px 2px rgba(0,0,0,0.8)'
                                            }}>
                                        {b.name || 'بدون اسم'}
                                      </span>

                                 </div>
                            </div>

                            <div className="absolute top-full mt-2 flex flex-col items-center gap-0.5 z-20" style={{transform: `rotate(-${b.icon_rotation || 0}deg)`}}>
                               {b.custom_status === 'maintenance' && <span className="text-[9px] text-white font-black bg-blue-600 px-2 py-0.5 rounded-full border border-white/20 uppercase shadow-sm">{t.maintStatusLabel}</span>}
                               {b.custom_status === 'out_of_service' && <span className="text-[9px] text-white font-black bg-slate-600 px-2 py-0.5 rounded-full border border-white/20 uppercase shadow-sm">{t.outStatusLabel}</span>}
                            </div>

                         </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {showSecretModal && (
        <div className="fixed inset-0 bg-black/80 z-[400] flex items-center justify-center p-4 no-print backdrop-blur-sm" onClick={() => setShowSecretModal(false)}>
            <div className="bg-slate-900 border-2 border-indigo-500/50 rounded-[2rem] w-full max-w-2xl shadow-[0_0_150px_rgba(99,102,241,0.3)] overflow-hidden flex flex-col max-h-[90vh]" onClick={e => e.stopPropagation()}>
                <div className="flex justify-between items-center p-6 border-b border-white/10 bg-indigo-950/30">
                    <h2 className="font-black flex items-center gap-3 text-sm text-indigo-400 uppercase tracking-widest">
                        <Sliders className="w-5 h-5"/> الإعدادات المتقدمة للوحة الحقوق (نافذة سرية)
                    </h2>
                    <button onClick={() => setShowSecretModal(false)} className="p-2 hover:bg-red-500/20 hover:text-red-500 text-slate-400 rounded-full transition-all"><X className="w-5 h-5"/></button>
                </div>
                <div className="p-6 overflow-y-auto custom-scrollbar space-y-6 flex-1 text-slate-200">
                    
                    <div className="grid grid-cols-1 gap-4">
                        <div className="space-y-1.5">
                            <label className="text-[10px] font-black text-slate-400 uppercase">نص الحقوق (اليمين)</label>
                            <input type="text" value={(systemSettings as any).footerRightText !== undefined ? (systemSettings as any).footerRightText : 'برمجة وتطوير: المهندس علي أحمد عنيد • جميع الحقوق محفوظة'} onChange={(e) => handleUpdateSettings({footerRightText: e.target.value})} className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 text-[11px] font-bold outline-none focus:border-indigo-500 transition-all text-white" dir="rtl" />
                        </div>
                    </div>

                    <div className="grid grid-cols-3 gap-4 pt-4 border-t border-white/5">
                        <div className="space-y-1.5">
                            <label className="text-[10px] font-black text-slate-400 uppercase">النص الأيسر 1 (الكود)</label>
                            <input type="text" value={(systemSettings as any).footerLeftText1 !== undefined ? (systemSettings as any).footerLeftText1 : 'SEC-ID: 7941-PRO'} onChange={(e) => handleUpdateSettings({footerLeftText1: e.target.value})} className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 text-[11px] font-bold outline-none focus:border-indigo-500 transition-all text-white" dir="ltr" />
                        </div>
                        <div className="space-y-1.5">
                            <label className="text-[10px] font-black text-slate-400 uppercase">النص الأيسر 2 (النظام)</label>
                            <input type="text" value={(systemSettings as any).footerLeftText2 !== undefined ? (systemSettings as any).footerLeftText2 : 'نظام البوابات المشفر'} onChange={(e) => handleUpdateSettings({footerLeftText2: e.target.value})} className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 text-[11px] font-bold outline-none focus:border-indigo-500 transition-all text-white" dir="rtl" />
                        </div>
                        <div className="space-y-1.5">
                            <label className="text-[10px] font-black text-slate-400 uppercase">النص الأيسر 3 (الترخيص)</label>
                            <input type="text" value={(systemSettings as any).footerLeftText3 !== undefined ? (systemSettings as any).footerLeftText3 : 'ترخيص نشط ومصرح'} onChange={(e) => handleUpdateSettings({footerLeftText3: e.target.value})} className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 text-[11px] font-bold outline-none focus:border-indigo-500 transition-all text-white" dir="rtl" />
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 pt-4 border-t border-white/5">
                        <div className="space-y-1.5">
                            <label className="text-[10px] font-black text-slate-400 uppercase">العرض Width: {(systemSettings as any).creditWidth ? `${(systemSettings as any).creditWidth}px` : 'تلقائي'}</label>
                            <input type="range" min="0" max="600" step="5" value={(systemSettings as any).creditWidth || 0} onChange={(e) => handleUpdateSettings({creditWidth: parseInt(e.target.value)})} className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500 outline-none" />
                        </div>
                        <div className="space-y-1.5">
                            <label className="text-[10px] font-black text-slate-400 uppercase">الارتفاع Height: {(systemSettings as any).creditHeight ? `${(systemSettings as any).creditHeight}px` : 'تلقائي'}</label>
                            <input type="range" min="0" max="200" step="2" value={(systemSettings as any).creditHeight || 0} onChange={(e) => handleUpdateSettings({creditHeight: parseInt(e.target.value)})} className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500 outline-none" />
                        </div>
                        <div className="space-y-1.5 col-span-2">
                            <label className="text-[10px] font-black text-slate-400 uppercase">حجم التكبير العام: {Math.round(((systemSettings as any).creditSize !== undefined ? (systemSettings as any).creditSize : 1) * 100)}%</label>
                            <input type="range" min="0.5" max="3" step="0.1" value={(systemSettings as any).creditSize !== undefined ? (systemSettings as any).creditSize : 1} onChange={(e) => handleUpdateSettings({creditSize: parseFloat(e.target.value)})} className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500 outline-none" />
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 pt-4 border-t border-white/5">
                        <div className="space-y-1.5">
                            <label className="text-[10px] font-black text-slate-400 uppercase">حجم خط الاسم: {(systemSettings as any).creditNameSize || 11}px</label>
                            <input type="range" min="6" max="40" step="1" value={(systemSettings as any).creditNameSize || 11} onChange={(e) => handleUpdateSettings({creditNameSize: parseInt(e.target.value)})} className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500 outline-none" />
                        </div>
                        <div className="space-y-1.5">
                            <label className="text-[10px] font-black text-slate-400 uppercase">حجم خط الوصف: {(systemSettings as any).creditRoleSize || 9}px</label>
                            <input type="range" min="5" max="30" step="1" value={(systemSettings as any).creditRoleSize || 9} onChange={(e) => handleUpdateSettings({creditRoleSize: parseInt(e.target.value)})} className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500 outline-none" />
                        </div>
                    </div>

                    <div className="grid grid-cols-3 gap-4 pt-4 border-t border-white/5">
                        <div className="space-y-1.5">
                            <label className="text-[10px] font-black text-slate-400 uppercase">من الأسفل: {(systemSettings as any).creditBottom !== undefined ? (systemSettings as any).creditBottom : 24}px</label>
                            <input type="range" min="0" max="800" step="2" value={(systemSettings as any).creditBottom !== undefined ? (systemSettings as any).creditBottom : 24} onChange={(e) => handleUpdateSettings({creditBottom: parseInt(e.target.value)})} className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500 outline-none" />
                        </div>
                        <div className="space-y-1.5">
                            <label className="text-[10px] font-black text-slate-400 uppercase">من الجانب: {(systemSettings as any).creditSide !== undefined ? (systemSettings as any).creditSide : 24}px</label>
                            <input type="range" min="0" max="800" step="2" value={(systemSettings as any).creditSide !== undefined ? (systemSettings as any).creditSide : 24} onChange={(e) => handleUpdateSettings({creditSide: parseInt(e.target.value)})} className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500 outline-none" />
                        </div>
                        <div className="space-y-1.5">
                            <label className="text-[10px] font-black text-slate-400 uppercase">الشفافية: {Math.round(((systemSettings as any).creditOpacity !== undefined ? (systemSettings as any).creditOpacity : 1) * 100)}%</label>
                            <input type="range" min="0.1" max="1" step="0.05" value={(systemSettings as any).creditOpacity !== undefined ? (systemSettings as any).creditOpacity : 1} onChange={(e) => handleUpdateSettings({creditOpacity: parseFloat(e.target.value)})} className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500 outline-none" />
                        </div>
                    </div>

                    <div className="grid grid-cols-3 gap-4 pt-4 border-t border-white/5">
                        <div className="space-y-1.5">
                            <label className="text-[10px] font-black text-slate-400 uppercase">لون الأيقونة</label>
                            <input type="color" value={(systemSettings as any).creditIconColor || '#38bdf8'} onChange={(e) => handleUpdateSettings({creditIconColor: e.target.value})} className="w-full h-8 rounded border border-slate-800 cursor-pointer bg-slate-950 p-0.5" />
                        </div>
                        <div className="space-y-1.5">
                            <label className="text-[10px] font-black text-slate-400 uppercase">خلفية الليلي</label>
                            <input type="color" value={(systemSettings as any).creditBgDark || '#0b101e'} onChange={(e) => handleUpdateSettings({creditBgDark: e.target.value})} className="w-full h-8 rounded border border-slate-800 cursor-pointer bg-slate-950 p-0.5" />
                        </div>
                        <div className="space-y-1.5">
                            <label className="text-[10px] font-black text-slate-400 uppercase">خلفية النهاري</label>
                            <input type="color" value={(systemSettings as any).creditBgLight || '#ffffff'} onChange={(e) => handleUpdateSettings({creditBgLight: e.target.value})} className="w-full h-8 rounded border border-slate-800 cursor-pointer bg-slate-950 p-0.5" />
                        </div>
                    </div>

                </div>
                <div className="p-4 border-t border-white/10 flex justify-between bg-black/40">
                    <button onClick={handleResetSecretSettings} className="px-5 py-2.5 bg-red-500/10 text-red-400 border border-red-500/20 rounded-xl text-[11px] font-black hover:bg-red-500 hover:text-white transition-all">استعادة الافتراضيات</button>
                    <button onClick={() => setShowSecretModal(false)} className="px-8 py-2.5 bg-indigo-600 text-white rounded-xl text-[11px] font-black hover:bg-indigo-500 transition-all shadow-lg shadow-indigo-900/50">إغلاق وتطبيق</button>
                </div>
            </div>
        </div>
      )}

      {showSettingsModal && (
        <div className="fixed inset-0 bg-black/80 z-[150] flex items-center justify-center p-4 no-print" onClick={()=>setShowSettingsModal(false)}>
          <div className="theme-card border-theme rounded-[3rem] w-full max-w-md shadow-[0_0_100px_rgba(0,0,0,0.5)] overflow-hidden" onClick={e=>e.stopPropagation()}>
            <div className="flex justify-between items-center p-7 border-b border-theme bg-black/5 dark:bg-white/5">
              <h2 className="font-black flex items-center gap-3 text-sm text-blue-500 uppercase tracking-widest"><Settings className="w-6 h-6"/> {t.settingsTitle}</h2>
              <button onClick={() => setShowSettingsModal(false)} className="p-2 theme-btn rounded-full transition-all"><X className="w-6 h-6"/></button>
            </div>
            <div className="p-9 space-y-7 max-h-[75vh] overflow-y-auto custom-scrollbar">
              <div className="space-y-3">
                <label className="text-[11px] font-black text-theme-muted flex items-center gap-2 uppercase tracking-widest"><ImageIcon className="w-5 h-5"/> {t.changeMap}</label>
                <input type="file" accept="image/*" onChange={(e)=>handleFileUpload(e, 'mapBg')} className="w-full text-[11px] text-slate-500 file:mr-4 file:py-2.5 file:px-7 file:rounded-full file:border-0 file:bg-blue-600 file:text-white file:font-black hover:file:bg-blue-500 transition-all cursor-pointer shadow-lg" disabled={isUploading} />
              </div>
              <div className="space-y-3">
                <label className="text-[11px] font-black text-theme-muted flex items-center gap-2 uppercase tracking-widest"><Music className="w-5 h-5"/> {t.changeSound}</label>
                <input type="file" accept="audio/*" onChange={(e)=>handleFileUpload(e, 'customAlarmSound')} className="w-full text-[11px] text-slate-500 file:mr-4 file:py-2.5 file:px-7 file:rounded-full file:border-0 file:bg-purple-600 file:text-white file:font-black hover:file:bg-purple-500 transition-all cursor-pointer shadow-lg" disabled={isUploading} />
              </div>
              {isUploading && <div className="text-center py-3 bg-emerald-500/10 rounded-2xl text-[11px] text-emerald-400 animate-pulse font-black border border-emerald-500/20">{t.isUploading}</div>}
              
              <div className="space-y-3 pt-4 border-t border-theme">
                 <h3 className="text-[11px] font-black text-theme-muted uppercase tracking-widest flex items-center gap-2">
                    <Sliders className="w-4 h-4 text-blue-500"/> اسم البرنامج ولوحة التحكم
                 </h3>
                 <div className="space-y-2">
                   <div className="space-y-1">
                     <label className="text-[9px] font-black text-theme-muted uppercase px-1">عنوان البرنامج (عربي)</label>
                     <input type="text" value={(systemSettings as any).appTitleText || ''} onChange={(e) => handleUpdateSettings({appTitleText: e.target.value})} placeholder="مثال: لوحة تحكم إنذارات الحريق" className="w-full theme-input border-theme rounded-xl px-4 py-2.5 text-xs outline-none focus:border-blue-500/50 transition-all" />
                   </div>
                   <div className="space-y-1">
                     <label className="text-[9px] font-black text-theme-muted uppercase px-1">عنوان البرنامج (English)</label>
                     <input type="text" value={(systemSettings as any).appTitleTextEn || ''} onChange={(e) => handleUpdateSettings({appTitleTextEn: e.target.value})} placeholder="e.g. Fire Alarm Monitoring Panel" className="w-full theme-input border-theme rounded-xl px-4 py-2.5 text-xs outline-none focus:border-blue-500/50 transition-all" dir="ltr" />
                   </div>
                 </div>
              </div>
              
              <div className="space-y-3 pt-4 border-t border-theme">
                 <h3 className="text-[11px] font-black text-theme-muted uppercase tracking-widest flex items-center gap-2">
                    <ShieldAlert className="w-4 h-4"/> {t.creditSettings}
                 </h3>
                 <div className="space-y-2">
                    <input type="text" value={(systemSettings as any).creditName !== undefined ? (systemSettings as any).creditName : 'ALI AHMED ANEED'} onChange={(e) => handleUpdateSettings({creditName: e.target.value})} placeholder={t.creditNameLabel} className="w-full theme-input border-theme rounded-xl px-4 py-2 text-[11px] font-bold outline-none focus:border-blue-500/50 transition-all" dir="ltr" />
                    <input type="text" value={(systemSettings as any).creditRole !== undefined ? (systemSettings as any).creditRole : 'IT BWE DESIGN & DEV'} onChange={(e) => handleUpdateSettings({creditRole: e.target.value})} placeholder={t.creditRoleLabel} className="w-full theme-input border-theme rounded-xl px-4 py-2 text-[11px] font-bold outline-none focus:border-blue-500/50 transition-all" dir="ltr" />
                    <div className="space-y-1.5 pt-1">
                       <label className="text-[10px] font-black text-theme-muted uppercase">{t.creditSizeLabel}: {Math.round(((systemSettings as any).creditSize !== undefined ? (systemSettings as any).creditSize : 1) * 100)}%</label>
                       <input type="range" min="0.5" max="3" step="0.1" value={(systemSettings as any).creditSize !== undefined ? (systemSettings as any).creditSize : 1} onChange={(e) => handleUpdateSettings({creditSize: parseFloat(e.target.value)})} className="w-full h-1.5 bg-slate-300 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-500 outline-none" />
                    </div>
                 </div>
              </div>

              <div className="space-y-3 pt-4 border-t border-theme">
                 <h3 className="text-[11px] font-black text-theme-muted uppercase tracking-widest flex items-center gap-2">
                    <Volume2 className="w-4 h-4"/> {t.voiceAlarmToggle}
                 </h3>
                 <div className="flex items-center gap-3">
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" className="sr-only peer" checked={systemSettings.enableVoiceAlarm || false} onChange={(e) => handleUpdateSettings({enableVoiceAlarm: e.target.checked})} />
                      <div className="w-11 h-6 bg-slate-300 dark:bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                    </label>
                    <span className="text-[11px] font-bold text-theme">{systemSettings.enableVoiceAlarm ? 'مفعل' : 'معطل'}</span>
                 </div>
                 {systemSettings.enableVoiceAlarm && (
                    <div className="space-y-1.5 mt-2">
                       <label className="text-[10px] font-black text-theme-muted uppercase">{t.voiceAlarmPhrase}</label>
                       <input type="text" value={systemSettings.voiceAlarmText || ''} onChange={(e) => handleUpdateSettings({voiceAlarmText: e.target.value})} placeholder={t.voiceAlarmPlaceholder} className="w-full theme-input border-theme rounded-xl px-4 py-2.5 text-[11px] outline-none focus:border-blue-500/50 transition-all" />
                    </div>
                 )}
              </div>

              <div className="space-y-3 pt-4 border-t border-theme">
                 <h3 className="text-[11px] font-black text-theme-muted uppercase tracking-widest flex items-center gap-2">
                    <Sliders className="w-4 h-4"/> إعدادات شبكة الفحص الذكي والإنذار
                 </h3>
                 <div className="grid grid-cols-2 gap-4">
                   <div className="space-y-1.5">
                     <div className="flex items-center justify-between">
                       <label className="text-[9px] font-black text-theme-muted uppercase leading-tight">
                         {lang === 'ar' ? 'فترة فحص البنك (بالثواني)' : 'Ping Interval (seconds)'}
                       </label>
                       <span className="text-[10px] font-black text-blue-500 font-mono">
                         {(() => {
                           const raw = (systemSettings as any).pingInterval;
                           if (!raw) return 5;
                           return raw >= 100 ? Math.round(raw / 1000) : raw;
                         })()} {lang === 'ar' ? 'ثانية' : 'sec'}
                       </span>
                     </div>
                     <div className="flex items-center gap-2">
                       <input 
                         type="number" 
                         min="1" 
                         max="120"
                         step="1"
                         value={
                           (() => {
                             const raw = (systemSettings as any).pingInterval;
                             if (!raw) return 5;
                             return raw >= 100 ? Math.round(raw / 1000) : raw;
                           })()
                         } 
                         onChange={(e) => {
                           const sec = Math.max(1, Number(e.target.value) || 1);
                           handleUpdateSettings({ pingInterval: sec * 1000 });
                         }} 
                         className="w-full theme-input border-theme rounded-xl px-3 py-2 text-xs font-bold outline-none" 
                       />
                     </div>
                     <div className="flex flex-wrap gap-1 pt-1">
                       {[3, 5, 10, 15, 30].map(s => {
                         const currentSec = (() => {
                           const raw = (systemSettings as any).pingInterval;
                           if (!raw) return 5;
                           return raw >= 100 ? Math.round(raw / 1000) : raw;
                         })();
                         const isSelected = currentSec === s;
                         return (
                           <button
                             key={s}
                             type="button"
                             onClick={() => handleUpdateSettings({ pingInterval: s * 1000 })}
                             className={`px-2 py-0.5 rounded-lg text-[9px] font-bold border transition-all ${
                               isSelected 
                                 ? 'bg-blue-600 text-white border-blue-500 shadow-sm' 
                                 : 'theme-card border-theme text-theme-muted hover:text-white'
                             }`}
                           >
                             {s} {lang === 'ar' ? 'ث' : 's'}
                           </button>
                         );
                       })}
                     </div>
                   </div>
                   <div className="space-y-1.5">
                     <label className="text-[9px] font-black text-theme-muted uppercase leading-tight">انتظار الاستجابة (ms)</label>
                     <input type="number" min="100" value={(systemSettings as any).pingTimeout || 800} onChange={(e) => handleUpdateSettings({pingTimeout: Number(e.target.value)})} className="w-full theme-input border-theme rounded-xl px-3 py-2 text-xs outline-none" />
                   </div>
                    <div className="space-y-1.5">
                      <label className="text-[9px] font-black text-theme-muted uppercase leading-tight">
                        {lang === 'ar' ? 'محاولات البكت لكل فحص' : 'Retries Per Check'}
                      </label>
                      <input 
                        type="number" 
                        min="1" 
                        max="10"
                        value={(systemSettings as any).pingRetries || 2} 
                        onChange={(e) => handleUpdateSettings({pingRetries: Number(e.target.value)})} 
                        className="w-full theme-input border-theme rounded-xl px-3 py-2 text-xs font-bold outline-none" 
                      />
                    </div>
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <label className="text-[9px] font-black text-blue-400 uppercase leading-tight flex items-center gap-1">
                          <ShieldCheck className="w-3 h-3 text-blue-500" />
                          {lang === 'ar' ? 'تأكيد الانقطاع (فلترة البكت لوز)' : 'Loss Filter (Cycles)'}
                        </label>
                        <span className="text-[10px] font-black text-blue-500 font-mono">
                          {Number((systemSettings as any).confirmCycles) || 2} {lang === 'ar' ? 'دورات' : 'cyc'}
                        </span>
                      </div>
                      <div className="flex flex-wrap gap-1 pt-0.5">
                        {[1, 2, 3, 4].map(c => {
                          const currentCycles = Number((systemSettings as any).confirmCycles) || 2;
                          const isSelected = currentCycles === c;
                          return (
                            <button
                              key={c}
                              type="button"
                              onClick={() => handleUpdateSettings({ confirmCycles: c })}
                              className={`px-2 py-1 rounded-lg text-[9px] font-bold border transition-all ${
                                isSelected 
                                  ? 'bg-blue-600 text-white border-blue-500 shadow-sm font-black' 
                                  : 'theme-card border-theme text-theme-muted hover:text-white'
                              }`}
                            >
                              {c === 1 ? (lang === 'ar' ? '1 (فوري)' : '1 (instant)') : c === 2 ? (lang === 'ar' ? '2 (ذكي وسريع)' : '2 (smart)') : `${c} ${lang === 'ar' ? 'دورات' : 'cyc'}`}
                            </button>
                          );
                        })}
                      </div>
                      <p className="text-[8px] text-theme-muted leading-snug">
                        {lang === 'ar' 
                          ? '✨ فحص ذكي وسريع: يكتشف انقطاع البناية ويدق الإنذار خلال ثوانٍ معدودة مع امتصاص تذبذب الشبكة والـ Packet Loss.' 
                          : 'Smart and rapid check: detects real outages in seconds while filtering transient network packet loss.'}
                      </p>
                    </div>
                    <div className="space-y-1.5 col-span-2">
                      <label className="text-[9px] font-black text-theme-muted uppercase leading-tight">مصدر وموقع فحص البنك (Ping Source)</label>
                      <select 
                        value={(systemSettings as any).pingSource || 'server'} 
                        onChange={(e) => handleUpdateSettings({pingSource: e.target.value})} 
                        className="w-full theme-input border-theme rounded-xl px-2 py-2 text-xs outline-none bg-slate-900 text-white dark:bg-slate-950"
                      >
                        <option value="server">الخادم / الحاسوب المحلي (ICMP Ping المباشر - مستحسن للتنصيب بالحاسبة)</option>
                        <option value="browser">متصفح المستخدم (HTTP probe - مستحسن للرابط السحابي العام)</option>
                      </select>
                      <p className="text-[8px] text-theme-muted mt-0.5 leading-snug">
                        {lang === 'ar' 
                          ? 'عند تنصيب البرنامج بالحاسبة، اختر "الخادم / الحاسوب المحلي" لعمل فحص شبكة ICMP حقيقي ومباشر بدون فصلات مو حقيقية.' 
                          : 'For local PC installation, choose Local PC Server for real ICMP pings without false disconnects.'}
                      </p>
                      {window.location.protocol === 'https:' && ((systemSettings as any).pingSource || 'server') === 'browser' && (
                        <div className="p-2.5 bg-amber-500/10 text-amber-500 border border-amber-500/20 rounded-xl text-[8px] mt-1.5 leading-snug font-bold">
                          ⚠️ تنبيه المحتوى المختلط: بما أنك تتصفح النظام عبر رابط آمن (HTTPS)، قد يقوم المتصفح بحظر الفحص المحلي. يفضل تشغيل البرنامج كبرنامج حاسوب مخصص (Electron) أو فتحه عبر رابط HTTP عادي ليعمل الفحص المحلي بشكل كامل.
                        </div>
                      )}
                    </div>
                 </div>
              </div>

              <div className="space-y-3 pt-4 border-t border-theme">
                  <h3 className="text-[11px] font-black text-theme-muted uppercase tracking-widest flex items-center gap-2">
                     <Sliders className="w-4 h-4 text-blue-500"/> إعدادات إغلاق وإسكات الإنذار المنفصلة
                  </h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-[9px] font-black text-theme-muted uppercase leading-tight">إسكات إشعار التنبيه البصري (ثانية)</label>
                      <input type="number" min="1" value={(systemSettings as any).autoCloseTimeout || 10} onChange={(e) => handleUpdateSettings({autoCloseTimeout: Number(e.target.value)})} className="w-full theme-input border-theme rounded-xl px-3 py-2 text-xs outline-none focus:border-blue-500/50" />
                      <p className="text-[8px] text-theme-muted mt-0.5 leading-snug">الوقت الذي يختفي بعده إشعار التنبيه البصري من الشاشة تلقائياً.</p>
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-[9px] font-black text-theme-muted uppercase leading-tight">إسكات صوت الإنذار تلقائياً (ثانية)</label>
                      <input type="number" min="1" value={(systemSettings as any).audioSilenceTimeout || 15} onChange={(e) => handleUpdateSettings({audioSilenceTimeout: Number(e.target.value)})} className="w-full theme-input border-theme rounded-xl px-3 py-2 text-xs outline-none focus:border-blue-500/50" />
                      <p className="text-[8px] text-theme-muted mt-0.5 leading-snug">الوقت الذي يتوقف بعده صوت الإنذار تلقائياً لتجنب الإزعاج.</p>
                    </div>
                  </div>
              </div>

              <div className="space-y-4 pt-4 border-t border-theme">
                  <h3 className="text-[11px] font-black text-theme-muted uppercase tracking-widest flex items-center gap-2">
                     <AlertOctagon className="w-4 h-4 text-red-500"/> تخصيص واجهة إنذار انقطاع الاتصال البصري
                  </h3>
                  
                  <div className="space-y-3">
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="text-[9px] font-black text-theme-muted uppercase px-1">عنوان التنبيه (عربي)</label>
                        <input type="text" value={(systemSettings as any).alertHeaderTextAr || ''} onChange={(e) => handleUpdateSettings({alertHeaderTextAr: e.target.value})} className="w-full theme-input border-theme rounded-xl px-3 py-2 text-[10px] outline-none focus:border-blue-500/50" />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[9px] font-black text-theme-muted uppercase px-1">عنوان التنبيه (English)</label>
                        <input type="text" value={(systemSettings as any).alertHeaderTextEn || ''} onChange={(e) => handleUpdateSettings({alertHeaderTextEn: e.target.value})} className="w-full theme-input border-theme rounded-xl px-3 py-2 text-[10px] outline-none focus:border-blue-500/50" dir="ltr" />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="text-[9px] font-black text-theme-muted uppercase px-1">نص التنبيه البصري (عربي)</label>
                        <textarea rows={2} value={(systemSettings as any).alertBodyTextAr || ''} onChange={(e) => handleUpdateSettings({alertBodyTextAr: e.target.value})} className="w-full theme-input border-theme rounded-xl px-3 py-2 text-[10px] outline-none focus:border-blue-500/50 resize-none" />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[9px] font-black text-theme-muted uppercase px-1">نص التنبيه البصري (English)</label>
                        <textarea rows={2} value={(systemSettings as any).alertBodyTextEn || ''} onChange={(e) => handleUpdateSettings({alertBodyTextEn: e.target.value})} className="w-full theme-input border-theme rounded-xl px-3 py-2 text-[10px] outline-none focus:border-blue-500/50 resize-none" dir="ltr" />
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-2 pt-1">
                      <div className="space-y-1">
                        <label className="text-[9px] font-black text-theme-muted uppercase px-1">حجم الخط (px)</label>
                        <input type="number" min="10" max="40" value={(systemSettings as any).alertTextSize || 16} onChange={(e) => handleUpdateSettings({alertTextSize: Number(e.target.value)})} className="w-full theme-input border-theme rounded-xl px-3 py-1.5 text-[10px] outline-none" />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[9px] font-black text-theme-muted uppercase px-1">لون النص</label>
                        <input type="color" value={(systemSettings as any).alertTextColor || '#ffffff'} onChange={(e) => handleUpdateSettings({alertTextColor: e.target.value})} className="w-full h-8 rounded-lg border border-theme cursor-pointer bg-slate-950 p-0.5" />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[9px] font-black text-theme-muted uppercase px-1">نمط الخط</label>
                        <select value={(systemSettings as any).alertTextStyle || 'extrabold'} onChange={(e) => handleUpdateSettings({alertTextStyle: e.target.value})} className="w-full theme-input border-theme rounded-xl px-2 py-1.5 text-[10px] outline-none bg-slate-900 text-white dark:bg-slate-950">
                          <option value="normal">عادي (Normal)</option>
                          <option value="bold">عريض (Bold)</option>
                          <option value="extrabold">عريض جداً (Extrabold)</option>
                          <option value="italic">مائل (Italic)</option>
                        </select>
                      </div>
                    </div>
                  </div>
              </div>

              <div className="space-y-4 pt-4 border-t border-theme">
                  <h3 className="text-[11px] font-black text-theme-muted uppercase tracking-widest flex items-center gap-2">
                     <Sparkles className="w-4 h-4 text-amber-500"/> نمط حركة الأيقونة وحجمها الببلي
                  </h3>
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    <div className="space-y-1">
                      <label className="text-[9px] font-black text-theme-muted uppercase px-1">نوع الحركة</label>
                      <select value={(systemSettings as any).alertIconAnimation || 'bounce'} onChange={(e) => handleUpdateSettings({alertIconAnimation: e.target.value})} className="w-full theme-input border-theme rounded-xl px-2 py-2 text-[10px] outline-none bg-slate-900 text-white dark:bg-slate-950">
                        <option value="bounce">قفز كلاسيكي (Bounce)</option>
                        <option value="grow">تكبير متقطع (Grow Zoom)</option>
                        <option value="bubble">نبض الفقاعة (Bubble Pulse)</option>
                      </select>
                    </div>
                    <div className="space-y-1">
                      <label className="text-[9px] font-black text-theme-muted uppercase px-1">تكبير الأيقونة (%)</label>
                      <input type="number" min="100" max="1000" step="50" value={(systemSettings as any).alertIconScale || 500} onChange={(e) => handleUpdateSettings({alertIconScale: Number(e.target.value)})} className="w-full theme-input border-theme rounded-xl px-3 py-2 text-[10px] outline-none focus:border-blue-500/50" />
                      <p className="text-[7px] text-theme-muted mt-0.5">مثال: 500 لـ 500%</p>
                    </div>
                    <div className="space-y-1">
                      <label className="text-[9px] font-black text-theme-muted uppercase px-1">مدة الحركة (ثانية)</label>
                      <input type="number" min="1" max="30" value={(systemSettings as any).alertAnimationDuration || 5} onChange={(e) => handleUpdateSettings({alertAnimationDuration: Number(e.target.value)})} className="w-full theme-input border-theme rounded-xl px-3 py-2 text-[10px] outline-none focus:border-blue-500/50" />
                      <p className="text-[7px] text-theme-muted mt-0.5">سرعة تكرار الحركة</p>
                    </div>
                    <div className="space-y-1">
                      <label className="text-[9px] font-black text-theme-muted uppercase px-1">تأثير الانذار الشامل</label>
                      <select value={(systemSettings as any).visualAlarmEffectType || 'classic'} onChange={(e) => handleUpdateSettings({visualAlarmEffectType: e.target.value})} className="w-full theme-input border-theme rounded-xl px-2 py-2 text-[10px] outline-none bg-slate-900 text-white dark:bg-slate-950">
                        <option value="classic">كلاسيكي (Classic Flash)</option>
                        <option value="radar">رادار نابض (Radar Pulse)</option>
                        <option value="strobe">ومضات متسارعة (Strobe)</option>
                        <option value="cyber">سايبر/رقمي (Cyber Glitch)</option>
                        <option value="minimal">هادئ بدون وميض (Minimal)</option>
                      </select>
                      <p className="text-[7px] text-theme-muted mt-0.5">تأثير الخلفية عند الانذار</p>
                    </div>
                  </div>
              </div>

              <div className="space-y-3 pt-4 border-t border-theme">
                 <h3 className="text-[11px] font-black text-theme-muted uppercase tracking-widest flex items-center gap-2">
                    <MonitorIcon className="w-4 h-4 text-purple-500"/> تثبيت تطبيق الحاسوب (PWA)
                 </h3>
                 <p className="text-[10px] text-theme-muted leading-relaxed">
                   {lang === 'ar' 
                     ? 'تثبيت المنظومة كبرنامج حاسوب يمنحك تشغيلًا أسرع، وأيقونة على سطح المكتب، وواجهة ممتدة بدون إطار المتصفح.' 
                     : 'Installing the system as a desktop app provides faster startup, a desktop icon, and an immersive borderless window.'
                   }
                 </p>
                 <button type="button" onClick={handleInstallApp} className="w-full bg-purple-600/10 hover:bg-purple-600/20 text-purple-600 dark:text-purple-400 border border-purple-500/20 py-2.5 rounded-xl text-[10px] font-black transition-all flex items-center justify-center gap-1.5 shadow-sm">
                   🖥️ {lang === 'ar' ? 'تثبيت الآن على الكمبيوتر' : 'Install Desktop App Now'}
                 </button>
              </div>

              <div className="space-y-3 pt-4 border-t border-theme">
                 <h3 className="text-[11px] font-black text-theme-muted uppercase tracking-widest flex items-center gap-2">
                    <Database className="w-4 h-4"/> النسخ الاحتياطي والبيانات (Backup)
                 </h3>
                 <div className="flex gap-2.5">
                   <button type="button" onClick={() => { window.location.href = `${SERVER_URL}/api/backup`; }} className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white py-2.5 rounded-xl text-[10px] font-black transition-all flex items-center justify-center gap-1.5 shadow-md">
                     <Download className="w-3.5 h-3.5"/> أخذ نسخة احتياطية
                   </button>
                   <button type="button" onClick={() => fileInputRef.current?.click()} className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2.5 rounded-xl text-[10px] font-black transition-all flex items-center justify-center gap-1.5 shadow-md">
                     <Upload className="w-3.5 h-3.5"/> استعادة نسخة احتياطية
                   </button>
                   <input type="file" ref={fileInputRef} accept=".json" onChange={async (e) => {
                     const file = e.target.files?.[0];
                     if (!file) return;
                     const reader = new FileReader();
                     reader.onload = async (event: any) => {
                       try {
                         const json = JSON.parse(event.target.result);
                         const res = await fetch(`${SERVER_URL}/api/restore`, {
                           method: 'POST',
                           headers: { 'Content-Type': 'application/json' },
                           body: JSON.stringify(json)
                         });
                         if (res.ok) {
                           addToast(lang === 'ar' ? 'تم استعادة النسخة الاحتياطية بنجاح!' : 'Backup restored successfully!', 'success');
                           fetchSystemData();
                         } else {
                           addToast(lang === 'ar' ? 'فشلت الاستعادة. ملف غير صالح.' : 'Restore failed. Invalid file.', 'error');
                         }
                       } catch (err) {
                         addToast(lang === 'ar' ? 'حدث خطأ في قراءة ملف الباك آب.' : 'Error reading backup file.', 'error');
                       }
                     };
                     reader.readAsText(file);
                   }} className="hidden" />
                 </div>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {showUsersModal && (
        <div className="fixed inset-0 bg-black/80 z-[160] flex items-center justify-center p-4 no-print" onClick={()=>setShowUsersModal(false)}>
          <div className="theme-card border-theme rounded-[3rem] w-full max-w-4xl shadow-2xl p-9 flex flex-col md:flex-row gap-8 max-h-[90vh] overflow-y-auto" onClick={e=>e.stopPropagation()}>
            
            <div className="flex-1 space-y-6">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="font-black text-base flex items-center gap-4 text-blue-500 uppercase tracking-widest"><Users className="w-6 h-6"/> {t.usersTitle}</h2>
                  <button onClick={() => setShowUsersModal(false)} className="p-2 theme-btn rounded-full transition-all md:hidden"><X className="w-5 h-5"/></button>
                </div>
                <form onSubmit={async (e) => { 
                    e.preventDefault(); 
                    const res = await fetch(`${SERVER_URL}/api/users`, { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({username: newUsername, password: newPassword, role: newUserRole, admin_user: username}) }); 
                    const d = await res.json(); 
                    setUserAddMsg(d.success ? '✅ Account Created' : '❌ Username Exists'); 
                    if(d.success) {setNewUsername(''); setNewPassword(''); fetchUsers();} 
                  }} className="space-y-5">
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-theme-muted uppercase px-1 tracking-widest">{t.username}</label>
                    <input type="text" value={newUsername} onChange={(e)=>setNewUsername(e.target.value)} className="w-full theme-input border-theme rounded-2xl px-6 py-3.5 text-sm outline-none transition-all shadow-inner" />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-theme-muted uppercase px-1 tracking-widest">{t.password}</label>
                    <input type="password" value={newPassword} onChange={(e)=>setNewPassword(e.target.value)} className="w-full theme-input border-theme rounded-2xl px-6 py-3.5 text-sm outline-none transition-all shadow-inner" />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-theme-muted uppercase px-1 tracking-widest">الصلاحية</label>
                    <select value={newUserRole} onChange={(e)=>setNewUserRole(e.target.value)} className="w-full theme-input border-theme rounded-2xl px-6 py-3.5 text-sm outline-none transition-all shadow-inner appearance-none">
                      <option value="admin">{t.adminRole}</option>
                      <option value="supervisor">{t.supervisorRole}</option>
                      <option value="maint">{t.maintRole}</option>
                      <option value="viewer">{t.viewerRole}</option>
                      <option value="monitoring">{t.monitoringRole}</option>
                    </select>
                  </div>
                  <button type="submit" className="w-full bg-blue-600 py-3.5 rounded-2xl text-[11px] font-black text-white shadow-xl shadow-blue-900/20 hover:bg-blue-700 transition-all active:scale-95 tracking-widest uppercase">{t.createBtn}</button>
                  {userAddMsg && <div className="text-center text-[10px] text-emerald-500 font-black tracking-tight">{userAddMsg}</div>}
                </form>
            </div>

            <div className="w-px bg-theme border-theme hidden md:block"></div>

            <div className="flex-1 flex flex-col overflow-hidden">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="font-black text-sm flex items-center gap-3 text-theme-muted uppercase tracking-widest"><User className="w-5 h-5"/> {t.usersList}</h3>
                  <button onClick={() => setShowUsersModal(false)} className="p-2 theme-btn rounded-full transition-all hidden md:block"><X className="w-5 h-5"/></button>
                </div>
                <div className="flex-1 overflow-y-auto space-y-3 custom-scrollbar pr-2">
                    {Object.entries(usersList).map(([uName, uRole]) => (
                        <div key={uName} className="theme-input border-theme p-4 rounded-2xl shadow-sm flex flex-col gap-3">
                            <div className="flex justify-between items-center">
                                <div className="flex flex-col">
                                    <span className="text-[13px] font-black text-theme">{uName}</span>
                                    <span className={`text-[9px] font-bold uppercase tracking-wider ${uRole === 'admin' ? 'text-red-500' : uRole === 'supervisor' ? 'text-blue-500' : uRole === 'maint' ? 'text-emerald-500' : uRole === 'monitoring' ? 'text-indigo-400 font-extrabold' : 'text-slate-500'}`}>
                                        {uRole === 'admin' ? t.adminRole : uRole === 'supervisor' ? t.supervisorRole : uRole === 'maint' ? t.maintRole : uRole === 'monitoring' ? t.monitoringRole : t.viewerRole}
                                    </span>
                                </div>
                                {uName !== 'admin' && (
                                    <button onClick={() => handleDeleteUser(uName)} className="p-2 bg-red-500/10 text-red-500 rounded-xl hover:bg-red-500 hover:text-white transition-colors" title={t.deleteUser}>
                                        <Trash2 className="w-4 h-4"/>
                                    </button>
                                )}
                            </div>
                            <div className="flex gap-2 items-center">
                                <input 
                                    type="password" 
                                    placeholder="كلمة مرور جديدة" 
                                    value={editPasswords[uName] || ''} 
                                    onChange={(e) => setEditPasswords({...editPasswords, [uName]: e.target.value})}
                                    className="flex-1 theme-input-bg border border-theme rounded-xl px-3 py-2 text-[10px] outline-none focus:border-blue-500/50"
                                />
                                <button 
                                    onClick={() => handleUserPasswordChange(uName)}
                                    disabled={!editPasswords[uName]}
                                    className={`px-3 py-2 rounded-xl text-[10px] font-black transition-colors ${editPasswords[uName] ? 'bg-emerald-600 text-white' : 'bg-slate-500/20 text-slate-500 cursor-not-allowed'}`}
                                >
                                    {t.updateBtn}
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

          </div>
        </div>
      )}

      {showAnalyticsModal && (
        <div className="fixed inset-0 bg-black/80 z-[160] flex items-center justify-center p-4 no-print" onClick={()=>setShowAnalyticsModal(false)}>
          <div className="theme-card border-theme rounded-[3rem] w-full max-w-3xl shadow-2xl overflow-hidden" onClick={e=>e.stopPropagation()}>
             <div className="flex justify-between items-center p-7 border-b border-theme bg-black/5 dark:bg-white/5">
                <h2 className="font-black flex items-center gap-4 text-base text-blue-500 uppercase tracking-widest"><BarChart3 className="w-7 h-7"/> {t.analyticsTitle}</h2>
                <button onClick={() => setShowAnalyticsModal(false)} className="p-2 theme-btn rounded-full transition-all"><X className="w-6 h-6"/></button>
             </div>
             <div className="p-9 space-y-8">
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                   <div className="p-5 rounded-2xl bg-blue-500/10 border border-blue-500/20 flex flex-col items-center justify-center shadow-inner">
                     <p className="text-4xl font-black text-blue-500">{stats.total}</p>
                     <p className="text-[10px] font-bold text-blue-600/80 mt-2 uppercase tracking-widest">{t.statTotal}</p>
                   </div>
                   <div className="p-5 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex flex-col items-center justify-center shadow-inner">
                     <p className="text-4xl font-black text-emerald-500">{stats.normal}</p>
                     <p className="text-[10px] font-bold text-emerald-600/80 mt-2 uppercase tracking-widest">{t.statNormal}</p>
                   </div>
                   <div className="p-5 rounded-2xl bg-red-500/10 border border-red-500/20 flex flex-col items-center justify-center shadow-inner">
                     <p className="text-4xl font-black text-red-500">{stats.alarm}</p>
                     <p className="text-[10px] font-bold text-red-600/80 mt-2 uppercase tracking-widest">{t.statAlarm}</p>
                   </div>
                   <div className="p-5 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex flex-col items-center justify-center shadow-inner">
                     <p className="text-4xl font-black text-amber-500">{stats.maint}</p>
                     <p className="text-[10px] font-bold text-amber-600/80 mt-2 uppercase tracking-widest">{t.statMaint}</p>
                   </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                   <div className="p-4 rounded-2xl theme-input-bg border border-theme flex flex-col items-center justify-center text-center">
                     <WifiOff className="w-5 h-5 text-slate-500 mb-2 opacity-50" />
                     <p className="text-2xl font-black text-theme">{stats.offline}</p>
                     <p className="text-[9px] font-bold text-theme-muted mt-1 uppercase tracking-widest">{t.offlineBuildings}</p>
                   </div>
                   <div className="p-4 rounded-2xl theme-input-bg border border-theme flex flex-col items-center justify-center text-center">
                     <VolumeX className="w-5 h-5 text-slate-500 mb-2 opacity-50" />
                     <p className="text-2xl font-black text-theme">{stats.acknowledged}</p>
                     <p className="text-[9px] font-bold text-theme-muted mt-1 uppercase tracking-widest">{t.acknowledgedAlarms}</p>
                   </div>
                   <div className="p-4 rounded-2xl theme-input-bg border border-theme flex flex-col items-center justify-center text-center">
                     <MessageCircle className="w-5 h-5 text-slate-500 mb-2 opacity-50" />
                     <p className="text-2xl font-black text-theme">{stats.commentsCount}</p>
                     <p className="text-[9px] font-bold text-theme-muted mt-1 uppercase tracking-widest">{t.totalComments}</p>
                   </div>
                </div>

                <div className="space-y-4 pt-4 border-t border-theme">
                   <h3 className="text-xs font-black text-theme-muted uppercase tracking-widest flex items-center gap-2"><Activity className="w-4 h-4"/> نسبة استقرار المنظومة</h3>
                   <div className="w-full h-8 theme-input border-theme rounded-full overflow-hidden flex shadow-inner">
                      {stats.total === 0 ? <div className="w-full bg-slate-500/20"></div> : (
                         <>
                           <div style={{width: `${(stats.normal / stats.total) * 100}%`}} className="bg-emerald-500 h-full transition-all"></div>
                           <div style={{width: `${(stats.maint / stats.total) * 100}%`}} className="bg-amber-500 h-full transition-all"></div>
                           <div style={{width: `${(stats.out / stats.total) * 100}%`}} className="bg-slate-500 h-full transition-all"></div>
                           <div style={{width: `${(stats.alarm / stats.total) * 100}%`}} className="bg-red-500 h-full transition-all relative overflow-hidden">
                               <div className="absolute inset-0 bg-white/20 animate-pulse"></div>
                           </div>
                         </>
                      )}
                   </div>
                   <div className="flex justify-between text-[10px] font-bold text-theme-muted font-mono">
                      <span>0%</span><span>50%</span><span>100%</span>
                   </div>
                </div>
             </div>
          </div>
        </div>
      )}
      
      {hugeOfflineAlert && (
        <div className="fixed inset-0 z-[500] flex items-center justify-center p-6 no-print overflow-hidden">
          
          {/* Visual Alarm Fullscreen Background Effect */}
          {(!systemSettings.visualAlarmEffectType || systemSettings.visualAlarmEffectType === 'classic') && (
             <div className="absolute inset-0 backdrop-blur-sm bg-[#050505]/95 animate-fade-in bg-[radial-gradient(circle,rgba(239,68,68,0.2)_0%,transparent_100%)] animate-[pulse_1.5s_infinite]"></div>
          )}
          {systemSettings.visualAlarmEffectType === 'radar' && (
             <div className="absolute inset-0 backdrop-blur-sm bg-black/95 animate-fade-in flex items-center justify-center overflow-hidden">
                 <div className="w-[100vw] h-[100vw] rounded-full border-[8px] border-red-600/30 animate-[ping_2.5s_infinite_ease-out]"></div>
                 <div className="absolute w-[75vw] h-[75vw] rounded-full border-[4px] border-red-500/40 animate-[ping_2.5s_infinite_ease-out_1s]"></div>
                 <div className="absolute w-[40vw] h-[40vw] rounded-full border-[2px] border-red-400/50 animate-[ping_2.5s_infinite_ease-out_2s]"></div>
             </div>
          )}
          {systemSettings.visualAlarmEffectType === 'strobe' && (
             <div className="absolute inset-0 backdrop-blur-sm bg-[#050505]/90 animate-fade-in border-[8px] border-red-600 animate-[pulse_0.2s_infinite] bg-[radial-gradient(circle,rgba(255,0,0,0.3)_0%,transparent_100%)]"></div>
          )}
          {systemSettings.visualAlarmEffectType === 'cyber' && (
             <div className="absolute inset-0 backdrop-blur-sm bg-[#030000]/95 animate-fade-in border-4 border-red-600/60 bg-[radial-gradient(circle,rgba(220,38,38,0.2)_0%,transparent_100%)]">
                 <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0IiBoZWlnaHQ9IjQiPjxyZWN0IHdpZHRoPSI0IiBoZWlnaHQ9IjQiIGZpbGw9InRyYW5zcGFyZW50Ii8+PGxpbmUgeDE9IjAiIHkxPSIwIiB4Mj0iNCIgeTI9IjAiIHN0cm9rZT0icmdiYSgyNTUsIDAsIDAsIDAuMikiIHN0cm9rZS13aWR0aD0iMSIvPjwvc3ZnPg==')] opacity-20"></div>
                 <div className="absolute top-0 bottom-0 left-0 w-2 bg-red-500/20 opacity-60 animate-[pulse_0.5s_infinite]"></div>
                 <div className="absolute top-0 bottom-0 right-0 w-2 bg-red-500/20 opacity-60 animate-[pulse_0.5s_infinite]"></div>
             </div>
          )}
          {systemSettings.visualAlarmEffectType === 'minimal' && (
             <div className="absolute inset-0 backdrop-blur-sm bg-slate-950/95 animate-fade-in border border-red-500/30"></div>
          )}

          <div className="relative w-full max-w-2xl bg-[#080c16]/95 border-2 border-red-500 rounded-[3rem] p-8 md:p-12 shadow-[0_0_40px_rgba(239,68,68,0.3)] text-center overflow-hidden flex flex-col items-center">
            
            {/* Background flashing glow effect */}
            <div className="absolute inset-x-0 top-0 h-2 bg-gradient-to-r from-red-500 via-amber-500 to-red-500 animate-[pulse_1.5s_infinite]"></div>
            <div className="absolute -top-40 -left-40 w-96 h-96 bg-red-600/10 rounded-full blur-[120px] pointer-events-none animate-[pulse_3s_infinite]" />
            <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-red-600/10 rounded-full blur-[120px] pointer-events-none animate-[pulse_3s_infinite]" />

            {/* Style Injection for Custom Animation */}
            <style>{`
              @keyframes customGrow {
                0%, 100% { transform: scale(1); }
                50% { transform: scale(${((systemSettings as any).alertIconScale || 500) / 100}); }
              }
              @keyframes customBubble {
                0%, 100% { transform: scale(1); filter: drop-shadow(0 0 0 rgba(220, 38, 38, 0.4)); }
                30% { transform: scale(${((systemSettings as any).alertIconScale || 500) / 100}); filter: drop-shadow(0 0 40px rgba(220, 38, 38, 0.85)); }
                60% { transform: scale(0.95); filter: drop-shadow(0 0 10px rgba(220, 38, 38, 0.3)); }
              }
              .alert-icon-grow {
                animation: customGrow ${((systemSettings as any).alertAnimationDuration || 5)}s ease-in-out infinite;
              }
              .alert-icon-bubble {
                animation: customBubble ${((systemSettings as any).alertAnimationDuration || 5)}s cubic-bezier(0.25, 1, 0.5, 1) infinite;
              }
            `}</style>

            {/* Glowing / Vibrating Fire/Pulse Disconnection Alarm */}
            <div className={`relative mb-6 transition-all duration-500 ${(systemSettings as any).alertIconAnimation === 'grow' ? 'alert-icon-grow' : (systemSettings as any).alertIconAnimation === 'bubble' ? 'alert-icon-bubble' : ''}`}>
              <div className="absolute inset-0 bg-red-600/40 rounded-full blur-md opacity-40 animate-[pulse_1.5s_infinite] scale-110" />
              <div className="relative p-6 bg-red-600 border-4 border-white/10 rounded-full shadow-2xl">
                <AlertOctagon className={`w-14 h-14 text-white ${((systemSettings as any).alertIconAnimation === 'bounce' || !(systemSettings as any).alertIconAnimation) ? 'animate-bounce' : ''}`} />
              </div>
            </div>

            {/* Title & Message statement with custom admin typography styling */}
            {(() => {
              const alertTextSize = (systemSettings as any).alertTextSize || 16;
              const alertTextColor = (systemSettings as any).alertTextColor || '#ffffff';
              const alertTextStyle = (systemSettings as any).alertTextStyle || 'extrabold';
              
              let fontWeightClass = 'font-bold';
              if (alertTextStyle === 'normal') fontWeightClass = 'font-normal';
              if (alertTextStyle === 'bold') fontWeightClass = 'font-bold';
              if (alertTextStyle === 'extrabold') fontWeightClass = 'font-black';
              const isItalic = alertTextStyle === 'italic';

              const headerText = lang === 'ar'
                ? ((systemSettings as any).alertHeaderTextAr || 'إنذار انقطاع اتصال البنك - عاجل')
                : ((systemSettings as any).alertHeaderTextEn || 'CONNECTION LOST WARNING - CRITICAL');

              const bodyText = lang === 'ar'
                ? ((systemSettings as any).alertBodyTextAr || 'انقطع اتصال البنك لبناية المذكورة فوراً! يرجى فحص المنظومة ومراقبة الموقع فوراً.')
                : ((systemSettings as any).alertBodyTextEn || 'The bank connection for this building has disconnected! Please inspect the system hardware and location immediately.');

              return (
                <>
                  {/* Title block */}
                  <div className="space-y-3 z-10 w-full">
                    <span className="inline-flex items-center gap-2 px-4 py-1.5 bg-red-500/10 border border-red-500/30 text-red-500 font-extrabold text-[12px] rounded-full uppercase tracking-wider animate-pulse">
                      ⚠️ {headerText} ⚠️
                    </span>
                    
                    <h1 className="text-4xl font-extrabold text-white tracking-tight leading-tight pt-2 drop-shadow-md">
                      {hugeOfflineAlert.name}
                    </h1>
                    
                    <p className="text-red-400 font-black text-lg font-mono tracking-wide">
                      IP: {hugeOfflineAlert.ip}
                    </p>
                  </div>

                  {/* Message statement */}
                  <div className="mt-6 p-6 bg-white/[0.03] border border-white/5 rounded-2xl w-full z-10">
                    <p 
                      className={`${fontWeightClass} ${isItalic ? 'italic' : ''} leading-relaxed`}
                      style={{ 
                        fontSize: `${alertTextSize}px`, 
                        color: alertTextColor 
                      }}
                    >
                      {bodyText}
                    </p>
                  </div>
                </>
              );
            })()}

            {/* Progress counter and dismissal bar */}
            <div className="mt-8 w-full z-10">
              <div className="flex justify-between text-[11px] font-bold text-slate-400 mb-2 font-mono">
                <span>{lang === 'ar' ? 'تحديث تلقائي' : 'Auto closing'}</span>
                <span>{Math.ceil(((systemSettings as any).autoCloseTimeout || 10) * (hugeAlertProgress / 100))} {lang === 'ar' ? 'ثانية' : 'sec'}</span>
              </div>
              <div className="w-full bg-slate-800/85 rounded-full h-2.5 overflow-hidden">
                <div 
                  className="bg-red-500 h-full transition-all ease-linear"
                  style={{ width: `${hugeAlertProgress}%` }}
                />
              </div>
            </div>

            {/* Dismiss button */}
            <button 
              onClick={() => setHugeOfflineAlert(null)}
              className="mt-8 px-8 py-3 bg-red-600/20 hover:bg-red-600 text-red-500 hover:text-white rounded-xl text-xs font-black uppercase tracking-widest border border-red-500/30 transition-all active:scale-95"
            >
              {lang === 'ar' ? 'إغلاق الإشعار' : 'Dismiss Alert'}
            </button>
          </div>
        </div>
      )}

      {selectedBuilding && (userRole === 'bwe' || userRole === 'monitoring' || isFullscreen) && (
        <div className="fixed inset-0 bg-black/75 z-[150] flex items-center justify-center p-4" onClick={() => setSelectedBuildingId(null)}>
          <div className="theme-card border-theme rounded-[2.5rem] w-full max-w-md shadow-2xl p-7 space-y-6 overflow-hidden relative" onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-center pb-4 border-b border-theme">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-blue-600/10 text-blue-500">
                  <BuildingIcon iconId={selectedBuilding.icon} className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-black text-sm text-theme leading-tight">{selectedBuilding.name || 'بدون اسم'}</h3>
                  <p className="text-[10px] text-theme-muted font-mono" dir="ltr">{selectedBuilding.ip || '0.0.0.0'}</p>
                </div>
              </div>
              <button onClick={() => setSelectedBuildingId(null)} className="p-2 theme-btn rounded-full transition-all"><X className="w-4 h-4"/></button>
            </div>

            <div className="space-y-4">
              {!selectedBuilding.isOnline && selectedBuilding.acknowledged && canSilenceAlarm && (
                <button onClick={() => handleUpdateBuilding(selectedBuilding.id, {acknowledged: false})} className="w-full py-3 bg-amber-500/20 text-amber-600 dark:text-amber-400 font-black rounded-xl border border-amber-500/30 flex items-center justify-center gap-2 hover:bg-amber-500/30 transition-all shadow-md">
                  <Volume2 className="w-4 h-4"/> {t.unmute}
                </button>
              )}

              {canChangeStatus && (
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-theme-muted uppercase tracking-tight">{lang === 'ar' ? 'تغيير وضع البناية' : 'Change Building Status'}</label>
                  <select value={selectedBuilding.custom_status || 'normal'} onChange={(e)=>handleUpdateBuilding(selectedBuilding.id, {custom_status: e.target.value})} className="w-full theme-input border-theme rounded-xl px-3 py-3 text-xs font-bold outline-none cursor-pointer focus:border-blue-500/50">
                    <option value="normal">{t.statusNormal}</option>
                    <option value="maintenance">{t.statusMaint}</option>
                    <option value="out_of_service">{t.statusOut}</option>
                  </select>
                </div>
              )}

              <div className="space-y-3 pt-3 border-t border-theme">
                <label className="text-[10px] font-black text-theme-muted flex items-center gap-2 uppercase tracking-tight"><FileText className="w-4 h-4"/> {t.commentsLabel}</label>
                <div className="w-full h-28 theme-input border-theme rounded-xl p-3 overflow-y-auto custom-scrollbar flex flex-col gap-2 bg-black/5 dark:bg-white/5">
                  {selectedBuilding.comments && selectedBuilding.comments.length > 0 ? (
                    selectedBuilding.comments.map((c, idx) => (
                      <div key={idx} className="bg-black/5 dark:bg-white/5 p-2 rounded-lg border border-black/5 dark:border-white/5 flex flex-col gap-1">
                        <div className="flex justify-between items-center">
                          <span className="text-[9px] font-black text-blue-600 dark:text-blue-400">{c.user}</span>
                          <span className="text-[8px] text-theme-muted font-mono">{c.time}</span>
                        </div>
                        <p className="text-[10px] font-medium text-theme leading-relaxed">{c.text}</p>
                      </div>
                    ))
                  ) : (
                    <div className="flex-1 flex items-center justify-center text-[9px] font-bold text-theme-muted uppercase">{t.noComments}</div>
                  )}
                </div>

                <div className="flex gap-2">
                  <input 
                    type="text" 
                    value={newCommentText} 
                    onChange={(e)=>setNewCommentText(e.target.value)} 
                    onKeyDown={(e)=>{if(e.key==='Enter') { if(newCommentText) { handleUpdateBuilding(selectedBuilding.id, {new_comment: newCommentText}); setNewCommentText(''); } }}}
                    placeholder={t.commentPlaceholder} 
                    className="flex-1 theme-input border-theme rounded-xl px-3 py-2 text-[10px] outline-none" 
                  />
                  <button type="button" onClick={() => {
                    if(!newCommentText) return;
                    handleUpdateBuilding(selectedBuilding.id, {new_comment: newCommentText});
                    setNewCommentText('');
                  }} className="px-3 bg-blue-600/10 text-blue-600 dark:text-blue-400 rounded-xl border border-blue-500/30 hover:bg-blue-600/20 transition-all flex items-center justify-center">
                    <Send className="w-3.5 h-3.5"/>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {showLogsModal && (
        <div className="fixed inset-0 bg-black/80 z-[100] flex items-center justify-center p-4 no-print" onClick={()=>setShowLogsModal(false)}>
          <div className="theme-card border-theme rounded-[3rem] w-full max-w-4xl max-h-[85vh] shadow-[0_0_120px_rgba(0,0,0,0.5)] flex flex-col overflow-hidden" onClick={e=>e.stopPropagation()}>
            <div className="flex justify-between items-center p-7 border-b border-theme bg-black/5 dark:bg-white/5">
              <h2 className="font-black flex items-center gap-4 text-base text-emerald-500 uppercase tracking-widest"><ClipboardList className="w-7 h-7"/> {t.logsTitle}</h2>
              <div className="flex gap-4">
                <button onClick={handlePrintPDF} title={t.printReport} className="p-3 bg-blue-600/10 rounded-2xl text-blue-600 dark:text-blue-400 border border-blue-500/20 hover:bg-blue-600 hover:text-white transition-all shadow-lg active:scale-90"><Printer className="w-6 h-6"/></button>
                <button onClick={exportLogsToCSV} title="Export to Excel" className="p-3 bg-emerald-600/10 rounded-2xl text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 hover:bg-emerald-600 hover:text-white transition-all shadow-lg active:scale-90"><Download className="w-6 h-6"/></button>
                <button onClick={() => setShowLogsModal(false)} className="p-3 theme-btn hover:!bg-red-500/20 hover:!text-red-500 rounded-2xl transition-all"><X className="w-6 h-6"/></button>
              </div>
            </div>
            <div className="flex-1 overflow-y-auto p-8 space-y-4 custom-scrollbar bg-black/5 dark:bg-slate-950/20">
              {(!Array.isArray(logs) || logs.length === 0) ? (
                <div className="text-center py-20 text-theme-muted text-xs font-black tracking-[0.5em] uppercase animate-pulse">NO LOGS AVAILABLE</div>
              ) : logs.slice().reverse().map((l, i) => (
                <div key={i} className="theme-input border-theme p-5 rounded-3xl flex items-start gap-5 hover:border-blue-500/50 transition-all group shadow-sm">
                  <div className={`mt-2 w-2.5 h-2.5 rounded-full shadow-lg shrink-0 ${l.type === 'error' ? 'bg-red-500 animate-pulse' : l.type === 'success' ? 'bg-emerald-500' : l.type === 'warning' ? 'bg-amber-500' : 'bg-blue-500'}`}></div>
                  <div className="flex-1">
                    <p className="text-[12px] font-bold text-theme leading-relaxed">{l.message}</p>
                    <div className="flex items-center gap-4 mt-2.5 opacity-60">
                      <p className="text-[9px] text-theme-muted font-mono" dir="ltr">{l.time}</p>
                      <div className="h-px flex-1 bg-black/10 dark:bg-white/10"></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {showBrowserPingHelp && (
        <div className="fixed inset-0 bg-black/85 z-[300] flex items-center justify-center p-4 backdrop-blur-sm" onClick={() => setShowBrowserPingHelp(false)}>
          <div className="bg-slate-900 border border-white/10 rounded-[2.5rem] w-full max-w-2xl shadow-2xl overflow-hidden p-8 space-y-6 animate-fade-in" onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-center pb-4 border-b border-white/5" dir={lang === 'ar' ? 'rtl' : 'ltr'}>
              <div className="flex items-center gap-3">
                <div className="p-2 bg-amber-500/10 rounded-xl text-amber-500">
                  <ShieldAlert className="w-6 h-6"/>
                </div>
                <h2 className="font-black text-sm text-amber-500 uppercase tracking-widest">
                  {lang === 'ar' ? 'دليل حل مشكلة فحص الأجهزة المحلية (Local Ping)' : 'Local Ping Troubleshooting Guide'}
                </h2>
              </div>
              <button onClick={() => setShowBrowserPingHelp(false)} className="p-2 bg-white/5 hover:bg-white/10 rounded-full transition-all text-slate-400"><X className="w-5 h-5"/></button>
            </div>

            <div className="space-y-6 text-slate-300 overflow-y-auto max-h-[60vh] pr-2 custom-scrollbar" dir={lang === 'ar' ? 'rtl' : 'ltr'}>
              
              {/* Intro */}
              <div className="text-xs leading-relaxed space-y-2">
                <p className="font-bold text-amber-400">
                  {lang === 'ar' 
                    ? 'لماذا لا تعمل عملية الفحص المركزي لشبكتك المحلية عبر المتصفح الحالي؟' 
                    : 'Why does local network pinging not work in your current browser?'
                  }
                </p>
                <p className="opacity-80">
                  {lang === 'ar'
                    ? 'بما أنك تتصفح المنظومة عبر رابط آمن مشفر (HTTPS)، فإن المتصفحات الحديثة تطبق سياسات أمنية صارمة تسمى "حظر المحتوى المختلط" (Mixed Content Block). تمنع هذه السياسات أي موقع سحابي آمن من إرسال طلبات فحص مباشرة للأجهزة المحلية (192.168.x.x) في شبكتك الداخلية لحمايتها.'
                    : 'Since you are visiting the system over a secure (HTTPS) link, modern browsers enforce strict security policies called "Mixed Content Block". These policies prevent secure cloud web pages from communicating with local offline IPs (192.168.x.x) on your private intranet.'
                  }
                </p>
              </div>

              {/* Solution 1 */}
              <div className="p-5 rounded-2xl bg-slate-950/60 border border-white/5 space-y-3">
                <h3 className="text-sm font-black text-blue-400 flex items-center gap-2">
                  <span>🖥️</span> {lang === 'ar' ? 'الخيار الأول (الموصى به والنهائي): تشغيل برنامج الحاسبة المدمج' : 'Option 1 (Recommended): Run the Dedicated Desktop App'}
                </h3>
                <p className="text-xs leading-relaxed opacity-80">
                  {lang === 'ar'
                    ? 'تحتوي ملفات المنظومة على تطبيق حاسوب متكامل مبرمج بتقنية (Electron) يعمل كخادم محلي. عند تشغيله على الحاسبة المربوطة بالشبكة المحلية:'
                    : 'The system files contain a fully integrated desktop application built using Electron that hosts a local server. When run on the PC connected to your local network:'
                  }
                </p>
                <ul className="list-disc list-inside text-xs space-y-1 pl-4 opacity-80">
                  <li>
                    {lang === 'ar'
                      ? 'يتم الفحص باستخدام بروتوكول ICMP ping الحقيقي مباشرة من نظام التشغيل.'
                      : 'Pinging is done using native OS ICMP packets with 100% accuracy.'
                    }
                  </li>
                  <li>
                    {lang === 'ar'
                      ? 'يتفادى البرنامج قيود المتصفح الأمنية بالكامل، ويعمل على مدار الساعة بشكل آمن.'
                      : 'Bypasses browser security and mixed content blocks entirely.'
                    }
                  </li>
                  <li>
                    {lang === 'ar'
                      ? 'لتشغيله: قم بتحميل كود المصدر وتشغيل ملف (build-desktop.bat) أو تشغيل "npm run electron" محلياً.'
                      : 'To run: Download the code repository, click (build-desktop.bat) or execute "npm run electron" locally.'
                    }
                  </li>
                </ul>
              </div>

              {/* Solution 2 */}
              <div className="p-5 rounded-2xl bg-slate-950/60 border border-white/5 space-y-3">
                <h3 className="text-sm font-black text-amber-500 flex items-center gap-2">
                  <span>🌐</span> {lang === 'ar' ? 'الخيار الثاني: السماح بالمحتوى غير الآمن للموقع في المتصفح' : 'Option 2: Allow Insecure Content for this Site'}
                </h3>
                <p className="text-xs leading-relaxed opacity-80">
                  {lang === 'ar'
                    ? 'إذا كنت مضطراً لتشغيل النظام من الرابط العام الحالي وتريد فحص الأجهزة المحلية، يمكنك استثناء هذا الرابط يدوياً من قيود الحماية في متصفحك باتباع الآتي:'
                    : 'If you must use this public link and still want to query local network devices directly, you can manually whitelist this page in Chrome/Edge by following these steps:'
                  }
                </p>
                <ol className="list-decimal list-inside text-xs space-y-2 pl-4 opacity-80">
                  <li>
                    {lang === 'ar'
                      ? 'انقر على أيقونة القفل أو الإعدادات المتواجدة بجانب رابط الموقع في شريط العنوان العلوي للمتصفح.'
                      : 'Click the lock / settings icon left of the website URL in the browser address bar.'
                    }
                  </li>
                  <li>
                    {lang === 'ar'
                      ? 'اختر "إعدادات الموقع" (Site Settings) من القائمة المنسدلة.'
                      : 'Select "Site Settings" from the dropdown menu.'
                    }
                  </li>
                  <li>
                    {lang === 'ar'
                      ? 'ابحث عن خيار يسمى "المحتوى غير الآمن" (Insecure content) أو "المحتوى المختلط".'
                      : 'Find the setting labeled "Insecure content" (or Mixed Content).'
                    }
                  </li>
                  <li>
                    {lang === 'ar'
                      ? 'قم بتغيير القيمة المقابلة له من "حظر" (Block) إلى "سماح" (Allow).'
                      : 'Change the value from "Block" to "Allow".'
                    }
                  </li>
                  <li>
                    {lang === 'ar'
                      ? 'قم بإعادة تحميل صفحة النظام الحالية وسيعمل الفحص المحلي الذكي فورا.'
                      : 'Reload this browser tab and local browser pinging will start working immediately.'
                    }
                  </li>
                </ol>
              </div>

            </div>

            <div className="pt-4 border-t border-white/5 flex justify-end">
              <button 
                onClick={() => setShowBrowserPingHelp(false)} 
                className="bg-blue-600 hover:bg-blue-700 text-white font-black px-6 py-3 rounded-xl text-xs transition-all active:scale-95 shadow-lg shadow-blue-900/40"
              >
                {lang === 'ar' ? 'فهمت ذلك ⚙️' : 'Got it ⚙️'}
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="print-only hidden w-full bg-white text-black p-8" dir={lang === 'ar' ? 'rtl' : 'ltr'}>
         <div className="border-b-4 border-slate-900 pb-4 mb-8 flex justify-between items-end">
            <div>
               <h1 className="text-3xl font-black">{t.reportHeader}</h1>
               <p className="text-sm font-bold text-slate-600 mt-2">{t.appSubtitle}</p>
            </div>
            <div className="text-right">
               <p className="text-xs font-bold">{t.reportDate} {new Date().toLocaleDateString()}</p>
               <p className="text-xs font-bold">{t.reportGeneratedBy} {username}</p>
            </div>
         </div>

         <h2 className="text-xl font-black mb-4 bg-slate-200 p-2 rounded">إحصائيات عامة</h2>
         <div className="grid grid-cols-4 gap-4 mb-8">
            <div className="border p-4 text-center rounded"><p className="text-2xl font-black">{stats.total}</p><p className="text-xs font-bold">إجمالي البنايات</p></div>
            <div className="border p-4 text-center rounded"><p className="text-2xl font-black text-green-600">{stats.normal}</p><p className="text-xs font-bold">سليم</p></div>
            <div className="border p-4 text-center rounded"><p className="text-2xl font-black text-red-600">{stats.alarm}</p><p className="text-xs font-bold">إنذار/مقطوع</p></div>
            <div className="border p-4 text-center rounded"><p className="text-2xl font-black text-blue-600">{stats.maint}</p><p className="text-xs font-bold">صيانة</p></div>
         </div>

         <h2 className="text-xl font-black mb-4 bg-slate-200 p-2 rounded">آخر الأحداث في المنظومة</h2>
         <table className="w-full text-left text-sm border-collapse" dir="rtl">
            <thead>
               <tr className="bg-slate-100">
                 <th className="border p-2">الوقت</th>
                 <th className="border p-2">النوع</th>
                 <th className="border p-2">التفاصيل</th>
               </tr>
            </thead>
            <tbody>
               {(Array.isArray(logs) ? logs.slice().reverse().slice(0, 40) : []).map((l, i) => (
                  <tr key={i}>
                     <td className="border p-2 font-mono" dir="ltr">{l.time}</td>
                     <td className="border p-2 font-bold">{l.type === 'error' ? 'إنذار' : l.type === 'success' ? 'سليم' : l.type === 'warning' ? 'إجراء' : 'معلومة'}</td>
                     <td className="border p-2">{l.message}</td>
                  </tr>
               ))}
            </tbody>
         </table>
         <div className="mt-16 text-center text-xs font-bold text-slate-500">
             Central Fire Alarm Monitoring System - AUIB | {t.devCreditEn}
         </div>
      </div>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 5px; height: 5px; } 
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; } 
        .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(128,128,128,0.2); border-radius: 10px; } 
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: rgba(128,128,128,0.4); }
        
        input[type="range"]::-webkit-slider-thumb {
          -webkit-appearance: none; appearance: none; width: 14px; height: 14px;
          background: #3b82f6; border-radius: 50%; cursor: pointer; border: 2px solid #fff;
        }
        
        select { 
          background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='gray'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M19 9l-7 7-7-7'%3E%3C/path%3E%3C/svg%3E"); 
          background-position: left 0.75rem center; 
          background-repeat: no-repeat; 
          background-size: 1rem; 
        }
        [dir='ltr'] select { background-position: right 0.75rem center; }

        .dark-theme {
           --theme-bg: #020617;
           --theme-text: #f8fafc;
           --theme-text-muted: #94a3b8;
           --theme-card-bg: #0f172a;
           --theme-border: rgba(255, 255, 255, 0.1);
           --theme-input-bg: #020617;
           --theme-btn-bg: #1e293b;
           --theme-btn-hover: #334155;
        }
        .light-theme {
           --theme-bg: #f1f5f9;
           --theme-text: #0f172a;
           --theme-text-muted: #475569;
           --theme-card-bg: #ffffff;
           --theme-border: rgba(0, 0, 0, 0.1);
           --theme-input-bg: #f8fafc;
           --theme-btn-bg: #e2e8f0;
           --theme-btn-hover: #cbd5e1;
        }

        .app-wrapper { background-color: var(--theme-bg); color: var(--theme-text); }
        .theme-card { background-color: var(--theme-card-bg); }
        
        .theme-sidebar { background-color: var(--theme-card-bg); opacity: 0.95; }
        .theme-header { background-color: var(--theme-bg); opacity: 0.9; }
        
        .border-theme { border-color: var(--theme-border); }
        .text-theme { color: var(--theme-text); }
        .text-theme-muted { color: var(--theme-text-muted); }
        .theme-input { background-color: var(--theme-input-bg); color: var(--theme-text); border-color: var(--theme-border); }
        .theme-btn { background-color: var(--theme-btn-bg); color: var(--theme-text-muted); border-color: var(--theme-border); }
        .theme-btn:hover { background-color: var(--theme-btn-hover); color: var(--theme-text); }
        .theme-input-bg { background-color: var(--theme-input-bg); }

        @media print {
           .no-print { display: none !important; }
           .print-only { display: block !important; position: absolute; left: 0; top: 0; background: white; z-index: 9999; }
           body { background: white; }
        }
      `}</style>
    </div>
  );
}
