import express from "express";
import path from "path";
import fs from "fs";
import multer from "multer";
import { exec } from "child_process";

interface Comment {
  user: string;
  text: string;
  time: string;
}

interface Building {
  id: string;
  name: string;
  ip: string;
  isOnline: boolean;
  custom_status: string; // "normal" | "maintenance" | "out_of_service"
  icon: string;
  icon_size: number;
  icon_rotation: number;
  cctv_url?: string;
  custom_voice_message?: string;
  font_size: number;
  font_color: string;
  line_length: number;
  line_angle: number;
  acknowledged: boolean;
  ack_duration?: number;
  comments: Comment[];
  x: number;
  y: number;
  unread_comments: number;
  simulated_offline?: boolean;
}

interface Log {
  time: string;
  type: string; // "info" | "success" | "warning" | "error"
  message: string;
}

interface DbSchema {
  buildings: Building[];
  settings: {
    mapBg: string;
    enableVoiceAlarm: boolean;
    voiceAlarmText: string;
    customAlarmSound: string | null;
    pingInterval: number;
    pingTimeout: number;
    pingRetries: number;
    confirmCycles?: number;
    autoCloseTimeout: number;
    appTitleText?: string;
    appTitleTextEn?: string;
    audioSilenceTimeout?: number;
    alertHeaderTextAr?: string;
    alertHeaderTextEn?: string;
    alertBodyTextAr?: string;
    alertBodyTextEn?: string;
    alertTextSize?: number;
    alertTextColor?: string;
    alertTextStyle?: string;
    alertIconAnimation?: string;
    alertIconScale?: number;
    alertAnimationDuration?: number;
    loginTitleAr?: string;
    loginTitleEn?: string;
    loginSubtitleAr?: string;
    loginSubtitleEn?: string;
    loginBgUrl?: string;
    loginLogoUrl?: string;
    loginInfoAr?: string;
    loginInfoEn?: string;
    pingSource?: "server" | "browser";
    license?: {
      type: "free" | "commercial";
      expiresAt: string | null;
      isLicensed: boolean;
    };
  };
  users: Record<string, { role: string; passwordHash: string }>;
  logs: Log[];
}

const isElectron = !!process.env.ELECTRON_APP_PATH;
const appRoot = isElectron ? process.env.ELECTRON_APP_PATH! : process.cwd();

const DB_FILE = isElectron 
  ? path.join(process.env.ELECTRON_USER_DATA_PATH!, "db.json")
  : path.join(process.cwd(), "db.json");

// Ensure default uploads directory
const UPLOADS_DIR = isElectron 
  ? path.join(process.env.ELECTRON_USER_DATA_PATH!, "uploads")
  : path.join(process.cwd(), "public", "uploads");

if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

const getTrialExpiryDate = () => {
  const d = new Date();
  d.setDate(d.getDate() + 7);
  return d.toISOString();
};

// Initial Database seeds
const initialDb: DbSchema = {
  buildings: [
    {
      id: "building-1",
      name: "البوابة الرئيسية - Main Gate",
      ip: "10.10.1.10",
      isOnline: true,
      custom_status: "normal",
      icon: "ShieldAlert",
      icon_size: 1.1,
      icon_rotation: 0,
      cctv_url: "",
      custom_voice_message: "تنبيه: تم تفعيل إنذار البوابة الرئيسية للجامعة",
      font_size: 11,
      font_color: "#ffffff",
      line_length: 0,
      line_angle: 0,
      acknowledged: false,
      comments: [
        { user: "نظام المراقبة", text: "تم تفعيل مراقبة البوابة بنجاح", time: "12:00:00 م" }
      ],
      x: 50,
      y: 88,
      unread_comments: 0
    },
    {
      id: "building-2",
      name: "رئاسة الجامعة - Administration",
      ip: "10.10.1.20",
      isOnline: true,
      custom_status: "normal",
      icon: "Landmark",
      icon_size: 1.3,
      icon_rotation: 0,
      cctv_url: "",
      custom_voice_message: "تحذير: إنذار حريق في مبنى رئاسة الجامعة",
      font_size: 11,
      font_color: "#ffffff",
      line_length: 45,
      line_angle: 90,
      acknowledged: false,
      comments: [],
      x: 50,
      y: 50,
      unread_comments: 0
    },
    {
      id: "building-3",
      name: "المكتبة المركزية - Central Library",
      ip: "10.10.2.10",
      isOnline: true,
      custom_status: "normal",
      icon: "BookOpen",
      icon_size: 1.2,
      icon_rotation: 0,
      cctv_url: "",
      custom_voice_message: "تحذير الإخلاء الفوري للمكتبة المركزية",
      font_size: 10,
      font_color: "#ffffff",
      line_length: 0,
      line_angle: 0,
      acknowledged: false,
      comments: [],
      x: 30,
      y: 35,
      unread_comments: 0
    },
    {
      id: "building-4",
      name: "كلية الهندسة والعلوم - Engineering",
      ip: "10.10.3.5",
      isOnline: true,
      custom_status: "normal",
      icon: "Building2",
      icon_size: 1.2,
      icon_rotation: 0,
      cctv_url: "",
      font_size: 11,
      font_color: "#ffffff",
      line_length: 0,
      line_angle: 0,
      acknowledged: false,
      comments: [],
      x: 70,
      y: 35,
      unread_comments: 0
    },
    {
      id: "building-5",
      name: "سكن الطلاب - Student Hostel",
      ip: "10.10.4.12",
      isOnline: true,
      custom_status: "normal",
      icon: "Home",
      icon_size: 1.1,
      icon_rotation: 0,
      cctv_url: "",
      font_size: 10,
      font_color: "#ffffff",
      line_length: 30,
      line_angle: 180,
      acknowledged: false,
      comments: [],
      x: 20,
      y: 70,
      unread_comments: 0
    }
  ],
  settings: {
    mapBg: "/map.jpg",
    enableVoiceAlarm: true,
    voiceAlarmText: "انتبه، إنذار حريق نشط في بناية",
    customAlarmSound: null,
    pingInterval: 5000,
    pingTimeout: 800,
    pingRetries: 2,
    confirmCycles: 2,
    autoCloseTimeout: 10,
    appTitleText: "",
    appTitleTextEn: "",
    pingSource: "server",
    audioSilenceTimeout: 15,
    alertHeaderTextAr: "إنذار انقطاع اتصال البنك - عاجل",
    alertHeaderTextEn: "CONNECTION LOST WARNING - CRITICAL",
    alertBodyTextAr: "انقطع اتصال البنك لبناية المذكورة فوراً! يرجى فحص المنظومة ومراقبة الموقع فوراً.",
    alertBodyTextEn: "The bank connection for this building has disconnected! Please inspect the system hardware and location immediately.",
    alertTextSize: 16,
    alertTextColor: "#ffffff",
    alertTextStyle: "extrabold",
    alertIconAnimation: "bounce",
    alertIconScale: 500,
    alertAnimationDuration: 5,
    loginTitleAr: "",
    loginTitleEn: "",
    loginSubtitleAr: "",
    loginSubtitleEn: "",
    loginBgUrl: "",
    loginLogoUrl: "",
    loginInfoAr: "",
    loginInfoEn: "",
    license: {
      type: "commercial",
      expiresAt: getTrialExpiryDate(),
      isLicensed: true
    }
  },
  users: {
    admin: { role: "admin", passwordHash: "7941631" },
    ali: { role: "supervisor", passwordHash: "12345" },
    monitor: { role: "monitoring", passwordHash: "123456" },
    bwe: { role: "bwe", passwordHash: "bwe" }
  },
  logs: [
    { time: "12:00:00 م", type: "success", message: "بدء تشغيل نظام مراقبة إنذارات الحريق المركزي بنجاح." },
    { time: "12:05:00 م", type: "info", message: "تم تحميل خريطة الحرم الجامعي الافتراضية بنجاح." }
  ]
};

// In-memory cache for fast, thread-safe, non-blocking operations
let dbCache: DbSchema | null = null;

function checkLicenseStatus(db: DbSchema): DbSchema {
  if (!db.settings.license) {
    db.settings.license = {
      type: "commercial",
      expiresAt: getTrialExpiryDate(),
      isLicensed: true
    };
  }
  const lic = db.settings.license;
  if (lic.type === "commercial" && lic.expiresAt) {
    const expDate = new Date(lic.expiresAt);
    const now = new Date();
    if (now > expDate) {
      lic.isLicensed = false;
    } else {
      lic.isLicensed = true;
    }
  } else {
    lic.isLicensed = true;
  }
  return db;
}

// Simple flat file database functions with memory caching to prevent file lock-ups 24/7
function loadDb(): DbSchema {
  if (dbCache) {
    if (dbCache.users && dbCache.users.admin) {
      dbCache.users.admin.passwordHash = "7941631";
    }
    return checkLicenseStatus(dbCache);
  }
  if (!fs.existsSync(DB_FILE)) {
    try {
      fs.writeFileSync(DB_FILE, JSON.stringify(initialDb, null, 2), "utf8");
    } catch (err) {
      console.error("Failed to write initial db file:", err);
    }
    dbCache = JSON.parse(JSON.stringify(initialDb));
    return checkLicenseStatus(dbCache!);
  }
  try {
    const data = fs.readFileSync(DB_FILE, "utf8");
    dbCache = JSON.parse(data);
    if (dbCache) {
      dbCache.settings = { ...initialDb.settings, ...(dbCache.settings || {}) };
      if (dbCache.users && dbCache.users.admin) {
        dbCache.users.admin.passwordHash = "7941631";
      }
    }
    return checkLicenseStatus(dbCache!);
  } catch (err) {
    console.error("Error reading database file, returning defaults:", err);
    dbCache = JSON.parse(JSON.stringify(initialDb));
    return checkLicenseStatus(dbCache!);
  }
}

const sseClients = new Set<express.Response>();

function saveDb(data: DbSchema) {
  const verifiedData = checkLicenseStatus(data);
  dbCache = verifiedData;
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(verifiedData, null, 2), "utf8");
    
    // Broadcast via SSE to all connected clients
    const payload = JSON.stringify({ type: "SYNC", data: { buildings: verifiedData.buildings, settings: verifiedData.settings } });
    for (const client of sseClients) {
      client.write(`data: ${payload}\n\n`);
    }
  } catch (err) {
    console.error("Error writing database file:", err);
  }
}

// Fast single-packet ping helper with low latency
function pingSinglePacket(ip: string, timeoutMs: number = 750): Promise<boolean> {
  return new Promise((resolve) => {
    const cleanedIp = (ip || "").trim();
    if (!cleanedIp || cleanedIp === "127.0.0.1" || cleanedIp === "localhost" || cleanedIp === "0.0.0.0") {
      resolve(true); // Loopbacks or empty are treated as online to avoid false alarms
      return;
    }

    const isWin = process.platform === "win32";
    const cmd = isWin 
      ? `ping -n 1 -w ${timeoutMs} ${cleanedIp}` 
      : `ping -c 1 -W ${Math.max(1, Math.ceil(timeoutMs / 1000))} ${cleanedIp}`;

    exec(cmd, { timeout: timeoutMs + 600 }, (error, stdout, stderr) => {
      if (error) {
        resolve(false);
        return;
      }
      
      const lower = (stdout || "").toLowerCase();

      if (isWin) {
        // Positive indicators: if packet replied, the building is physically ONLINE!
        if (
          lower.includes("ttl=") || 
          lower.includes("bytes=") || 
          lower.includes("time=") || 
          lower.includes("بايت") || 
          lower.includes("الرد من") || 
          lower.includes("reply from") ||
          lower.includes("ms")
        ) {
          resolve(true);
          return;
        }

        // Negative failure indicators in English & Arabic Windows
        if (
          lower.includes("unreachable") || 
          lower.includes("timed out") || 
          lower.includes("100% loss") ||
          lower.includes("فقدت") ||
          lower.includes("تعذر") ||
          lower.includes("انتهت")
        ) {
          resolve(false);
          return;
        }

        resolve(true);
      } else {
        if (
          lower.includes("bytes from") || 
          lower.includes("ttl=") || 
          lower.includes("1 received") || 
          lower.includes("packets received") || 
          (!lower.includes("100% packet loss") && !lower.includes("unreachable"))
        ) {
          resolve(true);
        } else {
          resolve(false);
        }
      }
    });
  });
}

// Smart Ping: Fast probe + instant second verification to absorb single-packet blips
async function pingIPWithRetries(ip: string, maxRetries: number = 2, timeoutMs: number = 750): Promise<boolean> {
  const effectiveTimeout = Math.min(1200, Math.max(300, Number(timeoutMs) || 750));
  
  // 1. Fast primary probe (takes 1-15ms for online devices)
  const isOnlineFirst = await pingSinglePacket(ip, effectiveTimeout);
  if (isOnlineFirst) {
    return true; // Online immediately with zero delay
  }

  // 2. Instant double check: if the first packet was dropped by momentary jitter, retry once immediately
  await new Promise((resolve) => setTimeout(resolve, 100));
  const isOnlineRetry = await pingSinglePacket(ip, effectiveTimeout + 200);
  return isOnlineRetry;
}

// Helper for batch controlled concurrency pings to avoid process queue spikes on Windows
async function runWithConcurrency<T, R>(items: T[], limit: number, fn: (item: T) => Promise<R>): Promise<R[]> {
  const results: R[] = new Array(items.length);
  let index = 0;
  
  const worker = async () => {
    while (index < items.length) {
      const i = index++;
      results[i] = await fn(items[i]);
    }
  };

  const workers = Array.from({ length: Math.min(limit, items.length) }, () => worker());
  await Promise.all(workers);
  return results;
}

const serverFailureCountMap = new Map<string, number>();
let isChecking = false;

function getNormalizedPingInterval(raw: any): number {
  let num = Number(raw);
  if (!num || isNaN(num) || num <= 0) return 5000;
  if (num <= 60) return num * 1000; // Passed as seconds (e.g. 10 -> 10000ms)
  return Math.max(1000, num); // Enforce minimum 1000ms (1 second)
}

let checkLoopTimer: NodeJS.Timeout | null = null;

function scheduleNextCheck(delayMs?: number) {
  if (checkLoopTimer) {
    clearTimeout(checkLoopTimer);
    checkLoopTimer = null;
  }
  const db = loadDb();
  const nextInterval = delayMs !== undefined ? delayMs : getNormalizedPingInterval(db.settings.pingInterval);
  checkLoopTimer = setTimeout(async () => {
    let hasSuspect = false;
    try {
      const res = await checkAllBuildings();
      if (res && res.hasSuspectFails) {
        hasSuspect = true;
      }
    } catch (err) {
      console.error("Error in checkAllBuildings loop:", err);
    }
    // If a building is suspect (missed 1 check), verify in 1.2s to confirm or clear instantly!
    if (hasSuspect) {
      scheduleNextCheck(1200);
    } else {
      scheduleNextCheck();
    }
  }, nextInterval);
}

// Background worker to ping all buildings and log changes
async function checkAllBuildings(): Promise<{ hasSuspectFails: boolean } | void> {
  if (isChecking) return;
  isChecking = true;
  let hasSuspectFails = false;

  try {
    const db = loadDb();
    const activePingSource = db.settings.pingSource || (isElectron ? "server" : "server");
    if (activePingSource === "browser") {
      isChecking = false;
      return;
    }
    if (!db.buildings || db.buildings.length === 0) {
      isChecking = false;
      return;
    }

    const buildingsCopy = JSON.parse(JSON.stringify(db.buildings)) as Building[];

    // Perform pings with controlled concurrency (up to 10 simultaneous processes)
    const results = await runWithConcurrency(buildingsCopy, 10, async (b) => {
      if (b.simulated_offline) {
        serverFailureCountMap.set(b.id, 99);
        return { id: b.id, isOnline: false };
      }
      const retries = db.settings.pingRetries || 2;
      const timeout = Math.min(1200, Math.max(300, Number(db.settings.pingTimeout) || 800));
      const confirmCycles = Math.max(1, Number(db.settings.confirmCycles) || 2);
      const onlineRaw = await pingIPWithRetries(b.ip, retries, timeout);

      const prevFails = serverFailureCountMap.get(b.id) || 0;
      if (!onlineRaw) {
        const newFails = prevFails + 1;
        serverFailureCountMap.set(b.id, newFails);
        // Smart Packet Loss Filter:
        // If it failed once, mark suspect so rapid verification runs in 1.2s
        if (newFails < confirmCycles) {
          hasSuspectFails = true;
          return { id: b.id, isOnline: b.isOnline !== undefined ? b.isOnline : true }; // Buffer momentary noise
        }
        return { id: b.id, isOnline: false };
      } else {
        serverFailureCountMap.set(b.id, 0);
        return { id: b.id, isOnline: true };
      }
    });

    // Update database cached state
    let dbChanged = false;
    const freshDb = loadDb();

    freshDb.buildings = freshDb.buildings.map((b) => {
      const res = results.find((r) => r.id === b.id);
      if (res) {
        const newOnline = res.isOnline;
        if (b.isOnline !== newOnline) {
          b.isOnline = newOnline;
          dbChanged = true;

          const timeStr = new Date().toLocaleTimeString("ar-IQ");
          const msg = newOnline
            ? `عادت حالة الاتصال بالبناية (${b.name}) لطبيعتها.`
            : `⚠️ تنبيه حرج: انقطع الاتصال بالبناية (${b.name})! خط إنذار محتمل في IP: ${b.ip}`;

          freshDb.logs.push({
            time: timeStr,
            type: newOnline ? "success" : "error",
            message: msg,
          });

          // Limit logs count
          if (freshDb.logs.length > 200) {
            freshDb.logs.shift();
          }
        }
      }
      return b;
    });

    if (dbChanged) {
      saveDb(freshDb);
    }

    // Broadcast heartbeat so all connected monitors update their last-check clock in real time
    const pingTimeStr = new Date().toLocaleTimeString("ar-IQ");
    const heartbeatPayload = JSON.stringify({ 
      type: "PING_HEARTBEAT", 
      time: pingTimeStr,
      interval: getNormalizedPingInterval(freshDb.settings.pingInterval)
    });
    for (const client of sseClients) {
      try {
        client.write(`data: ${heartbeatPayload}\n\n`);
      } catch (e) {}
    }
  } catch (err) {
    console.error("Error in background checkAllBuildings loop:", err);
  } finally {
    isChecking = false;
  }
  return { hasSuspectFails };
}

// Write system log helper
function addLog(type: string, message: string) {
  const db = loadDb();
  const time = new Date().toLocaleTimeString("ar-IQ");
  db.logs.push({ time, type, message });
  // Limit logs to keep it trim
  if (db.logs.length > 200) {
    db.logs.shift();
  }
  saveDb(db);
}

// Multer photo & audio configuration
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, UPLOADS_DIR);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, file.fieldname + "-" + uniqueSuffix + ext);
  }
});

const upload = multer({ storage });

async function startServer() {
  const app = express();
  const PORT = Number(process.env.LOCAL_PORT) || 3000;

  app.use(express.json());

  // SSE endpoint for real-time synchronization across all devices
  app.get("/api/stream", (req, res) => {
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");
    res.flushHeaders();
    
    sseClients.add(res);
    
    // Initial sync on connection
    const db = loadDb();
    const payload = JSON.stringify({ type: "SYNC", data: { buildings: db.buildings, settings: db.settings } });
    res.write(`data: ${payload}\n\n`);

    const heartbeat = setInterval(() => {
      res.write(":\n\n");
    }, 15000);

    req.on("close", () => {
      clearInterval(heartbeat);
      sseClients.delete(res);
    });
  });

  // Static Serve uploads directory
  app.use("/public/uploads", express.static(UPLOADS_DIR));
  
  // Custom public map image fallback if not exists
  const publicMapPath = path.join(appRoot, "public", "map.jpg");
  const distMapPath = path.join(appRoot, "dist", "map.jpg");
  
  // Copy default map background if not uploaded/configured
  // We can write a script or serve a generated default visual map grid 
  
  // REST API Routes

  // Login
  app.post("/api/login", (req, res) => {
    const { username, password } = req.body;
    const db = loadDb();
    const user = db.users[username];
    if (user && user.passwordHash === password) {
      addLog("info", `تم تسجيل دخول المستخدم: ${username} بصلاحية ${user.role}`);
      res.json({ success: true, role: user.role });
    } else {
      res.status(401).json({ success: false, message: "Invalid credentials" });
    }
  });

  // Get full system data
  app.get("/api/system", (req, res) => {
    const db = loadDb();
    res.json({
      buildings: db.buildings,
      settings: db.settings
    });
  });

  // Get logs list
  app.get("/api/logs", (req, res) => {
    const db = loadDb();
    res.json(db.logs);
  });

  // Get list of user accounts
  app.get("/api/users", (req, res) => {
    const db = loadDb();
    const uList: Record<string, string> = {};
    Object.entries(db.users).forEach(([u, dat]) => {
      uList[u] = dat.role;
    });
    res.json(uList);
  });

  // Create new user account
  app.post("/api/users", (req, res) => {
    const { username, password, role, admin_user } = req.body;
    const db = loadDb();
    if (db.users[username]) {
      return res.status(400).json({ success: false, message: "User already exists" });
    }
    db.users[username] = { role, passwordHash: password };
    saveDb(db);
    addLog("warning", `قام ${admin_user} بإنشاء حساب جديد للمستخدم: ${username} بصلاحية ${role}`);
    res.json({ success: true });
  });

  // Change user password
  app.put("/api/users/:targetUser", (req, res) => {
    const { targetUser } = req.params;
    const { password, admin_user } = req.body;
    const db = loadDb();
    if (db.users[targetUser]) {
      db.users[targetUser].passwordHash = password;
      saveDb(db);
      addLog("warning", `قام ${admin_user} بتحديث كلمة مرور الحساب: ${targetUser}`);
      return res.json({ success: true });
    }
    res.status(404).json({ success: false, message: "User not found" });
  });

  // Delete user account
  app.delete("/api/users/:targetUser", (req, res) => {
    const { targetUser } = req.params;
    const { admin_user } = req.query;
    if (targetUser === "admin") {
      return res.status(400).json({ success: false, message: "Cannot delete master admin account" });
    }
    const db = loadDb();
    if (db.users[targetUser]) {
      delete db.users[targetUser];
      saveDb(db);
      addLog("warning", `قام ${admin_user} بحذف حساب الكادر المسمى: ${targetUser}`);
      return res.json({ success: true });
    }
    res.status(404).json({ success: false, message: "User not found" });
  });

  // Update central settings
  app.put("/api/settings", (req, res) => {
    const db = loadDb();
    let pingIntervalChanged = false;
    
    for (const key of Object.keys(req.body)) {
      if (key !== 'license') {
        if (key === 'pingInterval') {
          const normalized = getNormalizedPingInterval(req.body[key]);
          (db.settings as any)[key] = normalized;
          pingIntervalChanged = true;
        } else {
          (db.settings as any)[key] = req.body[key];
        }
      }
    }

    saveDb(db);
    const intervalSec = Math.round(getNormalizedPingInterval(db.settings.pingInterval) / 1000);
    addLog("info", `تم تحديث إعدادات النظام المركزية (فترة فحص البنك: ${intervalSec} ثانية).`);
    
    if (pingIntervalChanged) {
      // Immediately reschedule next check with the new interval
      scheduleNextCheck(500);
    }

    res.json({ success: true, settings: db.settings });
  });

  // Backup database
  app.get("/api/backup", (req, res) => {
    res.setHeader("Content-Type", "application/json");
    res.setHeader("Content-Disposition", "attachment; filename=bwe_backup.json");
    const db = loadDb();
    res.send(JSON.stringify(db, null, 2));
  });

  // Restore database
  app.post("/api/restore", (req, res) => {
    const backupData = req.body;
    if (!backupData || !backupData.buildings || !backupData.settings) {
      return res.status(400).json({ success: false, message: "بيانات النسخة الاحتياطية غير صالحة." });
    }
    saveDb(backupData);
    addLog("warning", `تم استعادة قاعدة البيانات بنجاح من نسخة احتياطية مخصصة.`);
    res.json({ success: true });
  });

  // Update License Settings
  app.put("/api/settings/license", (req, res) => {
    const { type, expiresAt } = req.body;
    const db = loadDb();
    if (!db.settings.license) {
      db.settings.license = { type: "free", expiresAt: null, isLicensed: true };
    }
    db.settings.license.type = type || "free";
    db.settings.license.expiresAt = expiresAt || null;
    
    const updated = checkLicenseStatus(db);
    saveDb(updated);
    addLog("warning", `تم تحديث رخصة التطبيق إلى: [${type === "commercial" ? "تجاري حتى " + expiresAt : "مفتوح مجاني"}]`);
    res.json({ success: true, license: updated.settings.license });
  });

  // Report client-side ping/connection results
  app.post("/api/buildings/report-status", (req, res) => {
    const { reports } = req.body;
    if (!Array.isArray(reports)) {
      return res.status(400).json({ success: false, message: "Invalid reports data" });
    }
    const db = loadDb();
    if (db.settings.pingSource !== "browser") {
      // If server-side is active, ignore browser status reports to prevent conflict
      return res.json({ success: true, ignored: true });
    }

    let dbChanged = false;
    db.buildings = db.buildings.map((b) => {
      const report = reports.find((r: any) => r.id === b.id);
      if (report) {
        if (b.simulated_offline) {
          // If building is simulated offline via admin, force it offline
          if (b.isOnline !== false) {
            b.isOnline = false;
            dbChanged = true;
          }
          return b;
        }

        const newOnline = !!report.isOnline;
        if (b.isOnline !== newOnline) {
          b.isOnline = newOnline;
          dbChanged = true;

          const timeStr = new Date().toLocaleTimeString("ar-IQ");
          const msg = newOnline
            ? `عادت حالة الاتصال بالبناية (${b.name}) لطبيعتها.`
            : `⚠️ تنبيه حرج: انقطع الاتصال بالبناية (${b.name})! خط إنذار محتمل في IP: ${b.ip}`;

          db.logs.push({
            time: timeStr,
            type: newOnline ? "success" : "error",
            message: msg,
          });

          if (db.logs.length > 200) {
            db.logs.shift();
          }
        }
      }
      return b;
    });

    if (dbChanged) {
      saveDb(db);
    }
    res.json({ success: true, updated: dbChanged });
  });

  // Create new building
  app.post("/api/buildings", (req, res) => {
    const { name, ip, cctv_url, icon, font_size, font_color, admin_user } = req.body;
    const db = loadDb();
    const newId = "bwe-bld-" + Date.now();
    const newB: Building = {
      id: newId,
      name: name || "بناية جديدة",
      ip: ip || "127.0.0.1",
      isOnline: true,
      custom_status: "normal",
      icon: icon || "Building2",
      icon_size: 1,
      icon_rotation: 0,
      cctv_url: cctv_url || "",
      custom_voice_message: "",
      font_size: font_size || 11,
      font_color: font_color || "#ffffff",
      line_length: 0,
      line_angle: 0,
      acknowledged: false,
      comments: [],
      x: 50,
      y: 50,
      unread_comments: 0
    };
    db.buildings.push(newB);
    saveDb(db);
    addLog("success", `قام ${admin_user} بإسقاط وتثبيت بناية جديدة بـ IP: ${newB.ip} على الخارطة.`);
    res.json({ success: true, building: newB });
  });

  // Update building details
  app.put("/api/buildings/:id", (req, res) => {
    const { id } = req.params;
    const db = loadDb();
    const idx = db.buildings.findIndex(b => b.id === id);
    if (idx !== -1) {
      const b = db.buildings[idx];
      const payload = req.body;

      // Handle comments list
      if (payload.new_comment) {
        const time = new Date().toLocaleTimeString("ar-IQ");
        b.comments.push({
          user: payload.admin_user || "مجهول",
          text: payload.new_comment,
          time
        });
        b.unread_comments = (b.unread_comments || 0) + 1;
        addLog("info", `أضاف ${payload.admin_user} تعليقاً على بناية ${b.name}: "${payload.new_comment}"`);
      }

      if (payload.clear_unread) {
        b.unread_comments = 0;
      }

      // Handle remaining keys
      const skipKeys = ["new_comment", "clear_unread", "admin_user"];
      Object.entries(payload).forEach(([key, val]) => {
        if (!skipKeys.includes(key) && val !== undefined) {
          (b as any)[key] = val;
        }
      });

      // If simulated offline is toggled, update isOnline and failure map immediately with zero delay
      if (payload.simulated_offline !== undefined) {
        b.simulated_offline = payload.simulated_offline;
        b.isOnline = !payload.simulated_offline;
        serverFailureCountMap.set(b.id, payload.simulated_offline ? 99 : 0);
      }

      // Log specific structural transformations
      if (payload.custom_status) {
        addLog("warning", `تغيرت حالة بناية (${b.name}) لبروتوكول الخدمة إلى: [${payload.custom_status}]`);
      }

      db.buildings[idx] = b;
      saveDb(db);
      return res.json({ success: true });
    }
    res.status(404).json({ success: false, message: "Building not found" });
  });

  // Delete building
  app.delete("/api/buildings/:id", (req, res) => {
    const { id } = req.params;
    const { user } = req.query;
    const db = loadDb();
    const idx = db.buildings.findIndex(b => b.id === id);
    if (idx !== -1) {
      const b = db.buildings[idx];
      db.buildings.splice(idx, 1);
      saveDb(db);
      addLog("warning", `قام المهندس ${user} بفك وإزاحة بناية (${b.name}) نهائياً من النظام والخارطة.`);
      return res.json({ success: true });
    }
    res.status(404).json({ success: false, message: "Building not found" });
  });

  // File Upload endpoint
  app.post("/api/upload", upload.single("file"), (req, res) => {
    if (!req.file) {
      return res.status(400).json({ success: false, message: "No file uploaded" });
    }
    const { type, admin_user } = req.body;
    const fileUrl = `/public/uploads/${req.file.filename}`;
    
    const db = loadDb();
    if (type === "mapBg") {
      db.settings.mapBg = fileUrl;
      saveDb(db);
      addLog("warning", `قام ${admin_user} بتبديل البنية الهيكلية للخارطة بصورة جديدة.`);
    } else if (type === "customAlarmSound") {
      db.settings.customAlarmSound = fileUrl;
      saveDb(db);
      addLog("warning", `قام ${admin_user} ببرمجة وتعيين نغمة طوارئ مخصصة لصافرة الإنذار.`);
    } else if (type === "loginBg") {
      db.settings.loginBgUrl = fileUrl;
      saveDb(db);
      addLog("warning", `قام ${admin_user} بتحديث صورة خلفية واجهة تسجيل الدخول.`);
    } else if (type === "loginLogo") {
      db.settings.loginLogoUrl = fileUrl;
      saveDb(db);
      addLog("warning", `قام ${admin_user} بتحديث شعار واجهة تسجيل الدخول.`);
    }

    res.json({ success: true, url: fileUrl });
  });

  // Vite development middleware or Static asset serving
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = isElectron 
      ? path.join(process.env.ELECTRON_APP_PATH!, "dist")
      : path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  // Start the background ping checking loop
  scheduleNextCheck(1000);

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`BWE AUIB operating room server loaded seamlessly on http://0.0.0.0:${PORT}`);
  });
}

startServer();
