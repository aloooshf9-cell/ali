@echo off
title Stop BWE Server
echo Stopping Node.js server...
taskkill /F /IM node.exe
taskkill /F /IM tsx.cmd
echo.
echo Server stopped successfully.
pause
