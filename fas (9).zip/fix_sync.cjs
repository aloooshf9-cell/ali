const fs = require('fs');

// Fix App.tsx fetch caching
let appTsx = fs.readFileSync('src/App.tsx', 'utf8');
const targetFetch = 'const res = await fetch(`${SERVER_URL}/api/system`);';
const replacementFetch = 'const res = await fetch(`${SERVER_URL}/api/system?_t=${Date.now()}`, { cache: "no-store" });';
if (appTsx.includes(targetFetch)) {
  appTsx = appTsx.replace(targetFetch, replacementFetch);
  fs.writeFileSync('src/App.tsx', appTsx, 'utf8');
  console.log('Fixed App.tsx fetch caching');
} else {
  console.log('Could not find target fetch in App.tsx');
}

// Fix server.ts SSE heartbeat
let serverTs = fs.readFileSync('server.ts', 'utf8');
const targetSse = `    const db = loadDb();
    const payload = JSON.stringify({ type: "SYNC", data: { buildings: db.buildings, settings: db.settings } });
    res.write(\`data: \${payload}\\n\\n\`);

    req.on("close", () => {
      sseClients.delete(res);
    });`;

const replacementSse = `    const db = loadDb();
    const payload = JSON.stringify({ type: "SYNC", data: { buildings: db.buildings, settings: db.settings } });
    res.write(\`data: \${payload}\\n\\n\`);

    const heartbeat = setInterval(() => {
      res.write(":\\n\\n");
    }, 15000);

    req.on("close", () => {
      clearInterval(heartbeat);
      sseClients.delete(res);
    });`;

if (serverTs.includes(targetSse)) {
  serverTs = serverTs.replace(targetSse, replacementSse);
  fs.writeFileSync('server.ts', serverTs, 'utf8');
  console.log('Fixed server.ts SSE heartbeat');
} else {
  console.log('Could not find target SSE in server.ts');
  console.log(serverTs.indexOf('req.on("close"'));
}
