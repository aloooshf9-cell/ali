@echo off
title BWE Server Monitor
echo ========================================
echo BWE Fire Alarm Monitoring System
echo ========================================
echo.

set IS_BG=0
if "%1"=="--bg" set IS_BG=1
if "%1"=="-bg" set IS_BG=1

cd /d "%~dp0"

:: Check if Node.js is installed
where node >nul 2>nul
if errorlevel 1 goto NO_NODE

set LOCAL_PORT=3010
set PORT=3010
set NODE_ENV=production

:: 1. If compiled production server exists, start it DIRECTLY without npm or node_modules!
:: (100% Standalone, zero npm install, zero disk space, immune to ENOSPC)
if exist dist\server.cjs (
    echo [INFO] BWE System is ready!
    echo [INFO] Starting Production Server directly on Port 3010...
    echo.
    node dist\server.cjs
    if "%IS_BG%"=="0" pause
    exit /b
)

:: 2. Fallback only if dist\server.cjs is missing
if not exist node_modules (
    echo [INFO] First time setup: Installing minimal dependencies...
    call npm install --no-audit --no-fund --ignore-scripts
    if errorlevel 1 (
        echo.
        echo ========================================================
        echo [تنبيه حرج]: فشل التثبيت بسبب امتلاء مساحة القرص الصلب (C:)!
        echo npm error ENOSPC: no space left on device
        echo يرجى تفريغ مساحة من القرص C: (تفريغ سلة المحذوفات وحذف النسخ القديمة)
        echo ========================================================
        if "%IS_BG%"=="0" pause
        exit /b
    )
)

echo.
echo Starting via tsx engine...
npx tsx server.ts

if "%IS_BG%"=="0" pause
exit /b

:NO_NODE
echo [ERROR] Node.js is not installed on your system!
echo Please download and install Node.js from: https://nodejs.org
echo After installing, please restart this build file.
echo.
if "%IS_BG%"=="0" pause
exit /b
