const fs = require('fs');

const androidFile = 'android-client/app/src/main/java/com/restaurant/signage/SyncService.kt';
let androidCode = fs.readFileSync(androidFile, 'utf8');
androidCode = androidCode.replace(/call IP Phone 547/g, 'call IT BWE support');
fs.writeFileSync(androidFile, androidCode);

const tizenFile = 'tizen-client/js/main.js';
let tizenCode = fs.readFileSync(tizenFile, 'utf8');
tizenCode = tizenCode.replace(/call IP Phone 547/g, 'call IT BWE support');
fs.writeFileSync(tizenFile, tizenCode);

console.log("Patched messages in Android and Tizen.");
