const formData = new FormData();
formData.append('file', new Blob(['test'], {type: 'text/plain'}));
formData.append('targetScreens', 'A1B2C3');
console.log([...formData.entries()]);
