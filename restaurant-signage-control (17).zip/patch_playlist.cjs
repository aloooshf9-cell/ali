const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const targetMoveItem = `  const moveItem = async (index: number, direction: number) => {
    const newPlaylist = [...playlist];
    const temp = newPlaylist[index];
    newPlaylist[index] = newPlaylist[index + direction];
    newPlaylist[index + direction] = temp;
    
    setPlaylist(newPlaylist);
    
    try {
      await fetch('/api/playlist', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ playlist: newPlaylist })
      });
    } catch (err) {
      console.error('Reorder failed', err);
    }
  };`;

const patchMoveItem = `  const moveItemInGroup = async (item: PlaylistItem, direction: number) => {
    const group = playlist.filter(p => (p.targetScreens || '') === (item.targetScreens || ''));
    const groupIndex = group.findIndex(p => p.id === item.id);
    if (groupIndex < 0) return;
    
    const targetGroupIndex = groupIndex + direction;
    if (targetGroupIndex < 0 || targetGroupIndex >= group.length) return;
    
    const itemToSwapWith = group[targetGroupIndex];
    
    const absIndex1 = playlist.findIndex(p => p.id === item.id);
    const absIndex2 = playlist.findIndex(p => p.id === itemToSwapWith.id);
    
    const newPlaylist = [...playlist];
    const temp = newPlaylist[absIndex1];
    newPlaylist[absIndex1] = newPlaylist[absIndex2];
    newPlaylist[absIndex2] = temp;
    
    setPlaylist(newPlaylist);
    
    try {
      await fetch('/api/playlist', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ playlist: newPlaylist })
      });
    } catch (err) {
      console.error('Reorder failed', err);
    }
  };`;

code = code.replace(targetMoveItem, patchMoveItem);


const targetRightColumn = `{/* Right Column (Playlist Manager) */}
          <div className="lg:col-span-2">
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 h-full">
              <h2 className="text-lg font-semibold text-slate-800 mb-4 flex items-center justify-between">
                Playlist Manager
                <span className="bg-slate-100 text-slate-600 text-xs font-medium px-2.5 py-1 rounded-full">
                  {playlist.length} items
                </span>
              </h2>
              
              {playlist.length === 0 ? (
                <div className="text-center py-12 border-2 border-dashed border-slate-200 rounded-xl">
                  <div className="bg-slate-50 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                    <ImageIcon className="w-6 h-6 text-slate-400" />
                  </div>
                  <p className="text-slate-500 text-sm">Your playlist is empty.</p>
                  <p className="text-slate-400 text-xs mt-1">Upload images or videos to get started.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {playlist.map((item, index) => {
                    const isScheduled = item.schedule && item.schedule.enabled;
                    return (
                      <div key={item.id} className="group flex flex-col sm:flex-row items-start sm:items-center gap-4 p-3 bg-slate-50 border border-slate-100 rounded-xl hover:shadow-md transition-all">
                        
                        {/* Controls */}
                        <div className="flex flex-row sm:flex-col gap-1 w-full sm:w-auto justify-between sm:justify-start order-3 sm:order-1 mt-2 sm:mt-0">
                          <div className="flex sm:flex-col gap-1">
                            <button onClick={() => moveItem(index, -1)} disabled={index === 0} className="text-slate-400 hover:text-indigo-600 disabled:opacity-30 p-1 bg-white sm:bg-transparent rounded border sm:border-0 border-slate-200">
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 15l7-7 7 7"></path></svg>
                            </button>
                            <button onClick={() => moveItem(index, 1)} disabled={index === playlist.length - 1} className="text-slate-400 hover:text-indigo-600 disabled:opacity-30 p-1 bg-white sm:bg-transparent rounded border sm:border-0 border-slate-200">
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
                            </button>
                          </div>
                          <button onClick={() => handleDelete(item.id)} className="p-1.5 sm:p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors border sm:border-0 border-slate-200 bg-white sm:bg-transparent" title="Remove from playlist">
                            <Trash2 className="w-4 h-4 sm:w-5 sm:h-5" />
                          </button>
                        </div>
                        
                        {/* Thumbnail */}
                        <div className="w-full sm:w-24 h-32 sm:h-20 rounded-lg bg-slate-200 flex-shrink-0 overflow-hidden flex items-center justify-center order-1 sm:order-2">
                          {item.type === 'image' ? (
                            <img src={item.url} alt={item.originalName} className="w-full h-full object-cover" />
                          ) : (
                            <div className="bg-slate-800 w-full h-full flex items-center justify-center">
                              <Video className="w-6 h-6 text-white" />
                            </div>
                          )}
                        </div>
                        
                        {/* Info */}
                        <div className="flex-1 min-w-0 order-2 sm:order-3 w-full">
                          <p className="text-sm font-semibold text-slate-800 truncate">{item.originalName}</p>
                          <div className="flex flex-wrap items-center gap-2 mt-1.5 text-xs text-slate-500">
                            <span className="flex items-center gap-1 bg-white px-2 py-0.5 rounded border border-slate-200">
                              {item.type === 'image' ? <ImageIcon className="w-3 h-3" /> : <Video className="w-3 h-3" />}
                              <span className="capitalize">{item.type}</span>
                            </span>
                            {item.type === 'image' && (
                              <span className="px-2 py-0.5 bg-indigo-50 text-indigo-700 rounded border border-indigo-100 font-medium">
                                {item.duration}s
                              </span>
                            )}
                            {isScheduled && (
                              <span className="px-2 py-0.5 bg-amber-50 text-amber-700 rounded border border-amber-100 font-medium flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                Scheduled
                              </span>
                            )}
                            {item.targetScreens && (
                              <span className="px-2 py-0.5 bg-blue-50 text-blue-700 rounded border border-blue-100 font-medium flex items-center gap-1" title={item.targetScreens}>
                                <MonitorPlay className="w-3 h-3" />
                                Targeted
                              </span>
                            )}
                          </div>
                          
                          {/* Schedule Details */}
                          {isScheduled && (
                            <div className="mt-2 text-[11px] text-slate-500 bg-white p-2 rounded border border-slate-100 flex flex-wrap gap-x-4 gap-y-1">
                               {item.schedule?.startDate && <span><span className="font-medium">From:</span> {item.schedule.startDate}</span>}
                               {item.schedule?.endDate && <span><span className="font-medium">Until:</span> {item.schedule.endDate}</span>}
                               {item.schedule?.startTime && <span><span className="font-medium">Time:</span> {item.schedule.startTime} to {item.schedule.endTime}</span>}
                            </div>
                          )}
                        </div>
                        
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>`;

const renderListHelper = `
          {/* Right Column (Playlist Manager) */}
          <div className="lg:col-span-2 space-y-6">
            
            {/* Helper function to render a playlist block */}
            {[
              { title: 'Global Playlist (All Screens)', items: playlist.filter(p => !p.targetScreens || p.targetScreens === ''), id: 'global' },
              ...activeScreens.map(s => ({
                  title: \`Playlist for Screen: \${s.id}\`,
                  items: playlist.filter(p => p.targetScreens === s.id),
                  id: s.id
              }))
            ].map(group => (
              <div key={group.id} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                <h2 className="text-lg font-semibold text-slate-800 mb-4 flex items-center justify-between">
                  {group.title}
                  <span className="bg-slate-100 text-slate-600 text-xs font-medium px-2.5 py-1 rounded-full">
                    {group.items.length} items
                  </span>
                </h2>
                
                {group.items.length === 0 ? (
                  <div className="text-center py-8 border-2 border-dashed border-slate-200 rounded-xl">
                    <p className="text-slate-500 text-sm">No items in this playlist.</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {group.items.map((item, index) => {
                      const isScheduled = item.schedule && item.schedule.enabled;
                      return (
                        <div key={item.id} className="group flex flex-col sm:flex-row items-start sm:items-center gap-4 p-3 bg-slate-50 border border-slate-100 rounded-xl hover:shadow-md transition-all">
                          
                          {/* Controls */}
                          <div className="flex flex-row sm:flex-col gap-1 w-full sm:w-auto justify-between sm:justify-start order-3 sm:order-1 mt-2 sm:mt-0">
                            <div className="flex sm:flex-col gap-1">
                              <button onClick={() => moveItemInGroup(item, -1)} disabled={index === 0} className="text-slate-400 hover:text-indigo-600 disabled:opacity-30 p-1 bg-white sm:bg-transparent rounded border sm:border-0 border-slate-200">
                                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 15l7-7 7 7"></path></svg>
                              </button>
                              <button onClick={() => moveItemInGroup(item, 1)} disabled={index === group.items.length - 1} className="text-slate-400 hover:text-indigo-600 disabled:opacity-30 p-1 bg-white sm:bg-transparent rounded border sm:border-0 border-slate-200">
                                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
                              </button>
                            </div>
                            <button onClick={() => handleDelete(item.id)} className="p-1.5 sm:p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors border sm:border-0 border-slate-200 bg-white sm:bg-transparent" title="Remove from playlist">
                              <Trash2 className="w-4 h-4 sm:w-5 sm:h-5" />
                            </button>
                          </div>
                          
                          {/* Thumbnail */}
                          <div className="w-full sm:w-24 h-32 sm:h-20 rounded-lg bg-slate-200 flex-shrink-0 overflow-hidden flex items-center justify-center order-1 sm:order-2">
                            {item.type === 'image' ? (
                              <img src={item.url} alt={item.originalName} className="w-full h-full object-cover" />
                            ) : (
                              <div className="bg-slate-800 w-full h-full flex items-center justify-center">
                                <Video className="w-6 h-6 text-white" />
                              </div>
                            )}
                          </div>
                          
                          {/* Info */}
                          <div className="flex-1 min-w-0 order-2 sm:order-3 w-full">
                            <p className="text-sm font-semibold text-slate-800 truncate">{item.originalName}</p>
                            <div className="flex flex-wrap items-center gap-2 mt-1.5 text-xs text-slate-500">
                              <span className="flex items-center gap-1 bg-white px-2 py-0.5 rounded border border-slate-200">
                                {item.type === 'image' ? <ImageIcon className="w-3 h-3" /> : <Video className="w-3 h-3" />}
                                <span className="capitalize">{item.type}</span>
                              </span>
                              {item.type === 'image' && (
                                <span className="px-2 py-0.5 bg-indigo-50 text-indigo-700 rounded border border-indigo-100 font-medium">
                                  {item.duration}s
                                </span>
                              )}
                              {isScheduled && (
                                <span className="px-2 py-0.5 bg-amber-50 text-amber-700 rounded border border-amber-100 font-medium flex items-center gap-1">
                                  <Clock className="w-3 h-3" />
                                  Scheduled
                                </span>
                              )}
                              {item.targetScreens && (
                                <span className="px-2 py-0.5 bg-blue-50 text-blue-700 rounded border border-blue-100 font-medium flex items-center gap-1" title={item.targetScreens}>
                                  <MonitorPlay className="w-3 h-3" />
                                  Targeted
                                </span>
                              )}
                            </div>
                            
                            {/* Schedule Details */}
                            {isScheduled && (
                              <div className="mt-2 text-[11px] text-slate-500 bg-white p-2 rounded border border-slate-100 flex flex-wrap gap-x-4 gap-y-1">
                                 {item.schedule?.startDate && <span><span className="font-medium">From:</span> {item.schedule.startDate}</span>}
                                 {item.schedule?.endDate && <span><span className="font-medium">Until:</span> {item.schedule.endDate}</span>}
                                 {item.schedule?.startTime && <span><span className="font-medium">Time:</span> {item.schedule.startTime} to {item.schedule.endTime}</span>}
                              </div>
                            )}
                          </div>
                          
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            ))}
          </div>`;

if (code.includes(targetRightColumn)) {
    code = code.replace(targetRightColumn, renderListHelper);
    fs.writeFileSync('src/App.tsx', code);
    console.log("Successfully patched Playlist Manager UI.");
} else {
    console.log("Could not find Target Right Column to patch.");
}
