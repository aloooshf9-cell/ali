const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const targetSocketOn = `  io.on('connection', (socket) => {
    console.log('Client connected:', socket.id);
    const db = getDatabase();
    socket.emit('playlist_updated', getActivePlaylist(db));
    socket.emit('settings_updated', db.settings || {});
    
    socket.on('disconnect', () => {
      console.log('Client disconnected:', socket.id);
    });
  });`;

const patchSocketOn = `  io.on('connection', (socket) => {
    const screenId = socket.handshake.query.screenId;
    const ip = socket.handshake.address;
    
    if (screenId && screenId !== 'undefined') {
        console.log('Screen connected:', screenId, 'IP:', ip);
        connectedScreens.set(socket.id, { id: screenId, ip: ip, lastSeen: new Date() });
    } else {
        console.log('Dashboard connected:', socket.id);
    }

    const db = getDatabase();
    if (screenId && screenId !== 'undefined') {
        socket.emit('playlist_updated', getActivePlaylist(db, screenId));
        socket.emit('settings_updated', db.settings || {});
    } else {
        socket.emit('playlist_updated', db.playlist); // Dashboard gets everything
    }
        
    socket.on('disconnect', () => {
      console.log('Client disconnected:', socket.id);
      if (connectedScreens.has(socket.id)) {
          connectedScreens.delete(socket.id);
      }
    });
  });`;

if (code.includes(targetSocketOn)) {
    code = code.replace(targetSocketOn, patchSocketOn);
    fs.writeFileSync('server.ts', code);
    console.log('Patched io.on successfully.');
} else {
    console.log('targetSocketOn not found. Trying regex.');
    const regex = /io\.on\('connection', \(socket\) => \{[\s\S]*?\}\);\s*\n\s*\/\//;
    const match = code.match(regex);
    if (match) {
        let rep = patchSocketOn + "\n  //";
        code = code.replace(regex, rep);
        fs.writeFileSync('server.ts', code);
        console.log('Patched io.on via regex successfully.');
    } else {
        console.log('Failed to patch io.on');
    }
}
