const fs = require('fs');
let code = fs.readFileSync('android-client/app/src/main/java/com/restaurant/signage/MainActivity.kt', 'utf8');

const targetOnDestroy = `    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(imageRunnable)
        player?.release()
        syncService.stopSync()
    }
}`;

const patchOnDestroy = `    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(imageRunnable)
        player?.release()
        syncService.stopSync()
    }
    
    // -------------------------------------------------------------
    // KIOSK MODE / IMMERSIVE ENFORCEMENT
    // -------------------------------------------------------------
    
    // 1. Prevent physical "Back" button from closing the app
    override fun onBackPressed() {
        // Do nothing! This disables the back button.
        // The app can only be closed via ADB or home button if another launcher exists.
    }
    
    // 2. Re-apply immersive mode when gaining focus (e.g., after system dialogs)
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            hideSystemUI()
        }
    }
}`;

if (code.includes(targetOnDestroy)) {
    code = code.replace(targetOnDestroy, patchOnDestroy);
    fs.writeFileSync('android-client/app/src/main/java/com/restaurant/signage/MainActivity.kt', code);
    console.log("Patched MainActivity with Kiosk features.");
} else {
    console.log("Could not find onDestroy to patch.");
}
