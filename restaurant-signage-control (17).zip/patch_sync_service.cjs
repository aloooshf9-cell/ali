const fs = require('fs');
const file = 'android-client/app/src/main/java/com/restaurant/signage/SyncService.kt';
let code = fs.readFileSync(file, 'utf8');

code = code.replace(
    'onStatusUpdate("Connecting to $SERVER_URL...")',
    'onStatusUpdate("Connecting to Server...")'
);

code = code.replace(
    'onStatusUpdate("Connection Error. Is the server running?")',
    'onStatusUpdate("Connection Error. call IP Phone 547")'
);

// In case Tizen has the same issue
const tizenFile = 'tizen-client/js/main.js';
if (fs.existsSync(tizenFile)) {
    let tizenCode = fs.readFileSync(tizenFile, 'utf8');
    tizenCode = tizenCode.replace(
        'statusMsg.textContent = "Connecting to " + serverUrl + "...";',
        'statusMsg.textContent = "Connecting to Server...";'
    );
    tizenCode = tizenCode.replace(
        'statusMsg.textContent = "Failed to reach server. Retrying in 10s...";',
        'statusMsg.textContent = "Failed to reach server. call IP Phone 547. Retrying...";'
    );
    tizenCode = tizenCode.replace(
        'statusMsg.textContent = "Disconnected from server. Retrying...";',
        'statusMsg.textContent = "Disconnected from server. call IP Phone 547. Retrying...";'
    );
    fs.writeFileSync(tizenFile, tizenCode);
}

fs.writeFileSync(file, code);
console.log("Patched SyncService and Tizen client successfully");
