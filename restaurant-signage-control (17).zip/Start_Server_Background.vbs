Set WshShell = CreateObject("WScript.Shell")
' Run the batch file completely hidden (0)
WshShell.Run chr(34) & "Start_Server.bat" & Chr(34), 0, False
Set WshShell = Nothing
