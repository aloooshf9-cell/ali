const http = require('http');

const boundary = '----WebKitFormBoundary7MA4YWxkTrZu0gW';
let data = '';

data += '--' + boundary + '\r\n';
data += 'Content-Disposition: form-data; name="targetScreens"\r\n\r\n';
data += 'SCREEN_X\r\n';

data += '--' + boundary + '\r\n';
data += 'Content-Disposition: form-data; name="file"; filename="test.txt"\r\n';
data += 'Content-Type: text/plain\r\n\r\n';
data += 'hello world\r\n';

data += '--' + boundary + '--\r\n';

const options = {
  hostname: 'localhost',
  port: 3000,
  path: '/api/upload',
  method: 'POST',
  headers: {
    'Content-Type': 'multipart/form-data; boundary=' + boundary,
    'Content-Length': Buffer.byteLength(data)
  }
};

const req = http.request(options, (res) => {
  let body = '';
  res.on('data', chunk => body += chunk);
  res.on('end', () => console.log('Response:', body));
});

req.on('error', (e) => console.error(e));
req.write(data);
req.end();
