const fs = require('fs');
let code = fs.readFileSync('android-client/app/src/main/java/com/restaurant/signage/SyncService.kt', 'utf8');

const targetCallback = `private val onSettingsUpdated: (String, Boolean) -> Unit`;
const patchCallback = `private val onSettingsUpdated: (String, Boolean, String) -> Unit`;
code = code.replace(targetCallback, patchCallback);

const targetParseSettings = `val appName = if (data.has("appName")) data.getString("appName") else "Restaurant Signage"
                    val expiryString = if (data.has("globalLicenseExpiry")) data.getString("globalLicenseExpiry") else ""
                    
                    var isExpired = false
                    if (expiryString.isNotEmpty()) {
                        try {
                            val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
                            val expiryDate = sdf.parse(expiryString)
                            if (expiryDate != null && java.util.Date().after(expiryDate)) {
                                isExpired = true
                            }
                        } catch (e: Exception) {}
                    }
                    scope.launch(Dispatchers.Main) { onSettingsUpdated(appName, isExpired) }`;

const patchParseSettings = `val appName = if (data.has("appName")) data.getString("appName") else "Restaurant Signage"
                    val expiryString = if (data.has("globalLicenseExpiry")) data.getString("globalLicenseExpiry") else ""
                    val transitionEffect = if (data.has("transitionEffect")) data.getString("transitionEffect") else "fade"
                    
                    var isExpired = false
                    if (expiryString.isNotEmpty()) {
                        try {
                            val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
                            val expiryDate = sdf.parse(expiryString)
                            if (expiryDate != null && java.util.Date().after(expiryDate)) {
                                isExpired = true
                            }
                        } catch (e: Exception) {}
                    }
                    scope.launch(Dispatchers.Main) { onSettingsUpdated(appName, isExpired, transitionEffect) }`;
code = code.replace(targetParseSettings, patchParseSettings);

fs.writeFileSync('android-client/app/src/main/java/com/restaurant/signage/SyncService.kt', code);
