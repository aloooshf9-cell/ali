const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const target = `function saveDatabase(data: any) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}`;

const patch = `
// --- Ensure Admin User Exists ---
let initialDb = getDatabase();
if (!initialDb.users || initialDb.users.length === 0) {
  initialDb.users = [{ id: '1', username: 'admin', password: '7941631', role: 'admin' }];
  saveDatabase(initialDb);
}
`;

if (code.includes(target) && !code.includes('Ensure Admin User Exists')) {
    code = code.replace(target, target + '\n' + patch);
    fs.writeFileSync('server.ts', code);
    console.log('Auth patch applied successfully.');
} else {
    console.log('Target not found or already patched.');
}
