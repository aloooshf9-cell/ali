package com.restaurant.signage

import android.content.Context
import android.util.Log
import io.socket.client.IO
import io.socket.client.Socket
import kotlinx.coroutines.*
import org.json.JSONArray
import java.io.File
import java.io.FileOutputStream
import java.net.URL

data class PlaylistItem(
    val id: String,
    val type: String,
    val duration: Int,
    val serverUrl: String,
    var localUri: String = ""
)

class SyncService(
    private val context: Context,
    private val screenId: String,
    private val onStatusUpdate: (String) -> Unit,
    private val onPlaylistUpdated: (List<PlaylistItem>) -> Unit,
    private val onSettingsUpdated: (String, Boolean, String) -> Unit,
    private val serverUrl: String
) {
    // private val serverUrl removed, passed in constructor
    private var socket: Socket? = null
    private val scope = CoroutineScope(Dispatchers.IO + Job())

    fun startSync() {
        try {
            onStatusUpdate("Connecting to Server...")
            val opts = IO.Options()
            opts.query = "screenId=$screenId"
            socket = IO.socket(serverUrl, opts)
            
            socket?.on(Socket.EVENT_CONNECT) {
                Log.d("SyncService", "Connected to Server")
                scope.launch(Dispatchers.Main) { onStatusUpdate("Connected! Waiting for playlist...") }
            }
            
            socket?.on(Socket.EVENT_CONNECT_ERROR) {
                scope.launch(Dispatchers.Main) { onStatusUpdate("Connection Error. call IT BWE support") }
            }
            
            socket?.on("playlist_updated") { args ->
                if (args.isNotEmpty()) {
                    val data = args[0] as JSONArray
                    val playlist = parsePlaylist(data)
                    if (playlist.isEmpty()) {
                        scope.launch(Dispatchers.Main) { onStatusUpdate("Playlist is empty. Please add media.") }
                    } else {
                        scope.launch(Dispatchers.Main) { onStatusUpdate("Downloading ${playlist.size} files...") }
                    }
                    syncFilesAndNotify(playlist)
                }
            }
            
            
            socket?.on("settings_updated") { args ->
                if (args.isNotEmpty()) {
                    val data = args[0] as org.json.JSONObject
                    val appName = if (data.has("appName")) data.getString("appName") else "Restaurant Signage"
                    val expiryString = if (data.has("globalLicenseExpiry")) data.getString("globalLicenseExpiry") else ""
                    val transitionEffect = if (data.has("transitionEffect")) data.getString("transitionEffect") else "fade"
                    
                    var isExpired = false
                    if (expiryString.isNotEmpty()) {
                        try {
                            val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
                            val expiryDate = sdf.parse(expiryString)
                            if (expiryDate != null && java.util.Date().after(expiryDate)) {
                                isExpired = true
                            }
                        } catch (e: Exception) {}
                    }
                    scope.launch(Dispatchers.Main) { onSettingsUpdated(appName, isExpired, transitionEffect) }
                }
            }
            socket?.connect()
        } catch (e: Exception) {
            Log.e("SyncService", "Socket Error: ${e.message}")
            onStatusUpdate("Error: ${e.message}")
        }
    }

    private fun parsePlaylist(jsonArray: JSONArray): List<PlaylistItem> {
        val list = mutableListOf<PlaylistItem>()
        for (i in 0 until jsonArray.length()) {
            val obj = jsonArray.getJSONObject(i)
            list.add(
                PlaylistItem(
                    id = obj.getString("id"),
                    type = obj.getString("type"),
                    duration = if (obj.has("duration")) obj.getInt("duration") else 10,
                    serverUrl = serverUrl + obj.getString("url")
                )
            )
        }
        return list
    }

    private fun syncFilesAndNotify(playlist: List<PlaylistItem>) {
        scope.launch {
            val cacheDir = context.cacheDir
            
            playlist.forEach { item ->
                val fileName = item.serverUrl.substringAfterLast("/")
                val localFile = File(cacheDir, fileName)
                
                if (!localFile.exists()) {
                    Log.d("SyncService", "Downloading: $fileName")
                    try {
                        URL(item.serverUrl).openStream().use { input ->
                            FileOutputStream(localFile).use { output ->
                                input.copyTo(output)
                            }
                        }
                    } catch (e: Exception) {
                        Log.e("SyncService", "Failed to download ${item.serverUrl}")
                    }
                }
                item.localUri = localFile.absolutePath
            }
            withContext(Dispatchers.Main) {
                if (playlist.isNotEmpty()) {
                    onStatusUpdate("") // Hide status when playing
                }
                onPlaylistUpdated(playlist)
            }
        }
    }

    fun stopSync() {
        socket?.disconnect()
        scope.cancel()
    }
}
