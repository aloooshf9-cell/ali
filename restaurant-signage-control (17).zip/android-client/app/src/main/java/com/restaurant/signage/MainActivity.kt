package com.restaurant.signage

import android.graphics.BitmapFactory
import android.app.AlertDialog
import android.widget.EditText
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.ui.StyledPlayerView

class MainActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    private lateinit var playerView: StyledPlayerView
    private lateinit var imageView: ImageView
    private lateinit var statusText: TextView
    private lateinit var syncService: SyncService
    private lateinit var expiredOverlay: View
    private lateinit var appNameText: TextView
    private lateinit var screenIdText: TextView
    private lateinit var screenId: String
    private var isLicenseExpired = false
    private var transitionEffect = "fade"

    private var currentPlaylist: List<PlaylistItem> = emptyList()
    private var currentIndex = 0
    private val handler = Handler(Looper.getMainLooper())
    
    private val imageRunnable = Runnable {
        playNextItem()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        hideSystemUI()
        setContentView(R.layout.activity_main)

        playerView = findViewById(R.id.player_view)
        imageView = findViewById(R.id.image_view)
        statusText = findViewById(R.id.status_text)
        expiredOverlay = findViewById(R.id.expired_overlay)
        appNameText = findViewById(R.id.app_name_text)
        screenIdText = findViewById(R.id.screen_id_text)
        
        val prefs = getSharedPreferences("SignagePrefs", android.content.Context.MODE_PRIVATE)
        var serverUrl = prefs.getString("SERVER_URL", "http://192.168.1.100:2000")!!
        screenId = prefs.getString("SCREEN_ID", null) ?: run {
            val newId = java.util.UUID.randomUUID().toString().substring(0, 6).uppercase(java.util.Locale.US)
            prefs.edit().putString("SCREEN_ID", newId).apply()
            newId
        }
        screenIdText.text = "Screen ID: $screenId"
        screenIdText.setOnLongClickListener {
            val input = EditText(this)
            input.setText(serverUrl)
            AlertDialog.Builder(this)
                .setTitle("Server URL")
                .setMessage("Enter the IP and Port of your server\n(e.g., http://192.168.1.100:2000)")
                .setView(input)
                .setPositiveButton("Save") { _, _ ->
                    val newUrl = input.text.toString()
                    prefs.edit().putString("SERVER_URL", newUrl).apply()
                    serverUrl = newUrl
                    // Restart app to apply
                    val intent = intent
                    finish()
                    startActivity(intent)
                }
                .setNegativeButton("Cancel", null)
                .show()
            true
        }


        player = ExoPlayer.Builder(this).build()
        playerView.player = player
        playerView.useController = false
        
        player?.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) {
                    playNextItem()
                }
            }
        })

        syncService = SyncService(
            context = this,
            screenId = screenId,
            onStatusUpdate = { status ->
                if (status.isEmpty()) {
                    statusText.visibility = View.GONE
                } else {
                    statusText.visibility = View.VISIBLE
                    statusText.text = status
                }
            },
            onPlaylistUpdated = { localPlaylist ->
                updatePlayerPlaylist(localPlaylist)
            },
            onSettingsUpdated = { appName, isExpired, effect ->
                appNameText.text = appName
                isLicenseExpired = isExpired
                transitionEffect = effect
                
                if (isExpired) {
                    expiredOverlay.visibility = View.VISIBLE
                    playerView.visibility = View.GONE
                    imageView.visibility = View.GONE
                    statusText.visibility = View.GONE
                    player?.pause()
                    handler.removeCallbacks(imageRunnable)
                } else {
                    expiredOverlay.visibility = View.GONE
                    if (currentPlaylist.isNotEmpty()) {
                        playCurrentItem()
                    }
                }
            },
            serverUrl = serverUrl
        )
        syncService.startSync()
    }

    private fun updatePlayerPlaylist(playlist: List<PlaylistItem>) {
        handler.removeCallbacks(imageRunnable)
        player?.stop()
        player?.clearMediaItems()
        
        currentPlaylist = playlist
        currentIndex = 0
        
        if (currentPlaylist.isNotEmpty()) {
            playCurrentItem()
        } else {
            playerView.visibility = View.GONE
            imageView.visibility = View.GONE
        }
    }

    private fun playCurrentItem() {
        if (currentPlaylist.isEmpty() || isLicenseExpired) return
        
        if (currentIndex >= currentPlaylist.size) {
            currentIndex = 0
        }
        
        val item = currentPlaylist[currentIndex]
        
        if (item.type == "image") {
            player?.stop()
            
            val bitmap = BitmapFactory.decodeFile(item.localUri)
            imageView.setImageBitmap(bitmap)
            
            if (transitionEffect == "none") {
                imageView.alpha = 1f
                imageView.visibility = View.VISIBLE
                playerView.visibility = View.GONE
            } else {
                imageView.alpha = 0f
                imageView.visibility = View.VISIBLE
                imageView.animate().alpha(1f).setDuration(1000).withEndAction {
                    playerView.visibility = View.GONE
                }.start()
                playerView.animate().alpha(0f).setDuration(1000).start()
            }
            
            val durationMs = (if (item.duration > 0) item.duration else 10) * 1000L
            handler.postDelayed(imageRunnable, durationMs)
        } else {
            handler.removeCallbacks(imageRunnable)
            
            val mediaItem = MediaItem.fromUri(item.localUri)
            player?.setMediaItem(mediaItem)
            player?.prepare()
            player?.seekTo(0)
            player?.play()
            
            if (transitionEffect == "none") {
                playerView.alpha = 1f
                playerView.visibility = View.VISIBLE
                imageView.visibility = View.GONE
            } else {
                playerView.alpha = 0f
                playerView.visibility = View.VISIBLE
                playerView.animate().alpha(1f).setDuration(1000).withEndAction {
                    imageView.visibility = View.GONE
                }.start()
                imageView.animate().alpha(0f).setDuration(1000).start()
            }
        }
    }
    
    private fun playNextItem() {
        currentIndex++
        playCurrentItem()
    }

    private fun hideSystemUI() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN)
    }

    override fun onResume() {
        super.onResume()
        hideSystemUI()
        if (currentPlaylist.isNotEmpty() && currentPlaylist[currentIndex].type == "video") {
            player?.play()
        }
    }

    override fun onPause() {
        super.onPause()
        player?.pause()
        handler.removeCallbacks(imageRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(imageRunnable)
        player?.release()
        syncService.stopSync()
    }
    
    // -------------------------------------------------------------
    // KIOSK MODE / IMMERSIVE ENFORCEMENT
    // -------------------------------------------------------------
    
    // 1. Physical "Back" button restored as requested.
    override fun onBackPressed() {
        super.onBackPressed()
    }
    
    // 2. Re-apply immersive mode when gaining focus (e.g., after system dialogs)
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            hideSystemUI()
        }
    }
}
