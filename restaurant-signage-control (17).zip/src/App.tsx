
import React, { useState, useEffect, useRef } from 'react';
import { io, Socket } from 'socket.io-client';
import { Upload, MonitorPlay, Save, Trash2, RefreshCw, Image as ImageIcon, Video, LogOut, Users, Clock, Calendar, Shield, Play, Settings, Plus } from 'lucide-react';

interface PlaylistItem {
  id: string;
  filename: string;
  originalName: string;
  type: string;
  url: string;
  duration: number;
  schedule?: {
    enabled: boolean;
    startDate: string;
    endDate: string;
    startTime: string;
    endTime: string;
  };
}

interface User {
  id: string;
  username: string;
  role: string;
  licenseExpiry?: string;
}

interface Settings {
  appName: string;
  globalLicenseExpiry: string;
  transitionEffect?: string;
}

export default function App() {
  const [playlist, setPlaylist] = useState<PlaylistItem[]>([]);
  const [connected, setConnected] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [duration, setDuration] = useState<number>(10);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Auth State
  const [user, setUser] = useState<User | null>(null);
  const [loginUsername, setLoginUsername] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState('');

  // Schedule State
  const [scheduleEnabled, setScheduleEnabled] = useState(false);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');
  
  const [targetScreensInput, setTargetScreensInput] = useState('');
  const [activeScreens, setActiveScreens] = useState<any[]>([]);
  const [editingScreenId, setEditingScreenId] = useState('');
  const [editScreenName, setEditScreenName] = useState('');
  
  const handleUpdateScreenName = async (id: string, name: string) => {
    try {
      await fetch('/api/screens/' + id + '/name', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name })
      });
      fetchScreens();
      setEditingScreenId('');
    } catch(e) {}
  };

  // Users Management State
  const [usersList, setUsersList] = useState<User[]>([]);
  const [newUsername, setNewUsername] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [newUserLicense, setNewUserLicense] = useState('');
  
  const [settings, setSettings] = useState<Settings>({ appName: 'Restaurant Signage', globalLicenseExpiry: '', transitionEffect: 'fade' });
  const [showSettings, setShowSettings] = useState(false);
  
  const [previewMode, setPreviewMode] = useState(false);
  const [currentPreviewIndex, setCurrentPreviewIndex] = useState(0);
  const previewTimer = useRef<NodeJS.Timeout | null>(null);


  useEffect(() => {
    const savedUser = localStorage.getItem('auth_user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
  }, []);

  useEffect(() => {
    if (!user) return;
    fetchPlaylist();

    let screenInterval: NodeJS.Timeout;
    
    // Everyone needs to see active screens
    fetchScreens();
    screenInterval = setInterval(fetchScreens, 10000);
    
    if (user.role === 'admin') {
      fetchUsers();
      fetchSettings();
    }

    const socket = io();
    
    socket.on('connect', () => setConnected(true));
    socket.on('disconnect', () => setConnected(false));
    socket.on('playlist_updated', () => {
      fetchPlaylist();
    });

    return () => {
      socket.disconnect();
      if (screenInterval) clearInterval(screenInterval);
    };
  }, [user]);

  const fetchPlaylist = async () => {
    try {
      const res = await fetch('/api/playlist');
      const data = await res.json();
      setPlaylist(data);
    } catch (e) {
      console.error('Failed to fetch playlist', e);
    }
  };

  
  const fetchScreens = async () => {
    try {
        const res = await fetch('/api/screens');
        const data = await res.json();
        setActiveScreens(data);
    } catch(e) {}
  };

  const fetchSettings = async () => {
    try {
      const res = await fetch('/api/settings');
      const data = await res.json();
      setSettings(data);
    } catch (e) {
      console.error(e);
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings)
      });
      setShowSettings(false);
      alert('Settings saved successfully!');
    } catch (e) {
      console.error(e);
    }
  };

  // Preview Logic
  useEffect(() => {
    if (previewMode && playlist.length > 0) {
       const item = playlist[currentPreviewIndex];
       if (item.type === 'image') {
           const duration = (item.duration || 10) * 1000;
           previewTimer.current = setTimeout(() => {
               setCurrentPreviewIndex((prev) => (prev + 1) % playlist.length);
           }, duration);
       }
    }
    return () => {
       if (previewTimer.current) clearTimeout(previewTimer.current);
    }
  }, [previewMode, currentPreviewIndex, playlist]);

  const fetchUsers = async () => {
    try {
      const res = await fetch('/api/users');
      const data = await res.json();
      setUsersList(data);
    } catch (e) {
      console.error('Failed to fetch users', e);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: loginUsername, password: loginPassword })
      });
      const data = await res.json();
      if (data.success) {
        setUser(data.user);
        localStorage.setItem('auth_user', JSON.stringify(data.user));
        setLoginError('');
      } else {
        setLoginError('Invalid username or password');
      }
    } catch (e) {
      setLoginError('Login failed');
    }
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('auth_user');
  };

  const handleAddUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUsername || !newPassword) return;
    try {
      await fetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: newUsername, password: newPassword, licenseExpiry: newUserLicense })
      });
      setNewUsername('');
      setNewPassword('');
      setNewUserLicense('');
      fetchUsers();
    } catch (e) {
      console.error(e);
    }
  };

  const handleDeleteUser = async (id: string) => {
    try {
      await fetch(`/api/users/${id}`, { method: 'DELETE' });
      fetchUsers();
    } catch (e) {
      console.error(e);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setFile(e.target.files[0]);
    }
  };

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) return;

    setUploading(true);
    const formData = new FormData();
    formData.append('duration', duration.toString());
    
    if (targetScreensInput !== '' && targetScreensInput !== 'MANUAL') {
        formData.append('targetScreens', targetScreensInput);
    }
    
    if (scheduleEnabled) {
      formData.append('schedule', JSON.stringify({
        enabled: true,
        startDate,
        endDate,
        startTime,
        endTime
      }));
    }
    
    formData.append('file', file);

    try {
      await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });
      
      setFile(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
      setScheduleEnabled(false);
      setStartDate('');
      setEndDate('');
      setStartTime('');
      setEndTime('');
      setTargetScreensInput('');
      fetchPlaylist();
    } catch (err) {
      console.error('Upload failed', err);
      alert('Upload failed. Please try again.');
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this media?')) return;
    try {
      await fetch(`/api/playlist/${id}`, { method: 'DELETE' });
      fetchPlaylist();
    } catch (err) {
      console.error('Delete failed', err);
    }
  };

  const moveItemInGroup = async (item: any, direction: number) => {
    // Find the item in the global playlist
    const globalIndex = playlist.findIndex(p => p.id === item.id);
    if (globalIndex === -1) return;
    
    // Find the items in the same target group
    const groupItems = playlist.filter(p => p.targetScreens === item.targetScreens);
    const groupIndex = groupItems.findIndex(p => p.id === item.id);
    
    if (groupIndex + direction < 0 || groupIndex + direction >= groupItems.length) return;
    
    // Find the item to swap with
    const swapTarget = groupItems[groupIndex + direction];
    const globalTargetIndex = playlist.findIndex(p => p.id === swapTarget.id);
    
    if (globalTargetIndex === -1) return;
    
    // Swap them in the global playlist
    const newPlaylist = [...playlist];
    newPlaylist[globalIndex] = swapTarget;
    newPlaylist[globalTargetIndex] = item;
    
    setPlaylist(newPlaylist);
    
    try {
      await fetch('/api/playlist', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ playlist: newPlaylist })
      });
    } catch (err) {
      console.error('Reorder failed', err);
      fetchPlaylist(); // revert on fail
    }
  };

  const moveItem = async (index: number, direction: number) => {
    const newPlaylist = [...playlist];
    const temp = newPlaylist[index];
    newPlaylist[index] = newPlaylist[index + direction];
    newPlaylist[index + direction] = temp;
    
    setPlaylist(newPlaylist);
    
    try {
      await fetch('/api/playlist', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ playlist: newPlaylist })
      });
    } catch (err) {
      console.error('Reorder failed', err);
      fetchPlaylist(); // revert on fail
    }
  };


  const handleQuickAdd = (targetId: string) => {
    setTargetScreensInput(targetId === 'global' ? '' : targetId);
    document.getElementById('upload-section')?.scrollIntoView({ behavior: 'smooth' });
    if (fileInputRef.current) {
        fileInputRef.current.click();
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
        <div className="sm:mx-auto sm:w-full sm:max-w-md">
          <div className="flex justify-center text-indigo-600 mb-4">
            <MonitorPlay className="w-16 h-16" />
          </div>
          <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
            Sign in to Dashboard
          </h2>
        </div>
        <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
          <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10 border border-slate-100">
            <form className="space-y-6" onSubmit={handleLogin}>
              {loginError && (
                <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-md text-sm">
                  {loginError}
                </div>
              )}
              <div>
                <label className="block text-sm font-medium text-gray-700">Username</label>
                <div className="mt-1">
                  <input
                    type="text"
                    required
                    value={loginUsername}
                    onChange={(e) => setLoginUsername(e.target.value)}
                    className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Password</label>
                <div className="mt-1">
                  <input
                    type="password"
                    required
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  />
                </div>
              </div>
              <div>
                <button
                  type="submit"
                  className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                >
                  Sign in
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Header */}
        <header className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 flex flex-col md:flex-row items-center justify-between mb-8">
          <div className="flex items-center gap-4 mb-4 md:mb-0">
            <div className="bg-indigo-600 text-white p-3 rounded-xl shadow-lg shadow-indigo-200">
              <MonitorPlay className="w-8 h-8" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-slate-900 tracking-tight">{settings.appName || 'Restaurant Signage'}</h1>
              <p className="text-sm text-slate-500">Central Management Dashboard</p>
            </div>
          </div>
          <div className="flex flex-col items-end gap-2">
            <div className="flex items-center gap-4">
              <div className="text-sm font-medium text-slate-700 bg-slate-100 px-3 py-1.5 rounded-full flex items-center gap-2">
                <Shield className="w-4 h-4 text-indigo-500" />
                {user.username} ({user.role})
              </div>
              
              <button 
                onClick={() => setPreviewMode(true)}
                className="text-sm font-medium text-indigo-600 hover:text-indigo-700 flex items-center gap-1 bg-indigo-50 px-3 py-1.5 rounded-full transition-colors"
              >
                <Play className="w-4 h-4" /> Preview
              </button>
              {user.role === 'admin' && (
                <button 
                  onClick={() => setShowSettings(true)}
                  className="text-sm font-medium text-slate-600 hover:text-slate-900 flex items-center gap-1 bg-slate-100 px-3 py-1.5 rounded-full transition-colors"
                >
                  <Settings className="w-4 h-4" /> Settings
                </button>
              )}
              <button 
                onClick={handleLogout}
                className="text-sm font-medium text-red-600 hover:text-red-700 flex items-center gap-1 bg-red-50 px-3 py-1.5 rounded-full transition-colors"
              >
                <LogOut className="w-4 h-4" /> Logout
              </button>
            </div>
            <div className="flex items-center gap-2 text-sm font-medium">
              <span className="relative flex h-3 w-3">
                {connected ? (
                  <>
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
                  </>
                ) : (
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
                )}
              </span>
              <span className={connected ? "text-emerald-600" : "text-red-600"}>
                {connected ? 'TV Boxes Sync Active' : 'Disconnected'}
              </span>
            </div>
          </div>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Left Column (Upload + Users) */}
          <div className="lg:col-span-1 space-y-6">
          
            {/* Active Screens Panel */}
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
              <h2 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
                <MonitorPlay className="w-5 h-5 text-indigo-500" />
                Active Screens
                <span className="bg-indigo-50 text-indigo-700 text-xs font-bold px-2 py-0.5 rounded-full ml-auto">{activeScreens.length}</span>
              </h2>
              {activeScreens.length === 0 ? (
                <p className="text-sm text-slate-500 italic">No screens currently connected.</p>
              ) : (
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {activeScreens.map((s, i) => (
                    <div key={i} className="flex flex-col bg-slate-50 p-2 rounded-lg border border-slate-100">
                      <div className="flex justify-between items-center">
                        <div className="flex flex-col">
                            <span className="text-sm font-bold text-slate-800">
                                ID: {s.id} 
                                {s.name && <span className="ml-2 text-xs font-normal text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full border border-indigo-100">{s.name}</span>}
                            </span>
                            <span className="text-[10px] text-slate-500 mt-0.5">IP: {s.ip.replace('::ffff:', '')}</span>
                        </div>
                        <span className="flex items-center gap-1 text-[10px] text-emerald-600 font-medium bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-100 mb-auto"><div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></div> Online</span>
                      </div>
                      
                      {/* Edit Name Section */}
                      <div className="mt-2 flex gap-2">
                        {editingScreenId === s.id ? (
                            <>
                                <input type="text" value={editScreenName} onChange={(e) => setEditScreenName(e.target.value)} className="flex-1 text-xs px-2 py-1 border border-slate-300 rounded outline-none" placeholder="Screen Name" />
                                <button onClick={() => handleUpdateScreenName(s.id, editScreenName)} className="text-xs bg-indigo-600 text-white px-2 py-1 rounded">Save</button>
                                <button onClick={() => setEditingScreenId('')} className="text-xs bg-slate-200 text-slate-700 px-2 py-1 rounded">Cancel</button>
                            </>
                        ) : (
                            <button onClick={() => { setEditingScreenId(s.id); setEditScreenName(s.name || ''); }} className="text-[10px] text-slate-500 hover:text-indigo-600">✎ Edit Name</button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
            
            {/* Upload Section */}
            <div id="upload-section" className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
              <h2 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
                <Upload className="w-5 h-5 text-indigo-500" />
                Upload Media
              </h2>
              
              <form onSubmit={handleUpload} className="space-y-4">
                <div className="space-y-2">
                  <label className="block text-sm font-medium text-slate-700">File (Image/Video)</label>
                  <input 
                    type="file" 
                    accept="image/*,video/*" 
                    onChange={handleFileChange}
                    ref={fileInputRef}
                    required
                    className="w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100 cursor-pointer border border-slate-200 rounded-xl p-1"
                  />
                </div>
                
                {file && file.type.startsWith('image/') && (
                  <div className="space-y-2">
                    <label className="block text-sm font-medium text-slate-700">Duration (seconds)</label>
                    <input 
                      type="number" 
                      min="1" 
                      value={duration} 
                      onChange={(e) => setDuration(Number(e.target.value))}
                      className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all text-sm"
                    />
                  </div>
                )}

                
                {/* Screen Targeting Section */}
                <div className="pt-2 border-t border-slate-100 bg-indigo-50/50 p-3 rounded-xl mb-4 border border-indigo-100">
                  <label className="block text-sm font-bold text-indigo-900 mb-2 flex items-center gap-2">
                    <MonitorPlay className="w-4 h-4 text-indigo-500" /> Choose Upload Target
                  </label>
                  <div className="space-y-3">
                      <label className="flex items-center gap-2 cursor-pointer bg-white p-2 rounded-lg border border-slate-200 hover:border-indigo-300">
                          <input type="radio" name="target" checked={targetScreensInput === ''} onChange={() => setTargetScreensInput('')} className="text-indigo-600 focus:ring-indigo-500" />
                          <span className="text-sm font-medium text-slate-700">🌎 All Screens (Global)</span>
                      </label>
                      {activeScreens.map(s => (
                          <label key={s.id} className="flex items-center gap-2 cursor-pointer bg-white p-2 rounded-lg border border-slate-200 hover:border-indigo-300">
                              <input type="radio" name="target" checked={targetScreensInput === s.id} onChange={() => setTargetScreensInput(s.id)} className="text-indigo-600 focus:ring-indigo-500" />
                              <span className="text-sm font-medium text-slate-700">📺 Specific Screen: {s.name ? `${s.name} (${s.id})` : s.id}</span>
                          </label>
                      ))}
                      <label className="flex items-center gap-2 cursor-pointer bg-white p-2 rounded-lg border border-slate-200 hover:border-indigo-300">
                          <input type="radio" name="target" checked={targetScreensInput !== '' && !activeScreens.find(s => s.id === targetScreensInput)} onChange={() => setTargetScreensInput('MANUAL')} className="text-indigo-600 focus:ring-indigo-500" />
                          <span className="text-sm font-medium text-slate-700">⌨️ Other (Offline Screen)</span>
                      </label>
                      {targetScreensInput !== '' && !activeScreens.find(s => s.id === targetScreensInput) && (
                          <input 
                            type="text" 
                            value={targetScreensInput === 'MANUAL' ? '' : targetScreensInput} 
                            onChange={(e) => setTargetScreensInput(e.target.value)} 
                            placeholder="Enter Screen ID manually (e.g. A1B2C3)" 
                            className="w-full px-4 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-sm" 
                          />
                      )}
                  </div>
                </div>
                
                <div className="pt-2 border-t border-slate-100">
                  <label className="flex items-center gap-2 cursor-pointer mb-3">
                    <input 
                      type="checkbox" 
                      checked={scheduleEnabled}
                      onChange={(e) => setScheduleEnabled(e.target.checked)}
                      className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                    />
                    <span className="text-sm font-medium text-slate-700 flex items-center gap-1">
                      <Clock className="w-4 h-4 text-slate-400" /> Custom Schedule (Optional)
                    </span>
                  </label>

                  {scheduleEnabled && (
                    <div className="grid grid-cols-2 gap-3 bg-slate-50 p-3 rounded-xl border border-slate-100">
                      <div className="col-span-2 sm:col-span-1 space-y-1">
                        <label className="text-xs font-medium text-slate-500 flex items-center gap-1"><Calendar className="w-3 h-3"/> Start Date</label>
                        <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="w-full px-2 py-1.5 border border-slate-200 rounded-lg text-xs" />
                      </div>
                      <div className="col-span-2 sm:col-span-1 space-y-1">
                        <label className="text-xs font-medium text-slate-500 flex items-center gap-1"><Calendar className="w-3 h-3"/> End Date</label>
                        <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} className="w-full px-2 py-1.5 border border-slate-200 rounded-lg text-xs" />
                      </div>
                      <div className="col-span-2 sm:col-span-1 space-y-1">
                        <label className="text-xs font-medium text-slate-500 flex items-center gap-1"><Clock className="w-3 h-3"/> Start Time</label>
                        <input type="time" value={startTime} onChange={e => setStartTime(e.target.value)} className="w-full px-2 py-1.5 border border-slate-200 rounded-lg text-xs" />
                      </div>
                      <div className="col-span-2 sm:col-span-1 space-y-1">
                        <label className="text-xs font-medium text-slate-500 flex items-center gap-1"><Clock className="w-3 h-3"/> End Time</label>
                        <input type="time" value={endTime} onChange={e => setEndTime(e.target.value)} className="w-full px-2 py-1.5 border border-slate-200 rounded-lg text-xs" />
                      </div>
                    </div>
                  )}
                </div>

                <button 
                  type="submit" 
                  disabled={!file || uploading}
                  className="w-full bg-indigo-600 text-white py-2.5 px-4 rounded-xl font-medium hover:bg-indigo-700 focus:ring-4 focus:ring-indigo-100 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 mt-4"
                >
                  {uploading ? <RefreshCw className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
                  {uploading ? 'Uploading...' : 'Save & Publish'}
                </button>
              </form>
            </div>

            {/* Users Section (Admin only) */}
            {user.role === 'admin' && (
              <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                <h2 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
                  <Users className="w-5 h-5 text-indigo-500" />
                  User Management
                </h2>
                
                <form onSubmit={handleAddUser} className="space-y-3 mb-4 flex gap-2 items-end">
                  <div className="flex-1 space-y-1">
                    <label className="block text-xs font-medium text-slate-700">Username</label>
                    <input type="text" required value={newUsername} onChange={e => setNewUsername(e.target.value)} className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none" />
                  </div>
                  <div className="flex-1 space-y-1">
                    <label className="block text-xs font-medium text-slate-700">Password</label>
                    <input type="password" required value={newPassword} onChange={e => setNewPassword(e.target.value)} className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none" />
                  </div>
                  
                  <div className="flex-1 space-y-1">
                    <label className="block text-xs font-medium text-slate-700">License Expiry</label>
                    <input type="date" value={newUserLicense} onChange={e => setNewUserLicense(e.target.value)} className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none" />
                  </div>
                  <button type="submit" className="bg-indigo-600 text-white px-3 py-1.5 rounded-lg text-sm font-medium hover:bg-indigo-700 pb-2 pt-2">
                    Add
                  </button>
                </form>

                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {usersList.map((u) => (
                    <div key={u.id} className="flex items-center justify-between bg-slate-50 p-2 rounded-lg border border-slate-100">
                      <div className="flex flex-col">
                        <span className="text-sm font-semibold text-slate-800">{u.username}</span>
                        <span className="text-xs text-slate-500 capitalize">{u.role}</span>
                        {u.licenseExpiry && <span className="text-[10px] text-red-500 font-medium mt-1">Exp: {u.licenseExpiry}</span>}
                      </div>
                      {u.role !== 'admin' && (
                        <button onClick={() => handleDeleteUser(u.id)} className="text-slate-400 hover:text-red-500">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

          </div>

          
          {/* Right Column (Playlist Manager) */}
          <div className="lg:col-span-2 space-y-6">
            
            {/* Helper function to render a playlist block */}
            {[
              { title: 'Global Playlist (All Screens)', items: playlist.filter(p => !p.targetScreens || p.targetScreens === ''), id: 'global' },
              ...Array.from(new Set(playlist.map(p => p.targetScreens).filter(ts => ts && ts !== ''))).map(ts => {
                  const screen = activeScreens.find(s => s.id === ts);
                  return {
                      title: screen && screen.name ? `Playlist for Screen: ${screen.name} (${ts})` : `Playlist for Screen: ${ts} ${!screen ? '(Offline)' : ''}`,
                      items: playlist.filter(p => p.targetScreens === ts),
                      id: String(ts)
                  };
              }),
              ...activeScreens.filter(s => !playlist.some(p => p.targetScreens === s.id)).map(s => ({
                  title: `Playlist for Screen: ${s.name ? `${s.name} (${s.id})` : s.id}`,
                  items: [],
                  id: s.id
              }))
            ].map(group => (
              <div key={group.id} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                <h2 className="text-lg font-semibold text-slate-800 mb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <span>{group.title}</span>
                  <div className="flex items-center gap-2">
                    <button onClick={() => handleQuickAdd(group.id)} className="flex items-center gap-1 bg-indigo-50 text-indigo-600 hover:bg-indigo-100 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors border border-indigo-100 shadow-sm">
                      <Plus className="w-4 h-4" /> Add Media
                    </button>
                    <span className="bg-slate-100 text-slate-600 text-xs font-medium px-2.5 py-1 rounded-full">
                      {group.items.length} items
                    </span>
                  </div>
                </h2>
                
                {group.items.length === 0 ? (
                  <div className="text-center py-8 border-2 border-dashed border-slate-200 rounded-xl">
                    <p className="text-slate-500 text-sm">No items in this playlist.</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {group.items.map((item, index) => {
                      const isScheduled = item.schedule && item.schedule.enabled;
                      return (
                        <div key={item.id} className="group flex flex-col sm:flex-row items-start sm:items-center gap-4 p-3 bg-slate-50 border border-slate-100 rounded-xl hover:shadow-md transition-all">
                          
                          {/* Controls */}
                          <div className="flex flex-row sm:flex-col gap-1 w-full sm:w-auto justify-between sm:justify-start order-3 sm:order-1 mt-2 sm:mt-0">
                            <div className="flex sm:flex-col gap-1">
                              <button onClick={() => moveItemInGroup(item, -1)} disabled={index === 0} className="text-slate-400 hover:text-indigo-600 disabled:opacity-30 p-1 bg-white sm:bg-transparent rounded border sm:border-0 border-slate-200">
                                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 15l7-7 7 7"></path></svg>
                              </button>
                              <button onClick={() => moveItemInGroup(item, 1)} disabled={index === group.items.length - 1} className="text-slate-400 hover:text-indigo-600 disabled:opacity-30 p-1 bg-white sm:bg-transparent rounded border sm:border-0 border-slate-200">
                                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
                              </button>
                            </div>
                            <button onClick={() => handleDelete(item.id)} className="p-1.5 sm:p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors border sm:border-0 border-slate-200 bg-white sm:bg-transparent" title="Remove from playlist">
                              <Trash2 className="w-4 h-4 sm:w-5 sm:h-5" />
                            </button>
                          </div>
                          
                          {/* Thumbnail */}
                          <div className="w-full sm:w-24 h-32 sm:h-20 rounded-lg bg-slate-200 flex-shrink-0 overflow-hidden flex items-center justify-center order-1 sm:order-2">
                            {item.type === 'image' ? (
                              <img src={item.url} alt={item.originalName} className="w-full h-full object-cover" />
                            ) : (
                              <div className="bg-slate-800 w-full h-full flex items-center justify-center">
                                <Video className="w-6 h-6 text-white" />
                              </div>
                            )}
                          </div>
                          
                          {/* Info */}
                          <div className="flex-1 min-w-0 order-2 sm:order-3 w-full">
                            <p className="text-sm font-semibold text-slate-800 truncate">{item.originalName}</p>
                            <div className="flex flex-wrap items-center gap-2 mt-1.5 text-xs text-slate-500">
                              <span className="flex items-center gap-1 bg-white px-2 py-0.5 rounded border border-slate-200">
                                {item.type === 'image' ? <ImageIcon className="w-3 h-3" /> : <Video className="w-3 h-3" />}
                                <span className="capitalize">{item.type}</span>
                              </span>
                              {item.type === 'image' && (
                                <span className="px-2 py-0.5 bg-indigo-50 text-indigo-700 rounded border border-indigo-100 font-medium">
                                  {item.duration}s
                                </span>
                              )}
                              {isScheduled && (
                                <span className="px-2 py-0.5 bg-amber-50 text-amber-700 rounded border border-amber-100 font-medium flex items-center gap-1">
                                  <Clock className="w-3 h-3" />
                                  Scheduled
                                </span>
                              )}
                              {item.targetScreens && (
                                <span className="px-2 py-0.5 bg-blue-50 text-blue-700 rounded border border-blue-100 font-medium flex items-center gap-1" title={item.targetScreens}>
                                  <MonitorPlay className="w-3 h-3" />
                                  Targeted
                                </span>
                              )}
                            </div>
                            
                            {/* Schedule Details */}
                            {isScheduled && (
                              <div className="mt-2 text-[11px] text-slate-500 bg-white p-2 rounded border border-slate-100 flex flex-wrap gap-x-4 gap-y-1">
                                 {item.schedule?.startDate && <span><span className="font-medium">From:</span> {item.schedule.startDate}</span>}
                                 {item.schedule?.endDate && <span><span className="font-medium">Until:</span> {item.schedule.endDate}</span>}
                                 {item.schedule?.startTime && <span><span className="font-medium">Time:</span> {item.schedule.startTime} to {item.schedule.endTime}</span>}
                              </div>
                            )}
                          </div>
                          
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      
      </div>

      {/* Preview Modal */}
      {previewMode && playlist.length > 0 && (
        <div className="fixed inset-0 z-50 bg-black flex flex-col">
           <div className="absolute top-4 right-4 z-50 flex gap-4">
              <button onClick={() => setPreviewMode(false)} className="bg-white/20 hover:bg-white/40 text-white px-4 py-2 rounded-full backdrop-blur-sm transition-all font-medium">
                Close Preview
              </button>
           </div>
           <div className="flex-1 flex items-center justify-center relative">
              {playlist[currentPreviewIndex].type === 'image' ? (
                 <img src={playlist[currentPreviewIndex].url} className="max-w-full max-h-full object-contain" />
              ) : (
                 <video 
                    src={playlist[currentPreviewIndex].url} 
                    autoPlay 
                    muted 
                    className="max-w-full max-h-full"
                    onEnded={() => setCurrentPreviewIndex((prev) => (prev + 1) % playlist.length)}
                 />
              )}
           </div>
        </div>
      )}

      {/* Settings Modal */}
      {showSettings && user.role === 'admin' && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
           <div className="bg-white rounded-2xl w-full max-w-md p-6 shadow-xl">
              <h2 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-2"><Settings className="w-5 h-5 text-indigo-500" /> App Settings</h2>
              <form onSubmit={handleSaveSettings} className="space-y-4">
                 <div className="space-y-2">
                    <label className="block text-sm font-medium text-slate-700">App/Restaurant Name</label>
                    <input type="text" required value={settings.appName} onChange={e => setSettings({...settings, appName: e.target.value})} className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none" />
                 </div>
                 <div className="space-y-2">
                    <label className="block text-sm font-medium text-slate-700">Global License Expiry (Servers & TVs)</label>
                    <input type="date" value={settings.globalLicenseExpiry} onChange={e => setSettings({...settings, globalLicenseExpiry: e.target.value})} className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none" />
                    <p className="text-xs text-slate-500">If set, TV boxes will lock after this date until renewed.</p>
                 </div>
                 <div className="space-y-2">
                    <label className="block text-sm font-medium text-slate-700">Ad Transition Effect</label>
                    <select value={settings.transitionEffect || 'fade'} onChange={e => setSettings({...settings, transitionEffect: e.target.value})} className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none">
                        <option value="none">None (Instant Cut)</option>
                        <option value="fade">Cross-Fade (Smooth Transition)</option>
                    </select>
                 </div>
                 <div className="flex justify-end gap-3 mt-6">
                    <button type="button" onClick={() => setShowSettings(false)} className="px-4 py-2 text-slate-600 font-medium hover:bg-slate-100 rounded-xl">Cancel</button>
                    <button type="submit" className="px-4 py-2 bg-indigo-600 text-white font-medium hover:bg-indigo-700 rounded-xl">Save Settings</button>
                 </div>
              </form>
           </div>
        </div>
      )}

    </div>
  );
}
