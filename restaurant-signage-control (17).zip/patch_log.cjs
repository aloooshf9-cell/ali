const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

code = code.replace(
    `const targetScreens = req.body.targetScreens || '';`,
    `const targetScreens = req.body.targetScreens || '';\n    console.log('[UPLOAD] Received file:', req.file?.originalname, 'Target:', targetScreens);`
);

fs.writeFileSync('server.ts', code);
