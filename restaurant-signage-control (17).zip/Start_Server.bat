@echo off
echo ==========================================
echo Starting Restaurant Signage Server (Production Mode)
echo ==========================================
IF NOT EXIST "node_modules\" (
    echo Installing dependencies for the first time. Please wait...
    call npm install
)

IF NOT EXIST "dist\server.cjs" (
    echo Building the application for production...
    call npm run build
)

echo Starting server...
call npm run start
