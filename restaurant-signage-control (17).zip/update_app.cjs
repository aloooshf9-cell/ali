const fs = require('fs');

const appContent = `
import React, { useState, useEffect, useRef } from 'react';
import { io, Socket } from 'socket.io-client';
import { Upload, MonitorPlay, Save, Trash2, RefreshCw, Image as ImageIcon, Video, LogOut, Users, Clock, Calendar, Shield } from 'lucide-react';

interface PlaylistItem {
  id: string;
  filename: string;
  originalName: string;
  type: string;
  url: string;
  duration: number;
  schedule?: {
    enabled: boolean;
    startDate: string;
    endDate: string;
    startTime: string;
    endTime: string;
  };
}

interface User {
  id: string;
  username: string;
  role: string;
}

export default function App() {
  const [playlist, setPlaylist] = useState<PlaylistItem[]>([]);
  const [connected, setConnected] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [duration, setDuration] = useState<number>(10);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Auth State
  const [user, setUser] = useState<User | null>(null);
  const [loginUsername, setLoginUsername] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState('');

  // Schedule State
  const [scheduleEnabled, setScheduleEnabled] = useState(false);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');

  // Users Management State
  const [usersList, setUsersList] = useState<User[]>([]);
  const [newUsername, setNewUsername] = useState('');
  const [newPassword, setNewPassword] = useState('');

  useEffect(() => {
    const savedUser = localStorage.getItem('auth_user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
  }, []);

  useEffect(() => {
    if (!user) return;

    fetchPlaylist();
    if (user.role === 'admin') {
      fetchUsers();
    }

    const socket: Socket = io();
    
    socket.on('connect', () => setConnected(true));
    socket.on('disconnect', () => setConnected(false));
    socket.on('playlist_updated', (data: PlaylistItem[]) => {
      // In the real world we might just fetch the full list so we can edit scheduled ones
      fetchPlaylist();
    });

    return () => {
      socket.disconnect();
    };
  }, [user]);

  const fetchPlaylist = async () => {
    try {
      const res = await fetch('/api/playlist');
      const data = await res.json();
      setPlaylist(data);
    } catch (e) {
      console.error('Failed to fetch playlist', e);
    }
  };

  const fetchUsers = async () => {
    try {
      const res = await fetch('/api/users');
      const data = await res.json();
      setUsersList(data);
    } catch (e) {
      console.error('Failed to fetch users', e);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: loginUsername, password: loginPassword })
      });
      const data = await res.json();
      if (data.success) {
        setUser(data.user);
        localStorage.setItem('auth_user', JSON.stringify(data.user));
        setLoginError('');
      } else {
        setLoginError('Invalid username or password');
      }
    } catch (e) {
      setLoginError('Login failed');
    }
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('auth_user');
  };

  const handleAddUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUsername || !newPassword) return;
    try {
      await fetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: newUsername, password: newPassword })
      });
      setNewUsername('');
      setNewPassword('');
      fetchUsers();
    } catch (e) {
      console.error(e);
    }
  };

  const handleDeleteUser = async (id: string) => {
    try {
      await fetch(\`/api/users/\${id}\`, { method: 'DELETE' });
      fetchUsers();
    } catch (e) {
      console.error(e);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setFile(e.target.files[0]);
    }
  };

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) return;

    setUploading(true);
    const formData = new FormData();
    formData.append('file', file);
    formData.append('duration', duration.toString());
    
    if (scheduleEnabled) {
      formData.append('schedule', JSON.stringify({
        enabled: true,
        startDate,
        endDate,
        startTime,
        endTime
      }));
    }

    try {
      await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });
      
      setFile(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
      setScheduleEnabled(false);
      setStartDate('');
      setEndDate('');
      setStartTime('');
      setEndTime('');
      fetchPlaylist();
    } catch (err) {
      console.error('Upload failed', err);
      alert('Upload failed. Please try again.');
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this media?')) return;
    try {
      await fetch(\`/api/playlist/\${id}\`, { method: 'DELETE' });
      fetchPlaylist();
    } catch (err) {
      console.error('Delete failed', err);
    }
  };

  const moveItem = async (index: number, direction: number) => {
    const newPlaylist = [...playlist];
    const temp = newPlaylist[index];
    newPlaylist[index] = newPlaylist[index + direction];
    newPlaylist[index + direction] = temp;
    
    setPlaylist(newPlaylist);
    
    try {
      await fetch('/api/playlist', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ playlist: newPlaylist })
      });
    } catch (err) {
      console.error('Reorder failed', err);
      fetchPlaylist(); // revert on fail
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
        <div className="sm:mx-auto sm:w-full sm:max-w-md">
          <div className="flex justify-center text-indigo-600 mb-4">
            <MonitorPlay className="w-16 h-16" />
          </div>
          <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
            Sign in to Dashboard
          </h2>
        </div>
        <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
          <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10 border border-slate-100">
            <form className="space-y-6" onSubmit={handleLogin}>
              {loginError && (
                <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-md text-sm">
                  {loginError}
                </div>
              )}
              <div>
                <label className="block text-sm font-medium text-gray-700">Username</label>
                <div className="mt-1">
                  <input
                    type="text"
                    required
                    value={loginUsername}
                    onChange={(e) => setLoginUsername(e.target.value)}
                    className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Password</label>
                <div className="mt-1">
                  <input
                    type="password"
                    required
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  />
                </div>
              </div>
              <div>
                <button
                  type="submit"
                  className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                >
                  Sign in
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Header */}
        <header className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 flex flex-col md:flex-row items-center justify-between mb-8">
          <div className="flex items-center gap-4 mb-4 md:mb-0">
            <div className="bg-indigo-600 text-white p-3 rounded-xl shadow-lg shadow-indigo-200">
              <MonitorPlay className="w-8 h-8" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Restaurant Signage</h1>
              <p className="text-sm text-slate-500">Central Management Dashboard</p>
            </div>
          </div>
          <div className="flex flex-col items-end gap-2">
            <div className="flex items-center gap-4">
              <div className="text-sm font-medium text-slate-700 bg-slate-100 px-3 py-1.5 rounded-full flex items-center gap-2">
                <Shield className="w-4 h-4 text-indigo-500" />
                {user.username} ({user.role})
              </div>
              <button 
                onClick={handleLogout}
                className="text-sm font-medium text-red-600 hover:text-red-700 flex items-center gap-1 bg-red-50 px-3 py-1.5 rounded-full transition-colors"
              >
                <LogOut className="w-4 h-4" /> Logout
              </button>
            </div>
            <div className="flex items-center gap-2 text-sm font-medium">
              <span className="relative flex h-3 w-3">
                {connected ? (
                  <>
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
                  </>
                ) : (
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
                )}
              </span>
              <span className={connected ? "text-emerald-600" : "text-red-600"}>
                {connected ? 'TV Boxes Sync Active' : 'Disconnected'}
              </span>
            </div>
          </div>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Left Column (Upload + Users) */}
          <div className="lg:col-span-1 space-y-6">
            
            {/* Upload Section */}
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
              <h2 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
                <Upload className="w-5 h-5 text-indigo-500" />
                Upload Media
              </h2>
              
              <form onSubmit={handleUpload} className="space-y-4">
                <div className="space-y-2">
                  <label className="block text-sm font-medium text-slate-700">File (Image/Video)</label>
                  <input 
                    type="file" 
                    accept="image/*,video/*" 
                    onChange={handleFileChange}
                    ref={fileInputRef}
                    required
                    className="w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100 cursor-pointer border border-slate-200 rounded-xl p-1"
                  />
                </div>
                
                {file && file.type.startsWith('image/') && (
                  <div className="space-y-2">
                    <label className="block text-sm font-medium text-slate-700">Duration (seconds)</label>
                    <input 
                      type="number" 
                      min="1" 
                      value={duration} 
                      onChange={(e) => setDuration(Number(e.target.value))}
                      className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all text-sm"
                    />
                  </div>
                )}

                <div className="pt-2 border-t border-slate-100">
                  <label className="flex items-center gap-2 cursor-pointer mb-3">
                    <input 
                      type="checkbox" 
                      checked={scheduleEnabled}
                      onChange={(e) => setScheduleEnabled(e.target.checked)}
                      className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                    />
                    <span className="text-sm font-medium text-slate-700 flex items-center gap-1">
                      <Clock className="w-4 h-4 text-slate-400" /> Custom Schedule (Optional)
                    </span>
                  </label>

                  {scheduleEnabled && (
                    <div className="grid grid-cols-2 gap-3 bg-slate-50 p-3 rounded-xl border border-slate-100">
                      <div className="col-span-2 sm:col-span-1 space-y-1">
                        <label className="text-xs font-medium text-slate-500 flex items-center gap-1"><Calendar className="w-3 h-3"/> Start Date</label>
                        <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="w-full px-2 py-1.5 border border-slate-200 rounded-lg text-xs" />
                      </div>
                      <div className="col-span-2 sm:col-span-1 space-y-1">
                        <label className="text-xs font-medium text-slate-500 flex items-center gap-1"><Calendar className="w-3 h-3"/> End Date</label>
                        <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} className="w-full px-2 py-1.5 border border-slate-200 rounded-lg text-xs" />
                      </div>
                      <div className="col-span-2 sm:col-span-1 space-y-1">
                        <label className="text-xs font-medium text-slate-500 flex items-center gap-1"><Clock className="w-3 h-3"/> Start Time</label>
                        <input type="time" value={startTime} onChange={e => setStartTime(e.target.value)} className="w-full px-2 py-1.5 border border-slate-200 rounded-lg text-xs" />
                      </div>
                      <div className="col-span-2 sm:col-span-1 space-y-1">
                        <label className="text-xs font-medium text-slate-500 flex items-center gap-1"><Clock className="w-3 h-3"/> End Time</label>
                        <input type="time" value={endTime} onChange={e => setEndTime(e.target.value)} className="w-full px-2 py-1.5 border border-slate-200 rounded-lg text-xs" />
                      </div>
                    </div>
                  )}
                </div>

                <button 
                  type="submit" 
                  disabled={!file || uploading}
                  className="w-full bg-indigo-600 text-white py-2.5 px-4 rounded-xl font-medium hover:bg-indigo-700 focus:ring-4 focus:ring-indigo-100 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 mt-4"
                >
                  {uploading ? <RefreshCw className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
                  {uploading ? 'Uploading...' : 'Save & Publish'}
                </button>
              </form>
            </div>

            {/* Users Section (Admin only) */}
            {user.role === 'admin' && (
              <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                <h2 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
                  <Users className="w-5 h-5 text-indigo-500" />
                  User Management
                </h2>
                
                <form onSubmit={handleAddUser} className="space-y-3 mb-4 flex gap-2 items-end">
                  <div className="flex-1 space-y-1">
                    <label className="block text-xs font-medium text-slate-700">Username</label>
                    <input type="text" required value={newUsername} onChange={e => setNewUsername(e.target.value)} className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none" />
                  </div>
                  <div className="flex-1 space-y-1">
                    <label className="block text-xs font-medium text-slate-700">Password</label>
                    <input type="password" required value={newPassword} onChange={e => setNewPassword(e.target.value)} className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none" />
                  </div>
                  <button type="submit" className="bg-indigo-600 text-white px-3 py-1.5 rounded-lg text-sm font-medium hover:bg-indigo-700 pb-2 pt-2">
                    Add
                  </button>
                </form>

                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {usersList.map((u) => (
                    <div key={u.id} className="flex items-center justify-between bg-slate-50 p-2 rounded-lg border border-slate-100">
                      <div className="flex flex-col">
                        <span className="text-sm font-semibold text-slate-800">{u.username}</span>
                        <span className="text-xs text-slate-500 capitalize">{u.role}</span>
                      </div>
                      {u.role !== 'admin' && (
                        <button onClick={() => handleDeleteUser(u.id)} className="text-slate-400 hover:text-red-500">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

          </div>

          {/* Right Column (Playlist Manager) */}
          <div className="lg:col-span-2">
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 h-full">
              <h2 className="text-lg font-semibold text-slate-800 mb-4 flex items-center justify-between">
                Playlist Manager
                <span className="bg-slate-100 text-slate-600 text-xs font-medium px-2.5 py-1 rounded-full">
                  {playlist.length} items
                </span>
              </h2>
              
              {playlist.length === 0 ? (
                <div className="text-center py-12 border-2 border-dashed border-slate-200 rounded-xl">
                  <div className="bg-slate-50 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                    <ImageIcon className="w-6 h-6 text-slate-400" />
                  </div>
                  <p className="text-slate-500 text-sm">Your playlist is empty.</p>
                  <p className="text-slate-400 text-xs mt-1">Upload images or videos to get started.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {playlist.map((item, index) => {
                    const isScheduled = item.schedule && item.schedule.enabled;
                    return (
                      <div key={item.id} className="group flex flex-col sm:flex-row items-start sm:items-center gap-4 p-3 bg-slate-50 border border-slate-100 rounded-xl hover:shadow-md transition-all">
                        
                        {/* Controls */}
                        <div className="flex flex-row sm:flex-col gap-1 w-full sm:w-auto justify-between sm:justify-start order-3 sm:order-1 mt-2 sm:mt-0">
                          <div className="flex sm:flex-col gap-1">
                            <button onClick={() => moveItem(index, -1)} disabled={index === 0} className="text-slate-400 hover:text-indigo-600 disabled:opacity-30 p-1 bg-white sm:bg-transparent rounded border sm:border-0 border-slate-200">
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 15l7-7 7 7"></path></svg>
                            </button>
                            <button onClick={() => moveItem(index, 1)} disabled={index === playlist.length - 1} className="text-slate-400 hover:text-indigo-600 disabled:opacity-30 p-1 bg-white sm:bg-transparent rounded border sm:border-0 border-slate-200">
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
                            </button>
                          </div>
                          <button onClick={() => handleDelete(item.id)} className="p-1.5 sm:p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors border sm:border-0 border-slate-200 bg-white sm:bg-transparent" title="Remove from playlist">
                            <Trash2 className="w-4 h-4 sm:w-5 sm:h-5" />
                          </button>
                        </div>
                        
                        {/* Thumbnail */}
                        <div className="w-full sm:w-24 h-32 sm:h-20 rounded-lg bg-slate-200 flex-shrink-0 overflow-hidden flex items-center justify-center order-1 sm:order-2">
                          {item.type === 'image' ? (
                            <img src={item.url} alt={item.originalName} className="w-full h-full object-cover" />
                          ) : (
                            <div className="bg-slate-800 w-full h-full flex items-center justify-center">
                              <Video className="w-6 h-6 text-white" />
                            </div>
                          )}
                        </div>
                        
                        {/* Info */}
                        <div className="flex-1 min-w-0 order-2 sm:order-3 w-full">
                          <p className="text-sm font-semibold text-slate-800 truncate">{item.originalName}</p>
                          <div className="flex flex-wrap items-center gap-2 mt-1.5 text-xs text-slate-500">
                            <span className="flex items-center gap-1 bg-white px-2 py-0.5 rounded border border-slate-200">
                              {item.type === 'image' ? <ImageIcon className="w-3 h-3" /> : <Video className="w-3 h-3" />}
                              <span className="capitalize">{item.type}</span>
                            </span>
                            {item.type === 'image' && (
                              <span className="px-2 py-0.5 bg-indigo-50 text-indigo-700 rounded border border-indigo-100 font-medium">
                                {item.duration}s
                              </span>
                            )}
                            {isScheduled && (
                              <span className="px-2 py-0.5 bg-amber-50 text-amber-700 rounded border border-amber-100 font-medium flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                Scheduled
                              </span>
                            )}
                          </div>
                          
                          {/* Schedule Details */}
                          {isScheduled && (
                            <div className="mt-2 text-[11px] text-slate-500 bg-white p-2 rounded border border-slate-100 flex flex-wrap gap-x-4 gap-y-1">
                               {item.schedule?.startDate && <span><span className="font-medium">From:</span> {item.schedule.startDate}</span>}
                               {item.schedule?.endDate && <span><span className="font-medium">Until:</span> {item.schedule.endDate}</span>}
                               {item.schedule?.startTime && <span><span className="font-medium">Time:</span> {item.schedule.startTime} to {item.schedule.endTime}</span>}
                            </div>
                          )}
                        </div>
                        
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
`;

fs.writeFileSync('src/App.tsx', appContent);
