const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

code = code.replace(
    /const handleQuickAdd = \(targetId: string\) => {([\s\S]*?)};/,
    `const handleQuickAdd = (targetId: string) => {
    setTargetScreensInput(targetId === 'global' ? '' : targetId);
    document.getElementById('upload-section')?.scrollIntoView({ behavior: 'smooth' });
    if (fileInputRef.current) {
        fileInputRef.current.click();
    }
  };`
);

fs.writeFileSync('src/App.tsx', code);
