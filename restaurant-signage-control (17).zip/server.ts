import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import { createServer } from 'http';
import { Server } from 'socket.io';
import multer from 'multer';
import { v4 as uuidv4 } from 'uuid';
import cors from 'cors';

const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(process.cwd(), 'database.json');
const UPLOADS_DIR = path.join(process.cwd(), 'uploads');

// Ensure uploads directory exists
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

// Ensure database file exists
if (!fs.existsSync(DATA_FILE)) {
  fs.writeFileSync(DATA_FILE, JSON.stringify({ 
    playlist: [],
    users: [{ id: '1', username: 'admin', password: '7941631', role: 'admin' }]
  }, null, 2));
}

function getDatabase() {
  return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
}

function saveDatabase(data: any) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

// Track connected screens
const connectedScreens = new Map();

// --- Ensure Admin User Exists ---
let initialDb = getDatabase();
if (!initialDb.users || initialDb.users.length === 0) {
  initialDb.users = [{ id: '1', username: 'admin', password: '7941631', role: 'admin' }];
  saveDatabase(initialDb);
}

if (!initialDb.settings) {
    initialDb.settings = { appName: 'Restaurant Signage', globalLicenseExpiry: '' };
    saveDatabase(initialDb);
}



// Multer setup for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, UPLOADS_DIR);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `${uuidv4()}${ext}`);
  }
});
const upload = multer({ storage });

async function startServer() {
  const app = express();
  const httpServer = createServer(app);
  const io = new Server(httpServer, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"]
    }
  });

  app.use(cors());
  app.use(express.json());

  // Serve static uploads
  app.use('/uploads', express.static(UPLOADS_DIR));

  // --- API Routes ---
  // --- Auth Routes ---
  app.post('/api/login', (req, res) => {
    const db = getDatabase();
    const { username, password } = req.body;
    const user = db.users?.find(u => u.username === username && u.password === password);
    
    if (user) {
      // Check user license
      if (user.role !== 'admin' && user.licenseExpiry) {
          const expiry = new Date(user.licenseExpiry);
          if (expiry < new Date()) {
              return res.status(403).json({ error: 'Your license has expired. Please contact the administrator.' });
          }
      }
      res.json({ success: true, user: { id: user.id, username: user.username, role: user.role, licenseExpiry: user.licenseExpiry }, token: 'fake-jwt-token' });
    } else {
      res.status(401).json({ error: 'Invalid credentials' });
    }
  });

  
  // --- Settings & License APIs ---
  app.get('/api/settings', (req, res) => {
    const db = getDatabase();
    res.json(db.settings || { appName: 'Restaurant Signage', globalLicenseExpiry: '' });
  });

  app.put('/api/settings', (req, res) => {
    const db = getDatabase();
    db.settings = { ...db.settings, ...req.body };
    saveDatabase(db);
    io.emit('settings_updated', db.settings);
    res.json(db.settings);
  });

  app.get('/api/screens', (req, res) => {
    const db = getDatabase();
    const names = db.screenNames || {};
    const screens = Array.from(connectedScreens.values()).map(s => ({
        ...s,
        name: names[s.id] || ''
    }));
    res.json(screens);
  });
  
  app.put('/api/screens/:id/name', express.json(), (req, res) => {
    const db = getDatabase();
    if (!db.screenNames) db.screenNames = {};
    db.screenNames[req.params.id] = req.body.name;
    saveDatabase(db);
    res.json({ success: true });
  });

  app.get('/api/users', (req, res) => {
    const db = getDatabase();
    res.json(db.users || []);
  });

  app.post('/api/users', (req, res) => {
    const db = getDatabase();
    if (!db.users) db.users = [];
    const newUser = { id: uuidv4(), username: req.body.username, password: req.body.password, role: 'user', licenseExpiry: req.body.licenseExpiry || '' };
    db.users.push(newUser);
    saveDatabase(db);
    res.json(newUser);
  });
  
  
  app.put('/api/users/:id', (req, res) => {
    const db = getDatabase();
    if (!db.users) return res.status(404).json({error: 'No users'});
    const userIndex = db.users.findIndex(u => u.id === req.params.id);
    if (userIndex > -1) {
        db.users[userIndex] = { ...db.users[userIndex], ...req.body };
        saveDatabase(db);
        res.json(db.users[userIndex]);
    } else {
        res.status(404).json({error: 'User not found'});
    }
  });

  app.delete('/api/users/:id', (req, res) => {
    const db = getDatabase();
    if (!db.users) return res.json({success: true});
    db.users = db.users.filter(u => u.id !== req.params.id);
    saveDatabase(db);
    res.json({success: true});
  });

  // Helper to filter scheduled items
  
function broadcastPlaylistUpdate(db) {
    io.sockets.sockets.forEach(s => {
       const screenId = s.handshake.query.screenId;
       if (screenId && screenId !== 'undefined') {
          s.emit('playlist_updated', getActivePlaylist(db, screenId));
       } else {
          s.emit('playlist_updated', db.playlist);
       }
    });
}

  function getActivePlaylist(db, screenId) {
    const now = new Date();
    return db.playlist.filter(item => {
      // Check target screens
      if (screenId && item.targetScreens && item.targetScreens.trim() !== '') {
          const targets = item.targetScreens.split(',').map(s => s.trim().toUpperCase());
          if (!targets.includes(screenId.toUpperCase())) return false;
      }
      if (!item.schedule) return true; // always show if no schedule
      if (!item.schedule.enabled) return true;
      
      try {
        if (item.schedule.startDate && new Date(item.schedule.startDate) > now) return false;
        if (item.schedule.endDate && new Date(item.schedule.endDate) < now) return false;
        
        // Time check (HH:MM)
        if (item.schedule.startTime && item.schedule.endTime) {
          const currentMinutes = now.getHours() * 60 + now.getMinutes();
          const [sH, sM] = item.schedule.startTime.split(':').map(Number);
          const [eH, eM] = item.schedule.endTime.split(':').map(Number);
          const startMins = sH * 60 + sM;
          const endMins = eH * 60 + eM;
          
          if (startMins <= endMins) {
             if (currentMinutes < startMins || currentMinutes > endMins) return false;
          } else {
             // wraps around midnight
             if (currentMinutes < startMins && currentMinutes > endMins) return false;
          }
        }
      } catch (e) {
         console.error('Schedule check error', e);
      }
      return true;
    });
  }

  
  // Get playlist
  app.get('/api/playlist', (req, res) => {
    const db = getDatabase();
    res.json(db.playlist);
  });

  // Upload media and add to playlist
  app.post('/api/upload', upload.single('file'), (req, res) => {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }
    
    const db = getDatabase();
    const type = req.file.mimetype.startsWith('video/') ? 'video' : 'image';
    const duration = type === 'image' ? (parseInt(req.body.duration) || 10) : 0; // default 10s for images
    const targetScreens = req.body.targetScreens || '';
    console.log('[UPLOAD] Received file:', req.file?.originalname, 'Target:', targetScreens);
    
    // Parse schedule if sent
    let schedule = null;
    try {
        if (req.body.schedule) {
            schedule = JSON.parse(req.body.schedule);
        }
    } catch(e){}
    
    const newItem = {
      id: uuidv4(),
      filename: req.file.filename,
      originalName: req.file.originalname,
      type: type,
      url: `/uploads/${req.file.filename}`,
      duration: duration,
      schedule: schedule,
      targetScreens: targetScreens
    };
    
    db.playlist.push(newItem);
    saveDatabase(db);
    
    // Notify clients
    broadcastPlaylistUpdate(db);
    
    res.json(newItem);
  });

  // Reorder / update playlist
  app.put('/api/playlist', (req, res) => {
    const db = getDatabase();
    db.playlist = req.body.playlist;
    saveDatabase(db);
    broadcastPlaylistUpdate(db);
    res.json({ success: true });
  });

  // Delete media
  app.delete('/api/playlist/:id', (req, res) => {
    const db = getDatabase();
    const itemIndex = db.playlist.findIndex((p: any) => p.id === req.params.id);
    
    if (itemIndex > -1) {
      const item = db.playlist[itemIndex];
      // Try to delete file
      try {
        const filePath = path.join(UPLOADS_DIR, item.filename);
        if (fs.existsSync(filePath)) {
          fs.unlinkSync(filePath);
        }
      } catch (err) {
        console.error('Failed to delete file', err);
      }
      
      db.playlist.splice(itemIndex, 1);
      saveDatabase(db);
      broadcastPlaylistUpdate(db);
    }
    
    res.json({ success: true });
  });

  // Download APK endpoint
  app.get('/api/download-apk', (req, res) => {
    const apkPath = path.join(process.cwd(), 'android-client', 'app', 'build', 'outputs', 'apk', 'debug', 'app-debug.apk');
    if (fs.existsSync(apkPath)) {
      res.download(apkPath, 'RestaurantSignage.apk');
    } else {
      res.status(404).send('APK is currently building. Please wait a minute and refresh.');
    }
  });

  
  setInterval(() => {
    const db = getDatabase();
    broadcastPlaylistUpdate(db);
    
    io.emit('settings_updated', db.settings || {});
  }, 60000); // Check schedule every 1 minute

  // WebSockets Connection
  io.on('connection', (socket) => {
    const screenId = socket.handshake.query.screenId;
    const ip = socket.handshake.address;
    
    if (screenId && screenId !== 'undefined') {
        console.log('Screen connected:', screenId, 'IP:', ip);
        connectedScreens.set(socket.id, { id: screenId, ip: ip, lastSeen: new Date() });
    } else {
        console.log('Dashboard connected:', socket.id);
    }

    const db = getDatabase();
    if (screenId && screenId !== 'undefined') {
        socket.emit('playlist_updated', getActivePlaylist(db, screenId));
        socket.emit('settings_updated', db.settings || {});
    } else {
        socket.emit('playlist_updated', db.playlist); // Dashboard gets everything
    }
        
    socket.on('disconnect', () => {
      console.log('Client disconnected:', socket.id);
      if (connectedScreens.has(socket.id)) {
          connectedScreens.delete(socket.id);
      }
    });
  });

  // --- Vite Middleware (Development) / Static Files (Production) ---
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  httpServer.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
