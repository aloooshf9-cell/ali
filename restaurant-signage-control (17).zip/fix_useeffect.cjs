const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const regex = /useEffect\(\(\) => \{\s*if \(\!user\) return;\s*fetchPlaylist\(\);\s*if \(user\.role === 'admin'\) \{\s*fetchUsers\(\);\s*fetchSettings\(\);\s*fetchScreens\(\);\s*const screenInterval = setInterval\(fetchScreens, 10000\);\s*return \(\) => clearInterval\(screenInterval\);\s*\}\s*const socket: Socket = io\(\);\s*socket\.on\('connect', \(\) => setConnected\(true\)\);\s*socket\.on\('disconnect', \(\) => setConnected\(false\)\);\s*socket\.on\('playlist_updated', \(data: PlaylistItem\[\]\) => \{\s*\/\/ In the real world we might just fetch the full list so we can edit scheduled ones\s*fetchPlaylist\(\);\s*\}\);\s*return \(\) => \{\s*socket\.disconnect\(\);\s*\};\s*\}, \[user\]\);/g;

const patch = `useEffect(() => {
    if (!user) return;
    fetchPlaylist();

    let screenInterval: NodeJS.Timeout;
    if (user.role === 'admin') {
      fetchUsers();
      fetchSettings();
      fetchScreens();
      screenInterval = setInterval(fetchScreens, 10000);
    }

    const socket = io();
    
    socket.on('connect', () => setConnected(true));
    socket.on('disconnect', () => setConnected(false));
    socket.on('playlist_updated', () => {
      fetchPlaylist();
    });

    return () => {
      socket.disconnect();
      if (screenInterval) clearInterval(screenInterval);
    };
  }, [user]);`;

if (regex.test(code)) {
    code = code.replace(regex, patch);
    fs.writeFileSync('src/App.tsx', code);
    console.log("Successfully patched useEffect!");
} else {
    console.log("Regex did not match.");
}
