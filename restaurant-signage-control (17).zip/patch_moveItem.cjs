const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const targetMoveItem = `  const moveItem = async (index: number, direction: number) => {`;

const patchMoveItem = `  const moveItemInGroup = async (item: any, direction: number) => {
    // Find the item in the global playlist
    const globalIndex = playlist.findIndex(p => p.id === item.id);
    if (globalIndex === -1) return;
    
    // Find the items in the same target group
    const groupItems = playlist.filter(p => p.targetScreens === item.targetScreens);
    const groupIndex = groupItems.findIndex(p => p.id === item.id);
    
    if (groupIndex + direction < 0 || groupIndex + direction >= groupItems.length) return;
    
    // Find the item to swap with
    const swapTarget = groupItems[groupIndex + direction];
    const globalTargetIndex = playlist.findIndex(p => p.id === swapTarget.id);
    
    if (globalTargetIndex === -1) return;
    
    // Swap them in the global playlist
    const newPlaylist = [...playlist];
    newPlaylist[globalIndex] = swapTarget;
    newPlaylist[globalTargetIndex] = item;
    
    setPlaylist(newPlaylist);
    
    try {
      await fetch('/api/playlist', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ playlist: newPlaylist })
      });
    } catch (err) {
      console.error('Reorder failed', err);
      fetchPlaylist(); // revert on fail
    }
  };

  const moveItem = async (index: number, direction: number) => {`;

if (code.includes(targetMoveItem)) {
    code = code.replace(targetMoveItem, patchMoveItem);
    fs.writeFileSync('src/App.tsx', code);
    console.log("Patched moveItemInGroup");
} else {
    console.log("Could not find moveItem");
}
