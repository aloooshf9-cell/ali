const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const targetForm = `<div className="pt-2 border-t border-slate-100">
                  <label className="flex items-center gap-2 cursor-pointer mb-3">`;
const patchForm = `
                {/* Screen Targeting Section */}
                <div className="pt-2 border-t border-slate-100">
                  <label className="block text-sm font-medium text-slate-700 mb-2 flex items-center gap-2">
                    <MonitorPlay className="w-4 h-4 text-slate-500" /> Target Specific Screens (Optional)
                  </label>
                  <input 
                    type="text" 
                    value={targetScreensInput} 
                    onChange={(e) => setTargetScreensInput(e.target.value)} 
                    placeholder="e.g. A1B2C3 (leave blank for all)" 
                    className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-sm mb-4" 
                  />
                </div>
                
                <div className="pt-2 border-t border-slate-100">
                  <label className="flex items-center gap-2 cursor-pointer mb-3">`;

code = code.replace(targetForm, patchForm);

fs.writeFileSync('src/App.tsx', code);
