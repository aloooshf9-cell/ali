const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const targetUpload = `    const formData = new FormData();
    formData.append('file', file);
    formData.append('duration', duration.toString());
    
    if (targetScreensInput !== '' && targetScreensInput !== 'MANUAL') {
        formData.append('targetScreens', targetScreensInput);
    }
    
    if (scheduleEnabled) {
      formData.append('schedule', JSON.stringify({
        enabled: true,
        startDate,
        endDate,
        startTime,
        endTime
      }));
    }`;

const patchUpload = `    const formData = new FormData();
    formData.append('duration', duration.toString());
    
    if (targetScreensInput !== '' && targetScreensInput !== 'MANUAL') {
        formData.append('targetScreens', targetScreensInput);
    }
    
    if (scheduleEnabled) {
      formData.append('schedule', JSON.stringify({
        enabled: true,
        startDate,
        endDate,
        startTime,
        endTime
      }));
    }
    
    formData.append('file', file);`;

if (code.includes(targetUpload)) {
    code = code.replace(targetUpload, patchUpload);
    fs.writeFileSync('src/App.tsx', code);
    console.log("Patched Multer order");
} else {
    console.log("Could not find target string");
}
