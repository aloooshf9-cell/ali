const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const targetUseEffect = `  useEffect(() => {
    if (!user) return;
    fetchPlaylist();

    if (user.role === 'admin') {
      fetchUsers();
      fetchSettings();
      fetchScreens();
      const screenInterval = setInterval(fetchScreens, 10000);
      return () => clearInterval(screenInterval);
    }

    const socket: Socket = io();
    
    socket.on('connect', () => setConnected(true));
    socket.on('disconnect', () => setConnected(false));
    socket.on('playlist_updated', (data: PlaylistItem[]) => {
      // In the real world we might just fetch the full list so we can edit scheduled ones
      fetchPlaylist();
    });

    return () => {
      socket.disconnect();
    };
  }, [user]);`;

const patchUseEffect = `  useEffect(() => {
    if (!user) return;
    fetchPlaylist();

    let screenInterval: any;
    if (user.role === 'admin') {
      fetchUsers();
      fetchSettings();
      fetchScreens();
      screenInterval = setInterval(fetchScreens, 10000);
    }

    const socket: Socket = io();
    
    socket.on('connect', () => setConnected(true));
    socket.on('disconnect', () => setConnected(false));
    socket.on('playlist_updated', () => {
      fetchPlaylist();
    });

    return () => {
      socket.disconnect();
      if (screenInterval) clearInterval(screenInterval);
    };
  }, [user]);`;

code = code.replace(targetUseEffect, patchUseEffect);
fs.writeFileSync('src/App.tsx', code);
