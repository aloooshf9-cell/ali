const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

code = code.replace(
    '<span className="text-sm font-medium text-slate-700">📺 Specific Screen: {s.id}</span>',
    '<span className="text-sm font-medium text-slate-700">📺 Specific Screen: {s.name ? `${s.name} (${s.id})` : s.id}</span>'
);

code = code.replace(
    'title: `Playlist for Screen: ${s.id}`,',
    'title: `Playlist for Screen: ${s.name ? `${s.name} (${s.id})` : s.id}`,'
);

fs.writeFileSync('src/App.tsx', code);
console.log("Patched App.tsx names everywhere");
