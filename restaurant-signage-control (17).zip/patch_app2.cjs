const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const adminPanelTarget = "{/* Left Column (Upload + Users) */}\n          <div className=\"lg:col-span-1 space-y-6\">";
          
const adminPanelPatch = `{/* Left Column (Upload + Users) */}
          <div className="lg:col-span-1 space-y-6">
          
            {/* Active Screens Panel */}
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
              <h2 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
                <MonitorPlay className="w-5 h-5 text-indigo-500" />
                Active Screens
                <span className="bg-indigo-50 text-indigo-700 text-xs font-bold px-2 py-0.5 rounded-full ml-auto">{activeScreens.length}</span>
              </h2>
              {activeScreens.length === 0 ? (
                <p className="text-sm text-slate-500 italic">No screens currently connected.</p>
              ) : (
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {activeScreens.map((s, i) => (
                    <div key={i} className="flex flex-col bg-slate-50 p-2 rounded-lg border border-slate-100">
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-bold text-slate-800">ID: {s.id}</span>
                        <span className="flex items-center gap-1 text-[10px] text-emerald-600 font-medium bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-100"><div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></div> Online</span>
                      </div>
                      <span className="text-[10px] text-slate-500 mt-0.5">IP: {s.ip.replace('::ffff:', '')}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>`;
            
code = code.replace(adminPanelTarget, adminPanelPatch);
fs.writeFileSync('src/App.tsx', code);
