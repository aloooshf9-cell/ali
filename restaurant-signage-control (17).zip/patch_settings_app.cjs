const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const targetInterface = `interface Settings {
  appName: string;
  globalLicenseExpiry: string;
}`;
const patchInterface = `interface Settings {
  appName: string;
  globalLicenseExpiry: string;
  transitionEffect?: string;
}`;
code = code.replace(targetInterface, patchInterface);

const targetState = `const [settings, setSettings] = useState<Settings>({ appName: 'Restaurant Signage', globalLicenseExpiry: '' });`;
const patchState = `const [settings, setSettings] = useState<Settings>({ appName: 'Restaurant Signage', globalLicenseExpiry: '', transitionEffect: 'fade' });`;
code = code.replace(targetState, patchState);

const targetForm = `<p className="text-xs text-slate-500">If set, TV boxes will lock after this date until renewed.</p>
                 </div>
                 <div className="flex justify-end gap-3 mt-6">`;
const patchForm = `<p className="text-xs text-slate-500">If set, TV boxes will lock after this date until renewed.</p>
                 </div>
                 <div className="space-y-2">
                    <label className="block text-sm font-medium text-slate-700">Ad Transition Effect</label>
                    <select value={settings.transitionEffect || 'fade'} onChange={e => setSettings({...settings, transitionEffect: e.target.value})} className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none">
                        <option value="none">None (Instant Cut)</option>
                        <option value="fade">Cross-Fade (Smooth Transition)</option>
                    </select>
                 </div>
                 <div className="flex justify-end gap-3 mt-6">`;
code = code.replace(targetForm, patchForm);

fs.writeFileSync('src/App.tsx', code);
