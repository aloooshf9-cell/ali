const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

// Fix 1: handleUpload missing targetScreens
const targetUpload = `    const formData = new FormData();
    formData.append('file', file);
    formData.append('duration', duration.toString());
    
    if (scheduleEnabled) {`;

const patchUpload = `    const formData = new FormData();
    formData.append('file', file);
    formData.append('duration', duration.toString());
    
    if (targetScreensInput !== '' && targetScreensInput !== 'MANUAL') {
        formData.append('targetScreens', targetScreensInput);
    }
    
    if (scheduleEnabled) {`;

if (code.includes(targetUpload)) {
    code = code.replace(targetUpload, patchUpload);
    console.log("Patched handleUpload");
} else {
    console.log("Could not find handleUpload target");
}

// Fix 2: useEffect missing fetchScreens for normal users
const targetUseEffect = `    let screenInterval: NodeJS.Timeout;
    if (user.role === 'admin') {
      fetchUsers();
      fetchSettings();
      fetchScreens();
      screenInterval = setInterval(fetchScreens, 10000);
    }

    const socket = io();`;

const patchUseEffect = `    let screenInterval: NodeJS.Timeout;
    
    // Everyone needs to see active screens
    fetchScreens();
    screenInterval = setInterval(fetchScreens, 10000);
    
    if (user.role === 'admin') {
      fetchUsers();
      fetchSettings();
    }

    const socket = io();`;

if (code.includes(targetUseEffect)) {
    code = code.replace(targetUseEffect, patchUseEffect);
    console.log("Patched useEffect");
} else {
    console.log("Could not find useEffect target");
}

fs.writeFileSync('src/App.tsx', code);
