const fs = require('fs');
let code = fs.readFileSync('android-client/app/src/main/java/com/restaurant/signage/SyncService.kt', 'utf8');

const targetArgs = `class SyncService(
    private val context: Context,
    private val onStatusUpdate: (String) -> Unit,
    private val onPlaylistUpdated: (List<PlaylistItem>) -> Unit,
    private val onSettingsUpdated: (String, Boolean) -> Unit
) {`;
const patchArgs = `class SyncService(
    private val context: Context,
    private val screenId: String,
    private val onStatusUpdate: (String) -> Unit,
    private val onPlaylistUpdated: (List<PlaylistItem>) -> Unit,
    private val onSettingsUpdated: (String, Boolean) -> Unit
) {`;
code = code.replace(targetArgs, patchArgs);

const targetConnect = `socket = IO.socket(SERVER_URL)`;
const patchConnect = `val opts = IO.Options()
            opts.query = "screenId=$screenId"
            socket = IO.socket(SERVER_URL, opts)`;
code = code.replace(targetConnect, patchConnect);

fs.writeFileSync('android-client/app/src/main/java/com/restaurant/signage/SyncService.kt', code);
