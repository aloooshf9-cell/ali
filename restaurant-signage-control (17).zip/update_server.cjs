const fs = require('fs');

let serverCode = fs.readFileSync('server.ts', 'utf8');

// Update DB initialization
serverCode = serverCode.replace(
  `fs.writeFileSync(DATA_FILE, JSON.stringify({ playlist: [] }, null, 2));`,
  `fs.writeFileSync(DATA_FILE, JSON.stringify({ 
    playlist: [],
    users: [{ id: '1', username: 'admin', password: '7941631', role: 'admin' }]
  }, null, 2));`
);

// We need to inject the auth and scheduling routes. Let's find a good spot.
const routeInsertionPoint = `// --- API Routes ---`;
const newRoutes = `
  // --- Auth Routes ---
  app.post('/api/login', (req, res) => {
    const db = getDatabase();
    const { username, password } = req.body;
    const user = db.users?.find(u => u.username === username && u.password === password);
    
    if (user) {
      // In a real app we'd use JWT, but simple token works for local dashboard
      res.json({ success: true, user: { id: user.id, username: user.username, role: user.role }, token: 'fake-jwt-token' });
    } else {
      res.status(401).json({ error: 'Invalid credentials' });
    }
  });

  app.get('/api/users', (req, res) => {
    const db = getDatabase();
    res.json(db.users || []);
  });

  app.post('/api/users', (req, res) => {
    const db = getDatabase();
    if (!db.users) db.users = [];
    const newUser = { id: uuidv4(), username: req.body.username, password: req.body.password, role: 'user' };
    db.users.push(newUser);
    saveDatabase(db);
    res.json(newUser);
  });
  
  app.delete('/api/users/:id', (req, res) => {
    const db = getDatabase();
    if (!db.users) return res.json({success: true});
    db.users = db.users.filter(u => u.id !== req.params.id);
    saveDatabase(db);
    res.json({success: true});
  });

  // Helper to filter scheduled items
  function getActivePlaylist(db) {
    const now = new Date();
    return db.playlist.filter(item => {
      if (!item.schedule) return true; // always show if no schedule
      if (!item.schedule.enabled) return true;
      
      try {
        if (item.schedule.startDate && new Date(item.schedule.startDate) > now) return false;
        if (item.schedule.endDate && new Date(item.schedule.endDate) < now) return false;
        
        // Time check (HH:MM)
        if (item.schedule.startTime && item.schedule.endTime) {
          const currentMinutes = now.getHours() * 60 + now.getMinutes();
          const [sH, sM] = item.schedule.startTime.split(':').map(Number);
          const [eH, eM] = item.schedule.endTime.split(':').map(Number);
          const startMins = sH * 60 + sM;
          const endMins = eH * 60 + eM;
          
          if (startMins <= endMins) {
             if (currentMinutes < startMins || currentMinutes > endMins) return false;
          } else {
             // wraps around midnight
             if (currentMinutes < startMins && currentMinutes > endMins) return false;
          }
        }
      } catch (e) {
         console.error('Schedule check error', e);
      }
      return true;
    });
  }
`;

serverCode = serverCode.replace(routeInsertionPoint, routeInsertionPoint + newRoutes);

// Update upload logic to support schedule
serverCode = serverCode.replace(
  `const duration = type === 'image' ? (parseInt(req.body.duration) || 10) : 0; // default 10s for images`,
  `const duration = type === 'image' ? (parseInt(req.body.duration) || 10) : 0; // default 10s for images
    
    // Parse schedule if sent
    let schedule = null;
    try {
        if (req.body.schedule) {
            schedule = JSON.parse(req.body.schedule);
        }
    } catch(e){}`
);

serverCode = serverCode.replace(
  `url: \`/uploads/\${req.file.filename}\`,
      duration: duration
    };`,
  `url: \`/uploads/\${req.file.filename}\`,
      duration: duration,
      schedule: schedule
    };`
);

// Fix socket emitting to only emit active items OR emit all to dashboard but active to socket.
// Wait, the React dashboard needs ALL items to edit/delete them. The socket (Android clients) only needs active.
// Let's modify socket.emit
serverCode = serverCode.replace(
  `io.emit('playlist_updated', db.playlist);`,
  `io.emit('playlist_updated', getActivePlaylist(db));`
);
// replace all occurrences
serverCode = serverCode.replace(
  /io\.emit\('playlist_updated', db\.playlist\);/g,
  `io.emit('playlist_updated', getActivePlaylist(db));`
);

serverCode = serverCode.replace(
  `socket.emit('playlist_updated', getDatabase().playlist);`,
  `socket.emit('playlist_updated', getActivePlaylist(getDatabase()));`
);

// We need a loop to periodically update clients in case a schedule triggers
const timerCode = `
  setInterval(() => {
    io.emit('playlist_updated', getActivePlaylist(getDatabase()));
  }, 60000); // Check schedule every 1 minute
`;

serverCode = serverCode.replace(`// WebSockets Connection`, timerCode + `\n  // WebSockets Connection`);


fs.writeFileSync('server.ts', serverCode);
