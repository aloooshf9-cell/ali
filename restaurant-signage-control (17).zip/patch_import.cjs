const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

code = code.replace(
    "import { Upload, MonitorPlay, Save, Trash2, RefreshCw, Image as ImageIcon, Video, LogOut, Users, Clock, Calendar, Shield, Play, Settings } from 'lucide-react';",
    "import { Upload, MonitorPlay, Save, Trash2, RefreshCw, Image as ImageIcon, Video, LogOut, Users, Clock, Calendar, Shield, Play, Settings, Plus } from 'lucide-react';"
);

fs.writeFileSync('src/App.tsx', code);
