const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const targetRender = `            {[
              { title: 'Global Playlist (All Screens)', items: playlist.filter(p => !p.targetScreens || p.targetScreens === ''), id: 'global' },
              ...activeScreens.map(s => ({
                  title: \`Playlist for Screen: \${s.name ? \`\${s.name} (\${s.id})\` : s.id}\`,
                  items: playlist.filter(p => p.targetScreens === s.id),
                  id: s.id
              }))
            ].map(group => (`;

const patchRender = `            {[
              { title: 'Global Playlist (All Screens)', items: playlist.filter(p => !p.targetScreens || p.targetScreens === ''), id: 'global' },
              ...Array.from(new Set(playlist.map(p => p.targetScreens).filter(ts => ts && ts !== ''))).map(ts => {
                  const screen = activeScreens.find(s => s.id === ts);
                  return {
                      title: screen && screen.name ? \`Playlist for Screen: \${screen.name} (\${ts})\` : \`Playlist for Screen: \${ts} \${!screen ? '(Offline)' : ''}\`,
                      items: playlist.filter(p => p.targetScreens === ts),
                      id: String(ts)
                  };
              }),
              ...activeScreens.filter(s => !playlist.some(p => p.targetScreens === s.id)).map(s => ({
                  title: \`Playlist for Screen: \${s.name ? \`\${s.name} (\${s.id})\` : s.id}\`,
                  items: [],
                  id: s.id
              }))
            ].map(group => (`;

if (code.includes(targetRender)) {
    code = code.replace(targetRender, patchRender);
    fs.writeFileSync('src/App.tsx', code);
    console.log("Patched render groups");
} else {
    console.log("Could not find targetRender. Let me try an alternative...");
    const targetRender2 = `            {[
              { title: 'Global Playlist (All Screens)', items: playlist.filter(p => !p.targetScreens || p.targetScreens === ''), id: 'global' },
              ...activeScreens.map(s => ({
                  title: \`Playlist for Screen: \${s.id}\`,
                  items: playlist.filter(p => p.targetScreens === s.id),
                  id: s.id
              }))
            ].map(group => (`;
    if (code.includes(targetRender2)) {
        code = code.replace(targetRender2, patchRender);
        fs.writeFileSync('src/App.tsx', code);
        console.log("Patched render groups (alternative)");
    } else {
        console.log("Still could not find it. Here is the block:");
        const snippet = code.substring(code.indexOf('{/* Helper function to render a playlist block */}'), code.indexOf('.map(group => ('));
        console.log(snippet);
    }
}
