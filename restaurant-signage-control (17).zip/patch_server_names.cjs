const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const targetGetScreens = `  app.get('/api/screens', (req, res) => {
    res.json(Array.from(connectedScreens.values()));
  });`;

const patchGetScreens = `  app.get('/api/screens', (req, res) => {
    const db = getDatabase();
    const names = db.screenNames || {};
    const screens = Array.from(connectedScreens.values()).map(s => ({
        ...s,
        name: names[s.id] || ''
    }));
    res.json(screens);
  });
  
  app.put('/api/screens/:id/name', express.json(), (req, res) => {
    const db = getDatabase();
    if (!db.screenNames) db.screenNames = {};
    db.screenNames[req.params.id] = req.body.name;
    saveDatabase(db);
    res.json({ success: true });
  });`;

if (code.includes(targetGetScreens)) {
    code = code.replace(targetGetScreens, patchGetScreens);
    fs.writeFileSync('server.ts', code);
    console.log("Patched server.ts successfully");
} else {
    console.log("Could not find target in server.ts");
}
