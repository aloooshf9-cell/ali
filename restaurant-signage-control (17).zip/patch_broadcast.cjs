const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

// Add broadcast helper function
const broadcastHelper = `
function broadcastPlaylistUpdate(db) {
    io.sockets.sockets.forEach(s => {
       const screenId = s.handshake.query.screenId;
       if (screenId && screenId !== 'undefined') {
          s.emit('playlist_updated', getActivePlaylist(db, screenId));
       } else {
          s.emit('playlist_updated', db.playlist);
       }
    });
}
`;

if (!code.includes('function broadcastPlaylistUpdate')) {
    code = code.replace('function getActivePlaylist', broadcastHelper + '\n  function getActivePlaylist');
}

// Replace the buggy emit blocks
code = code.replace(/    \/\/ Emit to dashboard[\s\S]*?    \}\);\n/g, '    broadcastPlaylistUpdate(db);\n');
code = code.replace(/    io\.emit\('playlist_updated_dashboard', db\.playlist\);[\s\S]*?    \}\);\n/g, '    broadcastPlaylistUpdate(db);\n');

fs.writeFileSync('server.ts', code);
console.log("Patched server.ts broadcasts");
