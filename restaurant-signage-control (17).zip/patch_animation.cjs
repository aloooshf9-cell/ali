const fs = require('fs');
let code = fs.readFileSync('android-client/app/src/main/java/com/restaurant/signage/MainActivity.kt', 'utf8');

const targetPlay = `private fun playCurrentItem() {
        if (currentPlaylist.isEmpty() || isLicenseExpired) return
        
        if (currentIndex >= currentPlaylist.size) {
            currentIndex = 0
        }
        
        val item = currentPlaylist[currentIndex]
        
        if (item.type == "image") {
            player?.stop()
            playerView.visibility = View.GONE
            imageView.visibility = View.VISIBLE
            
            val bitmap = BitmapFactory.decodeFile(item.localUri)
            imageView.setImageBitmap(bitmap)
            
            val durationMs = (if (item.duration > 0) item.duration else 10) * 1000L
            handler.postDelayed(imageRunnable, durationMs)
        } else {
            handler.removeCallbacks(imageRunnable)
            imageView.visibility = View.GONE
            playerView.visibility = View.VISIBLE
            
            val mediaItem = MediaItem.fromUri(item.localUri)
            player?.setMediaItem(mediaItem)
            player?.prepare()
            player?.play()
        }
    }`;

const patchPlay = `private fun playCurrentItem() {
        if (currentPlaylist.isEmpty() || isLicenseExpired) return
        
        if (currentIndex >= currentPlaylist.size) {
            currentIndex = 0
        }
        
        val item = currentPlaylist[currentIndex]
        
        if (item.type == "image") {
            player?.stop()
            
            // Fade In Image, Fade Out Player
            imageView.alpha = 0f
            imageView.visibility = View.VISIBLE
            
            val bitmap = BitmapFactory.decodeFile(item.localUri)
            imageView.setImageBitmap(bitmap)
            
            imageView.animate().alpha(1f).setDuration(1000).withEndAction {
                playerView.visibility = View.GONE
            }.start()
            
            playerView.animate().alpha(0f).setDuration(1000).start()
            
            val durationMs = (if (item.duration > 0) item.duration else 10) * 1000L
            handler.postDelayed(imageRunnable, durationMs)
        } else {
            handler.removeCallbacks(imageRunnable)
            
            // Fade In Player, Fade Out Image
            playerView.alpha = 0f
            playerView.visibility = View.VISIBLE
            
            val mediaItem = MediaItem.fromUri(item.localUri)
            player?.setMediaItem(mediaItem)
            player?.prepare()
            player?.play()
            
            playerView.animate().alpha(1f).setDuration(1000).withEndAction {
                imageView.visibility = View.GONE
            }.start()
            
            imageView.animate().alpha(0f).setDuration(1000).start()
        }
    }`;

code = code.replace(targetPlay, patchPlay);
fs.writeFileSync('android-client/app/src/main/java/com/restaurant/signage/MainActivity.kt', code);
