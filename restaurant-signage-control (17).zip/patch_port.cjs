const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

code = code.replace("httpServer.listen(PORT, '0.0.0.0', () => {", "httpServer.listen(Number(PORT), '0.0.0.0', () => {");
fs.writeFileSync('server.ts', code);
