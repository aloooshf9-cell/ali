@echo off
echo ==========================================
echo Stopping Restaurant Signage Server...
echo ==========================================
taskkill /F /IM node.exe
echo.
echo Server stopped successfully.
pause
