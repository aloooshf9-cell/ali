const fs = require('fs');
let code = fs.readFileSync('android-client/app/src/main/java/com/restaurant/signage/MainActivity.kt', 'utf8');

const targetVideoPlay = `        } else {
            handler.removeCallbacks(imageRunnable)
            
            val mediaItem = MediaItem.fromUri(item.localUri)
            player?.setMediaItem(mediaItem)
            player?.prepare()
            player?.play()`;

const patchVideoPlay = `        } else {
            handler.removeCallbacks(imageRunnable)
            
            val mediaItem = MediaItem.fromUri(item.localUri)
            player?.setMediaItem(mediaItem)
            player?.prepare()
            player?.seekTo(0)
            player?.play()`;

if (code.includes(targetVideoPlay)) {
    code = code.replace(targetVideoPlay, patchVideoPlay);
    fs.writeFileSync('android-client/app/src/main/java/com/restaurant/signage/MainActivity.kt', code);
    console.log("Patched MainActivity.kt for video duration.");
} else {
    console.log("Could not find targetVideoPlay.");
}
