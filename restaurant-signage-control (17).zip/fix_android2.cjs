const fs = require('fs');
const mainActivityPath = 'android-client/app/src/main/java/com/restaurant/signage/MainActivity.kt';
let mainActivity = fs.readFileSync(mainActivityPath, 'utf8');

mainActivity = mainActivity.replace(
    '                    if (currentPlaylist.isNotEmpty()) {\n                        playCurrentItem()\n                    }\n                }\n            }\n        )',
    '                    if (currentPlaylist.isNotEmpty()) {\n                        playCurrentItem()\n                    }\n                }\n            },\n            serverUrl = serverUrl\n        )'
);

fs.writeFileSync(mainActivityPath, mainActivity);
