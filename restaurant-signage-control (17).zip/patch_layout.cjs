const fs = require('fs');
let code = fs.readFileSync('android-client/app/src/main/res/layout/activity_main.xml', 'utf8');

const target = `</androidx.constraintlayout.widget.ConstraintLayout>`;
const patch = `
    <TextView
        android:id="@+id/screen_id_text"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:textColor="#55FFFFFF"
        android:textSize="12sp"
        android:layout_margin="16dp"
        app:layout_constraintBottom_toBottomOf="parent"
        app:layout_constraintEnd_toEndOf="parent" />
</androidx.constraintlayout.widget.ConstraintLayout>`;

code = code.replace(target, patch);
fs.writeFileSync('android-client/app/src/main/res/layout/activity_main.xml', code);
