const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

// 1. Add id="upload-section"
code = code.replace(
    '            {/* Upload Section */}\n            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">',
    '            {/* Upload Section */}\n            <div id="upload-section" className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">'
);

// 2. Insert handleQuickAdd function before `if (!user)`
const quickAddFunc = `
  const handleQuickAdd = (targetId: string) => {
    setTargetScreensInput(targetId === 'global' ? '' : targetId);
    document.getElementById('upload-section')?.scrollIntoView({ behavior: 'smooth' });
  };

  if (!user) {`;
code = code.replace('  if (!user) {', quickAddFunc);

// 3. Update the playlist group header
// I need to import Plus from lucide-react if it's not imported.
const targetHeader = `                <h2 className="text-lg font-semibold text-slate-800 mb-4 flex items-center justify-between">
                  {group.title}
                  <span className="bg-slate-100 text-slate-600 text-xs font-medium px-2.5 py-1 rounded-full">
                    {group.items.length} items
                  </span>
                </h2>`;

const patchHeader = `                <h2 className="text-lg font-semibold text-slate-800 mb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <span>{group.title}</span>
                  <div className="flex items-center gap-2">
                    <button onClick={() => handleQuickAdd(group.id)} className="flex items-center gap-1 bg-indigo-50 text-indigo-600 hover:bg-indigo-100 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors border border-indigo-100 shadow-sm">
                      <Plus className="w-4 h-4" /> Add Media
                    </button>
                    <span className="bg-slate-100 text-slate-600 text-xs font-medium px-2.5 py-1 rounded-full">
                      {group.items.length} items
                    </span>
                  </div>
                </h2>`;

if (code.includes(targetHeader)) {
    code = code.replace(targetHeader, patchHeader);
    console.log("Patched targetHeader");
} else {
    console.log("Could not find targetHeader!");
}

// Ensure Plus is imported
if (!code.includes('Plus,')) {
    code = code.replace('import { Play, Pause, Trash2, Edit2, Check, X, Upload, Activity, MonitorPlay, Save, Clock, Calendar } from \'lucide-react\';',
                        'import { Play, Pause, Trash2, Edit2, Check, X, Upload, Activity, MonitorPlay, Save, Clock, Calendar, Plus } from \'lucide-react\';');
}

fs.writeFileSync('src/App.tsx', code);
console.log("App.tsx patched successfully.");
