const fs = require('fs');
let code = fs.readFileSync('android-client/app/src/main/java/com/restaurant/signage/MainActivity.kt', 'utf8');

const targetVars = `private lateinit var appNameText: TextView`;
const patchVars = `private lateinit var appNameText: TextView
    private lateinit var screenIdText: TextView
    private lateinit var screenId: String`;
code = code.replace(targetVars, patchVars);


const targetOnCreate = `appNameText = findViewById(R.id.app_name_text)`;
const patchOnCreate = `appNameText = findViewById(R.id.app_name_text)
        screenIdText = findViewById(R.id.screen_id_text)
        
        val prefs = getSharedPreferences("SignagePrefs", android.content.Context.MODE_PRIVATE)
        screenId = prefs.getString("SCREEN_ID", null) ?: run {
            val newId = java.util.UUID.randomUUID().toString().substring(0, 6).uppercase(java.util.Locale.US)
            prefs.edit().putString("SCREEN_ID", newId).apply()
            newId
        }
        screenIdText.text = "Screen ID: $screenId"`;
code = code.replace(targetOnCreate, patchOnCreate);

const targetSync = `syncService = SyncService(this, 
            onStatusUpdate = { status ->`;
const patchSync = `syncService = SyncService(this, screenId,
            onStatusUpdate = { status ->`;
code = code.replace(targetSync, patchSync);

fs.writeFileSync('android-client/app/src/main/java/com/restaurant/signage/MainActivity.kt', code);
