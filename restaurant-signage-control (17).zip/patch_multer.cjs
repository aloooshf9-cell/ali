const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const targetUpload = `    const formData = new FormData();
    formData.append('file', file);
    formData.append('duration', duration.toString());
    
    if (targetScreensInput !== '' && targetScreensInput !== 'MANUAL') {
        formData.append('targetScreens', targetScreensInput);
    }
    
    if (scheduleEnabled) {`;

const patchUpload = `    const formData = new FormData();
    // Append text fields BEFORE the file so multer parses them correctly
    formData.append('duration', duration.toString());
    
    if (targetScreensInput !== '' && targetScreensInput !== 'MANUAL') {
        formData.append('targetScreens', targetScreensInput);
    }
    
    if (scheduleEnabled) {
      formData.append('schedule', JSON.stringify({
        enabled: true,
        startDate,
        endDate,
        startTime,
        endTime
      }));
    }
    
    // Finally, append the file
    formData.append('file', file);`;

if (code.includes('formData.append(\'file\', file);')) {
    // I need to be careful with the exact replace string
    console.log("Found");
}

