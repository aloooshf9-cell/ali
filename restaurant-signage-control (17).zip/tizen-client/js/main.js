let socket = null;
let playlist = [];
let currentIndex = 0;
let imageTimer = null;
let currentSettings = { transitionEffect: 'fade' };

const overlay = document.getElementById('setup-overlay');
const screenIdInput = document.getElementById('setup-screen-id');
const serverUrlInput = document.getElementById('setup-server-url');
const saveBtn = document.getElementById('setup-save-btn');
const statusMsg = document.getElementById('status-message');
const setupStatus = document.getElementById('setup-status');

const imgEl = document.getElementById('media-image');
const vidEl = document.getElementById('media-video');

// Init
window.onload = () => {
    const savedScreenId = localStorage.getItem('signage_screen_id');
    const savedServerUrl = localStorage.getItem('signage_server_url');

    if (savedScreenId && savedServerUrl) {
        overlay.style.display = 'none';
        connectToServer(savedServerUrl, savedScreenId);
    } else {
        overlay.style.display = 'flex';
        // Auto-focus logic for TV remotes
        setTimeout(() => screenIdInput.focus(), 100);
    }
};

saveBtn.addEventListener('click', () => {
    const sId = screenIdInput.value.trim();
    const sUrl = serverUrlInput.value.trim();
    
    if (!sId || !sUrl) {
        setupStatus.textContent = "Please fill in both fields";
        return;
    }

    localStorage.setItem('signage_screen_id', sId);
    localStorage.setItem('signage_server_url', sUrl);
    
    setupStatus.textContent = "Connecting...";
    setTimeout(() => {
        overlay.style.display = 'none';
        connectToServer(sUrl, sId);
    }, 500);
});

// Load Socket.io script dynamically from the target server
function connectToServer(serverUrl, screenId) {
    statusMsg.textContent = "Connecting to Server...";
    
    // Normalize URL
    let url = serverUrl;
    if (url.endsWith('/')) url = url.slice(0, -1);
    
    const script = document.createElement('script');
    script.src = url + "/socket.io/socket.io.js";
    script.onload = () => initSocket(url, screenId);
    script.onerror = () => {
        statusMsg.textContent = "Failed to reach server. call IT BWE support. Retrying...";
        setTimeout(() => connectToServer(serverUrl, screenId), 10000);
    };
    document.head.appendChild(script);
}

function initSocket(serverUrl, screenId) {
    socket = io(serverUrl, { query: { screenId: screenId } });

    socket.on('connect', () => {
        statusMsg.textContent = "Connected. Waiting for playlist...";
        console.log("Socket connected");
    });

    socket.on('disconnect', () => {
        statusMsg.textContent = "Disconnected from server. call IT BWE support. Retrying...";
        stopPlayback();
    });

    socket.on('playlist_updated', (data) => {
        console.log("Playlist updated", data);
        playlist = data || [];
        if (playlist.length === 0) {
            stopPlayback();
            statusMsg.textContent = "Playlist is empty.";
            statusMsg.style.display = 'block';
        } else {
            statusMsg.style.display = 'none';
            // Restart playback only if it's not currently playing, or force restart
            // For simplicity, restart on every update
            stopPlayback();
            currentIndex = 0;
            playNextItem();
        }
    });

    socket.on('settings_updated', (data) => {
        currentSettings = data || { transitionEffect: 'fade' };
    });
}

function stopPlayback() {
    clearTimeout(imageTimer);
    vidEl.pause();
    imgEl.style.display = 'none';
    vidEl.style.display = 'none';
}

function applyTransition(element) {
    if (currentSettings.transitionEffect === 'none') {
        element.style.opacity = 1;
        element.style.display = 'block';
    } else {
        element.style.opacity = 0;
        element.style.display = 'block';
        // Trigger reflow
        void element.offsetWidth;
        element.style.opacity = 1;
    }
}

function playNextItem() {
    if (playlist.length === 0) return;
    
    if (currentIndex >= playlist.length) {
        currentIndex = 0;
    }
    
    const item = playlist[currentIndex];
    
    // Hide both elements to start
    imgEl.style.display = 'none';
    vidEl.style.display = 'none';
    
    // Build full URL for media
    let savedServerUrl = localStorage.getItem('signage_server_url');
    if (savedServerUrl && savedServerUrl.endsWith('/')) {
        savedServerUrl = savedServerUrl.slice(0, -1);
    }
    const mediaUrl = savedServerUrl + item.url;
    
    if (item.type === 'image') {
        imgEl.src = mediaUrl;
        imgEl.onload = () => {
            applyTransition(imgEl);
            let durationMs = (item.duration > 0 ? item.duration : 10) * 1000;
            imageTimer = setTimeout(() => {
                currentIndex++;
                playNextItem();
            }, durationMs);
        };
        imgEl.onerror = () => {
            console.error("Failed to load image", mediaUrl);
            currentIndex++;
            setTimeout(playNextItem, 1000);
        };
    } else {
        vidEl.src = mediaUrl;
        applyTransition(vidEl);
        vidEl.play().catch(e => {
            console.error("Video playback failed", e);
            currentIndex++;
            setTimeout(playNextItem, 1000);
        });
        
        vidEl.onended = () => {
            currentIndex++;
            playNextItem();
        };
        vidEl.onerror = () => {
            currentIndex++;
            setTimeout(playNextItem, 1000);
        };
    }
}

// Tizen hardware keys handling (e.g. Back button on remote)
document.addEventListener('keydown', function(e) {
    switch(e.keyCode){
        case 10009: // RETURN button on TV Remote
            // If setup is open, do nothing. If playing, maybe exit or do nothing.
            // For digital signage, we usually block exit.
            e.preventDefault();
            break;
    }
});
