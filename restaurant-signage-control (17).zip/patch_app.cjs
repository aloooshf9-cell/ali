const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const targetState = `  const [activeScreens, setActiveScreens] = useState<any[]>([]);`;
const patchState = `  const [activeScreens, setActiveScreens] = useState<any[]>([]);
  const [editingScreenId, setEditingScreenId] = useState('');
  const [editScreenName, setEditScreenName] = useState('');
  
  const handleUpdateScreenName = async (id: string, name: string) => {
    try {
      await fetch('/api/screens/' + id + '/name', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name })
      });
      fetchScreens();
      setEditingScreenId('');
    } catch(e) {}
  };`;

if (code.includes(targetState)) {
    code = code.replace(targetState, patchState);
} else {
    console.log("Could not find state target");
}

const targetActivePanel = `                    <div key={i} className="flex flex-col bg-slate-50 p-2 rounded-lg border border-slate-100">
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-bold text-slate-800">ID: {s.id}</span>
                        <span className="flex items-center gap-1 text-[10px] text-emerald-600 font-medium bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-100"><div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></div> Online</span>
                      </div>
                      <span className="text-[10px] text-slate-500 mt-0.5">IP: {s.ip.replace('::ffff:', '')}</span>
                    </div>`;

const patchActivePanel = `                    <div key={i} className="flex flex-col bg-slate-50 p-2 rounded-lg border border-slate-100">
                      <div className="flex justify-between items-center">
                        <div className="flex flex-col">
                            <span className="text-sm font-bold text-slate-800">
                                ID: {s.id} 
                                {s.name && <span className="ml-2 text-xs font-normal text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full border border-indigo-100">{s.name}</span>}
                            </span>
                            <span className="text-[10px] text-slate-500 mt-0.5">IP: {s.ip.replace('::ffff:', '')}</span>
                        </div>
                        <span className="flex items-center gap-1 text-[10px] text-emerald-600 font-medium bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-100 mb-auto"><div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></div> Online</span>
                      </div>
                      
                      {/* Edit Name Section */}
                      <div className="mt-2 flex gap-2">
                        {editingScreenId === s.id ? (
                            <>
                                <input type="text" value={editScreenName} onChange={(e) => setEditScreenName(e.target.value)} className="flex-1 text-xs px-2 py-1 border border-slate-300 rounded outline-none" placeholder="Screen Name" />
                                <button onClick={() => handleUpdateScreenName(s.id, editScreenName)} className="text-xs bg-indigo-600 text-white px-2 py-1 rounded">Save</button>
                                <button onClick={() => setEditingScreenId('')} className="text-xs bg-slate-200 text-slate-700 px-2 py-1 rounded">Cancel</button>
                            </>
                        ) : (
                            <button onClick={() => { setEditingScreenId(s.id); setEditScreenName(s.name || ''); }} className="text-[10px] text-slate-500 hover:text-indigo-600">✎ Edit Name</button>
                        )}
                      </div>
                    </div>`;

if (code.includes(targetActivePanel)) {
    code = code.replace(targetActivePanel, patchActivePanel);
} else {
    console.log("Could not find active panel target");
}

fs.writeFileSync('src/App.tsx', code);
console.log("Patched App.tsx active panel");
