module.exports = {
  apps: [{
    name: "restaurant-signage",
    script: "dist/server.cjs",
    env: {
      NODE_ENV: "production",
      PORT: 2000
    },
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G'
  }]
}
