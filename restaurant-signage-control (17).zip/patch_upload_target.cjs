const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const targetTargeting = `{/* Screen Targeting Section */}
                <div className="pt-2 border-t border-slate-100">
                  <label className="block text-sm font-medium text-slate-700 mb-2 flex items-center gap-2">
                    <MonitorPlay className="w-4 h-4 text-slate-500" /> Target Specific Screens (Optional)
                  </label>
                  <input 
                    type="text" 
                    value={targetScreensInput} 
                    onChange={(e) => setTargetScreensInput(e.target.value)} 
                    placeholder="e.g. A1B2C3 (leave blank for all)" 
                    className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-sm mb-4" 
                  />
                </div>`;

const patchTargeting = `{/* Screen Targeting Section */}
                <div className="pt-2 border-t border-slate-100 bg-indigo-50/50 p-3 rounded-xl mb-4 border border-indigo-100">
                  <label className="block text-sm font-bold text-indigo-900 mb-2 flex items-center gap-2">
                    <MonitorPlay className="w-4 h-4 text-indigo-500" /> Choose Upload Target
                  </label>
                  <div className="space-y-3">
                      <label className="flex items-center gap-2 cursor-pointer bg-white p-2 rounded-lg border border-slate-200 hover:border-indigo-300">
                          <input type="radio" name="target" checked={targetScreensInput === ''} onChange={() => setTargetScreensInput('')} className="text-indigo-600 focus:ring-indigo-500" />
                          <span className="text-sm font-medium text-slate-700">🌎 All Screens (Global)</span>
                      </label>
                      {activeScreens.map(s => (
                          <label key={s.id} className="flex items-center gap-2 cursor-pointer bg-white p-2 rounded-lg border border-slate-200 hover:border-indigo-300">
                              <input type="radio" name="target" checked={targetScreensInput === s.id} onChange={() => setTargetScreensInput(s.id)} className="text-indigo-600 focus:ring-indigo-500" />
                              <span className="text-sm font-medium text-slate-700">📺 Specific Screen: {s.id}</span>
                          </label>
                      ))}
                      <label className="flex items-center gap-2 cursor-pointer bg-white p-2 rounded-lg border border-slate-200 hover:border-indigo-300">
                          <input type="radio" name="target" checked={targetScreensInput !== '' && !activeScreens.find(s => s.id === targetScreensInput)} onChange={() => setTargetScreensInput('MANUAL')} className="text-indigo-600 focus:ring-indigo-500" />
                          <span className="text-sm font-medium text-slate-700">⌨️ Other (Offline Screen)</span>
                      </label>
                      {targetScreensInput !== '' && !activeScreens.find(s => s.id === targetScreensInput) && (
                          <input 
                            type="text" 
                            value={targetScreensInput === 'MANUAL' ? '' : targetScreensInput} 
                            onChange={(e) => setTargetScreensInput(e.target.value)} 
                            placeholder="Enter Screen ID manually (e.g. A1B2C3)" 
                            className="w-full px-4 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-sm" 
                          />
                      )}
                  </div>
                </div>`;

if (code.includes(targetTargeting)) {
    code = code.replace(targetTargeting, patchTargeting);
    fs.writeFileSync('src/App.tsx', code);
    console.log("Patched Target Screens Section.");
} else {
    console.log("Could not find Target Screens Section.");
}
