const fs = require('fs');

const mainActivityPath = 'android-client/app/src/main/java/com/restaurant/signage/MainActivity.kt';
let mainActivity = fs.readFileSync(mainActivityPath, 'utf8');

mainActivity = mainActivity.replace(
    'onStatusUpdate = \n            onStatusUpdate = { status ->',
    'onStatusUpdate = { status ->'
);

mainActivity = mainActivity.replace(
    'onSettingsUpdated = { appName, isExpired, effect ->',
    'onSettingsUpdated = { appName, isExpired, effect ->'
);

// wait, I also forgot to pass serverUrl to SyncService in MainActivity.kt?
// let's check what I replaced earlier
fs.writeFileSync(mainActivityPath, mainActivity);
