const fs = require('fs');
let code = fs.readFileSync('android-client/app/src/main/java/com/restaurant/signage/MainActivity.kt', 'utf8');

const targetBackBtn = `    // 1. Prevent physical "Back" button from closing the app
    override fun onBackPressed() {
        // Do nothing! This disables the back button.
        // The app can only be closed via ADB or home button if another launcher exists.
    }`;

if (code.includes(targetBackBtn)) {
    code = code.replace(targetBackBtn, `    // 1. Physical "Back" button restored as requested.
    override fun onBackPressed() {
        super.onBackPressed()
    }`);
    fs.writeFileSync('android-client/app/src/main/java/com/restaurant/signage/MainActivity.kt', code);
    console.log("Restored Back Button");
} else {
    console.log("Could not find Back Button code.");
}
