const fs = require('fs');

const mainActivityPath = 'android-client/app/src/main/java/com/restaurant/signage/MainActivity.kt';
let mainActivity = fs.readFileSync(mainActivityPath, 'utf8');

const syncServicePath = 'android-client/app/src/main/java/com/restaurant/signage/SyncService.kt';
let syncService = fs.readFileSync(syncServicePath, 'utf8');

// 1. Update SyncService to accept serverUrl
syncService = syncService.replace(
    'private val onSettingsUpdated: (String, Boolean, String) -> Unit\n) {',
    'private val onSettingsUpdated: (String, Boolean, String) -> Unit,\n    private val serverUrl: String\n) {'
);
syncService = syncService.replace(
    'private val SERVER_URL = "http://10.218.0.111:2000"',
    '// private val SERVER_URL removed, passed in constructor'
);
syncService = syncService.replace(/SERVER_URL/g, 'serverUrl');

fs.writeFileSync(syncServicePath, syncService);

// 2. Update MainActivity
// Imports for AlertDialog and EditText
if (!mainActivity.includes('android.app.AlertDialog')) {
    mainActivity = mainActivity.replace(
        'import android.os.Bundle',
        'import android.app.AlertDialog\nimport android.widget.EditText\nimport android.os.Bundle'
    );
}

// Read server URL from prefs
mainActivity = mainActivity.replace(
    'screenId = prefs.getString("SCREEN_ID", null)',
    'var serverUrl = prefs.getString("SERVER_URL", "http://192.168.1.100:3000")!!\n        screenId = prefs.getString("SCREEN_ID", null)'
);

// Init sync service with server URL
mainActivity = mainActivity.replace(
    'syncService = SyncService(this, screenId,',
    'syncService = SyncService(this, screenId,\n            onStatusUpdate = '
);

mainActivity = mainActivity.replace(
    'onSettingsUpdated = {\n                appName, isExpired, expDate ->',
    'onSettingsUpdated = { appName, isExpired, expDate ->'
);

mainActivity = mainActivity.replace(
    'syncService = SyncService(this, screenId,\n            onStatusUpdate = ',
    'syncService = SyncService(\n            context = this,\n            screenId = screenId,\n            onStatusUpdate = '
);

mainActivity = mainActivity.replace(
    '                appName, isExpired, expDate ->\n                runOnUiThread {\n                    updateSettings(appName, isExpired, expDate)\n                }\n            }\n        )',
    '                runOnUiThread {\n                    updateSettings(appName, isExpired, expDate)\n                }\n            },\n            serverUrl = serverUrl\n        )'
);

mainActivity = mainActivity.replace(
    '            onSettingsUpdated = { appName, isExpired, expDate ->\n                runOnUiThread {\n                    updateSettings(appName, isExpired, expDate)\n                }\n            }',
    '            onSettingsUpdated = { appName, isExpired, expDate ->\n                runOnUiThread {\n                    updateSettings(appName, isExpired, expDate)\n                }\n            },\n            serverUrl = serverUrl\n'
);

// We need to inject the long click listener cleanly
const longClickListener = `
        screenIdText.setOnLongClickListener {
            val input = EditText(this)
            input.setText(serverUrl)
            AlertDialog.Builder(this)
                .setTitle("Server URL")
                .setMessage("Enter the IP and Port of your server\\n(e.g., http://192.168.1.100:3000)")
                .setView(input)
                .setPositiveButton("Save") { _, _ ->
                    val newUrl = input.text.toString()
                    prefs.edit().putString("SERVER_URL", newUrl).apply()
                    serverUrl = newUrl
                    // Restart app to apply
                    val intent = intent
                    finish()
                    startActivity(intent)
                }
                .setNegativeButton("Cancel", null)
                .show()
            true
        }
`;

mainActivity = mainActivity.replace(
    'screenIdText.text = "Screen ID: $screenId"',
    'screenIdText.text = "Screen ID: $screenId"' + longClickListener
);

fs.writeFileSync(mainActivityPath, mainActivity);

console.log("Patched Android code");
