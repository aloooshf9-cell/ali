const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

// 1. Update getActivePlaylist to accept screenId
const targetGetActive = `function getActivePlaylist(db) {
    const now = new Date();
    return db.playlist.filter(item => {`;
const patchGetActive = `function getActivePlaylist(db, screenId) {
    const now = new Date();
    return db.playlist.filter(item => {
      // Check target screens
      if (screenId && item.targetScreens && item.targetScreens.trim() !== '') {
          const targets = item.targetScreens.split(',').map(s => s.trim().toUpperCase());
          if (!targets.includes(screenId.toUpperCase())) return false;
      }`;
code = code.replace(targetGetActive, patchGetActive);

// 2. Track connected screens
const trackingTarget = `// --- Ensure Admin User Exists ---`;
const trackingPatch = `// Track connected screens
const connectedScreens = new Map();

// --- Ensure Admin User Exists ---`;
code = code.replace(trackingTarget, trackingPatch);

// 3. Expose connected screens API
const targetApiUsers = `app.get('/api/users', (req, res) => {`;
const patchApiUsers = `app.get('/api/screens', (req, res) => {
    res.json(Array.from(connectedScreens.values()));
  });

  app.get('/api/users', (req, res) => {`;
code = code.replace(targetApiUsers, patchApiUsers);

// 4. Update upload logic to save targetScreens
const targetUploadVars = `const duration = type === 'image' ? (parseInt(req.body.duration) || 10) : 0; // default 10s for images`;
const patchUploadVars = `const duration = type === 'image' ? (parseInt(req.body.duration) || 10) : 0; // default 10s for images
    const targetScreens = req.body.targetScreens || '';`;
code = code.replace(targetUploadVars, patchUploadVars);

const targetNewItem = `duration: duration,
      schedule: schedule
    };`;
const patchNewItem = `duration: duration,
      schedule: schedule,
      targetScreens: targetScreens
    };`;
code = code.replace(targetNewItem, patchNewItem);

// 5. Update WebSockets
const targetInterval = `setInterval(() => {
    const db = getDatabase();
    io.emit('playlist_updated', getActivePlaylist(db));
    io.emit('settings_updated', db.settings || {});
  }, 60000); // Check schedule every 1 minute`;

const patchInterval = `setInterval(() => {
    const db = getDatabase();
    // Emit to dashboard (all items)
    io.emit('playlist_updated_dashboard', db.playlist);
    
    // Emit to screens (filtered items)
    io.sockets.sockets.forEach(s => {
       const screenId = s.handshake.query.screenId;
       s.emit('playlist_updated', getActivePlaylist(db, screenId));
    });
    
    io.emit('settings_updated', db.settings || {});
  }, 60000); // Check schedule every 1 minute`;
code = code.replace(targetInterval, patchInterval);

// Update Socket Connection
const targetSocketOn = `io.on('connection', (socket) => {
    console.log('Client connected:', socket.id);
    const db = getDatabase();
    socket.emit('playlist_updated', getActivePlaylist(db));
    socket.emit('settings_updated', db.settings || {});
        
    socket.on('disconnect', () => {
      console.log('Client disconnected:', socket.id);
    });
  });`;

const patchSocketOn = `io.on('connection', (socket) => {
    const screenId = socket.handshake.query.screenId;
    const ip = socket.handshake.address;
    
    if (screenId && screenId !== 'undefined') {
        console.log('Screen connected:', screenId, 'IP:', ip);
        connectedScreens.set(socket.id, { id: screenId, ip: ip, lastSeen: new Date() });
    } else {
        console.log('Dashboard connected:', socket.id);
    }

    const db = getDatabase();
    if (screenId && screenId !== 'undefined') {
        socket.emit('playlist_updated', getActivePlaylist(db, screenId));
        socket.emit('settings_updated', db.settings || {});
    } else {
        socket.emit('playlist_updated', db.playlist); // Dashboard gets everything
    }
        
    socket.on('disconnect', () => {
      console.log('Client disconnected:', socket.id);
      if (connectedScreens.has(socket.id)) {
          connectedScreens.delete(socket.id);
      }
    });
  });`;
code = code.replace(targetSocketOn, patchSocketOn);


// Update all old emits to dashboard & screens
// For /api/upload
code = code.replace(
    `io.emit('playlist_updated', getActivePlaylist(db));`,
    `// Emit to dashboard
    io.emit('playlist_updated', db.playlist);
    // Emit to screens
    io.sockets.sockets.forEach(s => {
       const screenId = s.handshake.query.screenId;
       if (screenId && screenId !== 'undefined') {
          s.emit('playlist_updated', getActivePlaylist(db, screenId));
       }
    });`
);
// For /api/playlist (PUT)
code = code.replace(
    `io.emit('playlist_updated', getActivePlaylist(db));`,
    `// Emit to dashboard
    io.emit('playlist_updated', db.playlist);
    // Emit to screens
    io.sockets.sockets.forEach(s => {
       const screenId = s.handshake.query.screenId;
       if (screenId && screenId !== 'undefined') {
          s.emit('playlist_updated', getActivePlaylist(db, screenId));
       }
    });`
);
// For /api/playlist/:id (DELETE)
code = code.replace(
    `io.emit('playlist_updated', getActivePlaylist(db));`,
    `// Emit to dashboard
    io.emit('playlist_updated', db.playlist);
    // Emit to screens
    io.sockets.sockets.forEach(s => {
       const screenId = s.handshake.query.screenId;
       if (screenId && screenId !== 'undefined') {
          s.emit('playlist_updated', getActivePlaylist(db, screenId));
       }
    });`
);

fs.writeFileSync('server.ts', code);
