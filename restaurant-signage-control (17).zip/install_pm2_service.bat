@echo off
echo ==========================================
echo Installing Signage Server as a Windows Service (24/7)
echo ==========================================
echo 1. Installing pm2 globally...
call npm install -g pm2
echo.
echo 2. Installing pm2-windows-service...
call npm install -g pm2-windows-service
echo.
echo 3. Starting the application via pm2...
call pm2 start pm2_ecosystem.config.js
echo.
echo 4. Saving pm2 configuration...
call pm2 save
echo.
echo 5. Installing Windows Service (Run this as Administrator if it asks)
call pm2-service-install -n RestaurantSignage
echo.
echo Done! The server will now start automatically with Windows and restart if it crashes.
pause
